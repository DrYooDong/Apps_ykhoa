import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { requireAuth, AuthRequest } from './src/middleware/auth.ts';
import { signUserToken } from './src/lib/jwt.ts';
import {
  registerDoctor,
  verifyDoctorCredentials,
  seedDefaultDoctor,
  getOrCreateUser,
} from './src/db/users.ts';
import {
  getPatients,
  getPatientById,
  createPatient,
  updatePatient,
  deletePatient,
} from './src/db/patients.ts';
import {
  getMedicalRecords,
  getMedicalRecordById,
  createMedicalRecord,
  deleteMedicalRecord,
} from './src/db/records.ts';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Seed default doctor account if not exists
  await seedDefaultDoctor();

  // ----------------------------------------------------
  // API Routes
  // ----------------------------------------------------

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      service: 'MedLens Medical Record Engine',
      db: 'Cloud SQL PostgreSQL',
      timestamp: new Date().toISOString(),
    });
  });

  // --- Auth Endpoints ---

  // Login with email & password -> returns JWT
  app.post('/api/auth/login', async (req, res) => {
    try {
      const { email, password } = req.body;
      if (!email || !password) {
        return res.status(400).json({ error: 'Vui lòng nhập đầy đủ email và mật khẩu' });
      }

      const user = await verifyDoctorCredentials(email, password);
      if (!user) {
        return res.status(401).json({ error: 'Email hoặc mật khẩu không chính xác' });
      }

      const token = signUserToken({
        uid: user.uid,
        email: user.email,
        name: user.name,
        role: user.role,
        specialty: user.specialty || undefined,
      });

      res.json({
        token,
        user: {
          uid: user.uid,
          email: user.email,
          name: user.name,
          role: user.role,
          specialty: user.specialty,
        },
      });
    } catch (error: any) {
      console.error('Login error:', error);
      res.status(500).json({ error: error.message || 'Lỗi đăng nhập hệ thống' });
    }
  });

  // Register new medical staff -> returns JWT
  app.post('/api/auth/register', async (req, res) => {
    try {
      const { email, password, name, role, specialty } = req.body;
      if (!email || !password || !name) {
        return res.status(400).json({ error: 'Vui lòng điền đầy đủ thông tin: họ tên, email và mật khẩu' });
      }

      const newUser = await registerDoctor({
        email,
        password,
        name,
        role,
        specialty,
      });

      const token = signUserToken({
        uid: newUser.uid,
        email: newUser.email,
        name: newUser.name,
        role: newUser.role,
        specialty: newUser.specialty || undefined,
      });

      res.status(201).json({
        token,
        user: {
          uid: newUser.uid,
          email: newUser.email,
          name: newUser.name,
          role: newUser.role,
          specialty: newUser.specialty,
        },
      });
    } catch (error: any) {
      console.error('Register error:', error);
      res.status(400).json({ error: error.message || 'Lỗi đăng ký tài khoản bác sĩ' });
    }
  });

  // Google OAuth verification / sync -> returns JWT
  app.post('/api/auth/google', async (req, res) => {
    try {
      const { uid, email, name } = req.body;
      if (!uid || !email) {
        return res.status(400).json({ error: 'Thiếu thông tin Google OAuth' });
      }

      const user = await getOrCreateUser(uid, email, name);
      const token = signUserToken({
        uid: user.uid,
        email: user.email,
        name: user.name,
        role: user.role,
        specialty: user.specialty || undefined,
      });

      res.json({
        token,
        user: {
          uid: user.uid,
          email: user.email,
          name: user.name,
          role: user.role,
          specialty: user.specialty,
        },
      });
    } catch (error: any) {
      console.error('Google auth sync error:', error);
      res.status(500).json({ error: error.message || 'Lỗi đồng bộ tài khoản Google' });
    }
  });

  // Current user info
  app.get('/api/auth/me', requireAuth, (req: AuthRequest, res) => {
    res.json({ user: req.user });
  });

  // --- Patients Endpoints ---

  app.get('/api/patients', requireAuth, async (req: AuthRequest, res) => {
    try {
      const q = typeof req.query.q === 'string' ? req.query.q : undefined;
      const patientsList = await getPatients(q);
      res.json(patientsList);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get('/api/patients/:id', requireAuth, async (req: AuthRequest, res) => {
    try {
      const patient = await getPatientById(Number(req.params.id));
      if (!patient) {
        return res.status(404).json({ error: 'Không tìm thấy bệnh nhân' });
      }
      res.json(patient);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/patients', requireAuth, async (req: AuthRequest, res) => {
    try {
      const { fullName, gender, age, occupation, phoneNumber, idCard, address, notes } = req.body;
      if (!fullName) {
        return res.status(400).json({ error: 'Họ và tên bệnh nhân là bắt buộc' });
      }

      const patient = await createPatient({
        fullName,
        gender,
        age: age ? Number(age) : undefined,
        occupation,
        phoneNumber,
        idCard,
        address,
        notes,
        createdByUid: req.user?.uid,
      });

      res.status(201).json(patient);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.put('/api/patients/:id', requireAuth, async (req: AuthRequest, res) => {
    try {
      const updated = await updatePatient(Number(req.params.id), req.body);
      if (!updated) {
        return res.status(404).json({ error: 'Không tìm thấy bệnh nhân' });
      }
      res.json(updated);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete('/api/patients/:id', requireAuth, async (req: AuthRequest, res) => {
    try {
      const deleted = await deletePatient(Number(req.params.id));
      if (!deleted) {
        return res.status(404).json({ error: 'Không tìm thấy bệnh nhân' });
      }
      res.json({ success: true, deleted });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // --- Medical Records Endpoints ---

  app.get('/api/records', requireAuth, async (req: AuthRequest, res) => {
    try {
      const q = typeof req.query.q === 'string' ? req.query.q : undefined;
      const records = await getMedicalRecords(q);
      res.json(records);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get('/api/records/:id', requireAuth, async (req: AuthRequest, res) => {
    try {
      const record = await getMedicalRecordById(Number(req.params.id));
      if (!record) {
        return res.status(404).json({ error: 'Không tìm thấy bệnh án' });
      }
      res.json(record);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/records', requireAuth, async (req: AuthRequest, res) => {
    try {
      const recordData = req.body;
      if (!recordData.patientName) {
        return res.status(400).json({ error: 'Thiếu họ tên bệnh nhân' });
      }

      const created = await createMedicalRecord({
        ...recordData,
        doctorUid: req.user?.uid || 'dr_unassigned',
        doctorName: req.user?.name || 'Bác sĩ lâm sàng',
      });

      res.status(201).json(created);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete('/api/records/:id', requireAuth, async (req: AuthRequest, res) => {
    try {
      const deleted = await deleteMedicalRecord(Number(req.params.id));
      if (!deleted) {
        return res.status(404).json({ error: 'Không tìm thấy bệnh án để xóa' });
      }
      res.json({ success: true, deleted });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ----------------------------------------------------
  // Vite Middleware / Static Serving
  // ----------------------------------------------------
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`MedLens Server chạy tại http://0.0.0.0:${PORT}`);
  });
}

startServer();
