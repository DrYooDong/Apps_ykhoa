import React from 'react';
import { Database, Download, HelpCircle, Key, Lock, LogOut, ShieldCheck, Stethoscope } from 'lucide-react';
import { useAuth } from '../context/AuthContext.tsx';
import { KnowledgeBase } from '../types.ts';

interface HeaderProps {
  kb: KnowledgeBase;
  onOpenKB: () => void;
  onOpenRecords: () => void;
  onOpenAuth: () => void;
  onOpenAbout: () => void;
  onExportKB: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  kb,
  onOpenKB,
  onOpenRecords,
  onOpenAuth,
  onOpenAbout,
  onExportKB,
}) => {
  const { user, token, logout } = useAuth();
  const totalLinks = kb.benh.reduce((sum, b) => sum + b.dd.length, 0);

  return (
    <header className="h-14 bg-white border-b border-slate-200 flex items-center justify-between px-4 sm:px-6 shrink-0 select-none z-30 no-print">
      {/* Brand & Core Badges */}
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 bg-blue-600 rounded-md flex items-center justify-center text-white shadow-xs">
          <Stethoscope className="w-4.5 h-4.5" />
        </div>
        <div className="flex items-baseline gap-2">
          <h1 className="text-base sm:text-lg font-bold tracking-tight text-slate-800 flex items-center">
            MedLens <span className="text-blue-600 ml-1">Pro</span>
          </h1>
          <div className="hidden sm:inline-flex px-2 py-0.5 bg-blue-50 border border-blue-100 rounded text-[10px] font-semibold text-blue-700 uppercase tracking-wider">
            Clinical AI & TS
          </div>
        </div>

        {/* Live KB Stat */}
        <div className="hidden xl:flex items-center gap-2 font-mono-custom text-[11px] text-slate-500 bg-slate-50 px-2.5 py-1 rounded border border-slate-200 ml-2">
          <span className="w-1.5 h-1.5 rounded-full bg-blue-600 animate-pulse"></span>
          <span>Tri thức:</span>
          <b className="text-slate-700 font-semibold">{kb.benh.length}</b> bệnh
          <span className="text-slate-300">·</span>
          <b className="text-slate-700 font-semibold">{kb.trieuChung.length}</b> từ vựng
          <span className="text-slate-300">·</span>
          <b className="text-slate-700 font-semibold">{totalLinks}</b> liên kết
        </div>
      </div>

      {/* Connection Badges & Action Buttons */}
      <div className="flex items-center gap-3 sm:gap-4">
        {/* Status indicators */}
        <div className="hidden md:flex items-center gap-4 text-xs font-medium text-slate-500">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
            <span className="text-[11px] text-slate-600 font-medium">PostgreSQL Connected</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Lock className="w-3.5 h-3.5 text-blue-600" />
            <span className="text-[11px] text-slate-600 font-medium">JWT Secured</span>
          </div>
        </div>

        <div className="h-4 w-[1px] bg-slate-200 hidden md:block"></div>

        {/* Navigation Action Buttons */}
        <nav className="flex items-center gap-2">
          <button
            id="btn-nav-kb"
            onClick={onOpenKB}
            className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 rounded text-xs font-medium transition-colors cursor-pointer"
            title="Xem kho tri thức lâm sàng"
          >
            <Database className="w-3.5 h-3.5 text-blue-600" />
            <span className="hidden sm:inline">Kho tri thức</span>
          </button>

          <button
            id="btn-nav-records"
            onClick={onOpenRecords}
            className="flex items-center gap-1.5 px-2.5 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 rounded text-xs font-semibold transition-colors cursor-pointer shadow-xs"
            title="Quản lý hồ sơ bệnh nhân trong PostgreSQL"
          >
            <Stethoscope className="w-3.5 h-3.5 text-blue-600" />
            <span>Hồ sơ bệnh án</span>
          </button>

          <button
            id="btn-nav-export-kb"
            onClick={onExportKB}
            title="Xuất cơ sở tri thức dạng JSON"
            className="hidden lg:flex items-center gap-1 px-2 py-1 text-xs font-medium rounded border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span>JSON</span>
          </button>

          {/* User Auth Profile */}
          {user ? (
            <div className="flex items-center gap-2 pl-2 border-l border-slate-200">
              <div className="text-right hidden sm:block">
                <p className="text-xs font-bold text-slate-800 leading-tight truncate max-w-[120px]">{user.name}</p>
                <p className="text-[10px] text-blue-600 font-semibold uppercase tracking-wider">
                  {user.specialty || 'Bác sĩ lâm sàng'}
                </p>
              </div>
              <div className="w-7 h-7 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold text-xs border border-blue-700 shadow-xs">
                {user.name.charAt(0).toUpperCase()}
              </div>
              <button
                onClick={logout}
                title="Đăng xuất"
                className="p-1 text-slate-400 hover:text-red-600 transition-colors"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <button
              id="btn-nav-auth"
              onClick={onOpenAuth}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded text-xs font-semibold shadow-xs transition-colors cursor-pointer"
            >
              <Key className="w-3.5 h-3.5" />
              <span>Đăng nhập</span>
            </button>
          )}

          <button
            id="btn-nav-about"
            onClick={onOpenAbout}
            className="p-1 text-slate-400 hover:text-slate-700 rounded transition-colors"
            title="Về công cụ MedLens"
          >
            <HelpCircle className="w-4 h-4" />
          </button>
        </nav>
      </div>
    </header>
  );
};
