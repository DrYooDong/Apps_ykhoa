import React, { useMemo, useState } from 'react';
import {
  Activity,
  AlertCircle,
  AlertTriangle,
  ArrowLeft,
  Calculator,
  Check,
  CheckCircle2,
  ChevronRight,
  ClipboardCheck,
  ClipboardCopy,
  Clock,
  Database,
  FileCheck,
  FileText,
  Filter,
  Heart,
  HeartPulse,
  Info,
  Pill,
  Plus,
  Printer,
  RotateCcw,
  Search,
  ShieldAlert,
  Sparkles,
  Stethoscope,
  Syringe,
  Trash2,
  Truck,
  User,
  X,
  Zap,
} from 'lucide-react';
import {
  ClinicalFormState,
  KnowledgeBase,
  LabsState,
  VitalsState,
} from '../types.ts';
import { GROUP_COLORS, GROUP_NAMES } from '../data/seedData.ts';

interface CustomOrder {
  id: string;
  drug: string;
  dosage: string;
  note: string;
  completed: boolean;
}

interface Step3Props {
  kb: KnowledgeBase;
  selectedDiseaseId: string | null;
  onSelectDisease: (id: string) => void;
  onBackToAnalysis: () => void;
  onSaveToPostgres: () => void;
  onPrintReport: () => void;
  form?: ClinicalFormState;
  vitals?: VitalsState;
  labs?: LabsState;
}

export const Step3Protocol: React.FC<Step3Props> = ({
  kb,
  selectedDiseaseId,
  onSelectDisease,
  onBackToAnalysis,
  onSaveToPostgres,
  onPrintReport,
  form,
  vitals,
  labs,
}) => {
  // Local state for checked orders & custom doctor additions
  const [checkedOrders, setCheckedOrders] = useState<Set<string>>(new Set());
  const [customOrders, setCustomOrders] = useState<CustomOrder[]>([]);
  const [newDrug, setNewDrug] = useState('');
  const [newDosage, setNewDosage] = useState('');
  const [newNote, setNewNote] = useState('');
  const [showAddCustom, setShowAddCustom] = useState(false);
  const [copySuccess, setCopySuccess] = useState(false);
  const [searchDisease, setSearchDisease] = useState('');
  const [selectedSpecialty, setSelectedSpecialty] = useState<string>('all');
  const [showCalculator, setShowCalculator] = useState(false);

  // Quick Clinical Risk Calculator state
  const [curbScores, setCurbScores] = useState({
    c: false, // Confusion
    u: false, // Urea > 7
    r: false, // RR >= 30
    b: false, // BP < 90/60
    age: false, // Age >= 65
  });

  const [killipClass, setKillipClass] = useState<'I' | 'II' | 'III' | 'IV'>('I');

  // Currently viewed disease
  const currentDisease = useMemo(() => {
    return kb.benh.find((b) => b.id === selectedDiseaseId) || kb.benh[0];
  }, [kb, selectedDiseaseId]);

  // Robust protocol data from disease or standard fallback
  const phacDo = useMemo(() => {
    return (
      currentDisease?.phacDo || {
        tuyen: [
          'Đánh giá ABC: Đảm bảo đường thở thông thoáng, kiểm soát hô hấp và tuần hoàn',
          'Thiết lập đường truyền tĩnh mạch lớn (G18-G20), theo dõi sát mạch và huyết áp',
          'Lấy máu xét nghiệm cấp cứu: Công thức máu, điện giải đồ, chức năng gan thận',
          'Theo dõi monitor sinh hiệu liên tục, chuẩn bị phương tiện cấp cứu',
        ],
        thuoc: [
          ['Natri Clorid 0,9%', '500 ml TTM 30 giọt/phút', 'duy trì đường truyền'],
          ['Paracetamol', '1 g TTM khi sốt >= 38.5°C hoặc đau nhiều', 'cách mỗi 6h'],
        ],
        theoDoi: [
          'Theo dõi tri giác, dấu hiệu sinh tồn (Mạch, HA, SpO2, Nhịp thở) mỗi 15-30 phút',
          'Lượng nước tiểu 24 giờ, mục tiêu >= 0.5 ml/kg/h',
        ],
        luuY: [
          'Thận trọng với bệnh nhân suy tim, suy thận mạn tính hoặc tiền căn dị ứng thuốc',
          'Hội chẩn chuyên khoa nếu diễn tiến lâm sàng không đáp ứng sau 2 giờ đầu',
        ],
        nguon: ['Hướng dẫn chẩn đoán và điều trị Bộ Y tế Việt Nam'],
      }
    );
  }, [currentDisease]);

  // Filtered diseases for selector dropdown / quick search
  const filteredDiseases = useMemo(() => {
    const q = searchDisease.toLowerCase().trim();
    return kb.benh.filter((b) => {
      const matchSpecialty =
        selectedSpecialty === 'all' || b.nhom === selectedSpecialty;
      const matchQuery =
        !q ||
        b.ten.toLowerCase().includes(q) ||
        b.icd.toLowerCase().includes(q) ||
        b.nhom.toLowerCase().includes(q);
      return matchSpecialty && matchQuery;
    });
  }, [kb, searchDisease, selectedSpecialty]);

  // All unique organ specialties
  const specialties = useMemo(() => {
    const set = new Set<string>();
    kb.benh.forEach((b) => {
      if (b.nhom) set.add(b.nhom);
    });
    return Array.from(set);
  }, [kb]);

  // Toggle order checkbox
  const toggleOrder = (key: string) => {
    setCheckedOrders((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  // Mark all standard protocol orders as completed
  const handleCompleteAll = () => {
    if (!currentDisease) return;
    const next = new Set(checkedOrders);
    phacDo.tuyen.forEach((_, idx) => next.add(`tuyen-${currentDisease.id}-${idx}`));
    phacDo.thuoc.forEach((_, idx) => next.add(`thuoc-${currentDisease.id}-${idx}`));
    phacDo.theoDoi.forEach((_, idx) => next.add(`theodoi-${currentDisease.id}-${idx}`));
    setCheckedOrders(next);
  };

  // Reset checked orders for current disease
  const handleResetOrders = () => {
    if (!currentDisease) return;
    setCheckedOrders((prev) => {
      const next = new Set(prev);
      phacDo.tuyen.forEach((_, idx) => next.delete(`tuyen-${currentDisease.id}-${idx}`));
      phacDo.thuoc.forEach((_, idx) => next.delete(`thuoc-${currentDisease.id}-${idx}`));
      phacDo.theoDoi.forEach((_, idx) => next.delete(`theodoi-${currentDisease.id}-${idx}`));
      return next;
    });
  };

  // Add custom order
  const handleAddCustomOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDrug.trim()) return;
    const newOrder: CustomOrder = {
      id: `custom-${Date.now()}`,
      drug: newDrug.trim(),
      dosage: newDosage.trim() || 'Theo chỉ định bác sĩ',
      note: newNote.trim() || 'Y lệnh bổ sung',
      completed: false,
    };
    setCustomOrders((prev) => [...prev, newOrder]);
    setNewDrug('');
    setNewDosage('');
    setNewNote('');
    setShowAddCustom(false);
  };

  const toggleCustomOrder = (id: string) => {
    setCustomOrders((prev) =>
      prev.map((o) => (o.id === id ? { ...o, completed: !o.completed } : o))
    );
  };

  const removeCustomOrder = (id: string) => {
    setCustomOrders((prev) => prev.filter((o) => o.id !== id));
  };

  // Execution Progress Calculation
  const totalStandardOrders =
    phacDo.tuyen.length + phacDo.thuoc.length + phacDo.theoDoi.length;
  const currentCheckedCount = useMemo(() => {
    if (!currentDisease) return 0;
    let count = 0;
    phacDo.tuyen.forEach((_, idx) => {
      if (checkedOrders.has(`tuyen-${currentDisease.id}-${idx}`)) count++;
    });
    phacDo.thuoc.forEach((_, idx) => {
      if (checkedOrders.has(`thuoc-${currentDisease.id}-${idx}`)) count++;
    });
    phacDo.theoDoi.forEach((_, idx) => {
      if (checkedOrders.has(`theodoi-${currentDisease.id}-${idx}`)) count++;
    });
    const completedCustom = customOrders.filter((c) => c.completed).length;
    return count + completedCustom;
  }, [currentDisease, phacDo, checkedOrders, customOrders]);

  const totalAllOrders = totalStandardOrders + customOrders.length;
  const progressPercent = totalAllOrders > 0 ? Math.round((currentCheckedCount / totalAllOrders) * 100) : 0;

  // Copy Formatted Medical Order Sheet to Clipboard (HIS / EMR ready)
  const handleCopyOrderSheet = async () => {
    if (!currentDisease) return;

    const lines: string[] = [];
    lines.push(`========================================================`);
    lines.push(`PHIẾU Y LỆNH ĐIỀU TRỊ CHUYÊN KHOA (EMR FORMAT)`);
    lines.push(`Bệnh viện / Cơ sở y tế: Hệ thống Phân tích MedLens Pro`);
    lines.push(`Thời gian ra y lệnh: ${new Date().toLocaleString('vi-VN')}`);
    lines.push(`--------------------------------------------------------`);
    if (form) {
      lines.push(
        `Người bệnh: ${form.gioiTinh === 'nam' ? 'Nam' : 'Nữ'}, ${form.tuoi || '—'} tuổi | Nghề: ${
          form.ngheNghiep || '—'
        }`
      );
      lines.push(`Lý do vào viện: ${form.lyDo || '—'}`);
    }
    if (vitals) {
      lines.push(
        `Sinh hiệu: T° ${vitals.vNhiet || '—'}°C | Mạch ${vitals.vMach || '—'} l/p | HA ${
          vitals.vHATT || '—'
        }/${vitals.vHATTr || '—'} mmHg | Thở ${vitals.vTho || '—'} l/p | SpO2 ${vitals.vSpo2 || '—'}%`
      );
    }
    lines.push(`--------------------------------------------------------`);
    lines.push(`CHẨN ĐOÁN: ${currentDisease.ten} (ICD-10: ${currentDisease.icd})`);
    lines.push(`Phân loại: ${currentDisease.baoDong ? 'CẤP CỨU / NGUY KỊCH' : 'Thường quy / Theo dõi'}`);
    lines.push(`Nguồn phác đồ: ${phacDo.nguon.join('; ')}`);
    lines.push(`--------------------------------------------------------`);

    lines.push(`I. QUY TRÌNH XỬ TRÍ CẤP CỨU & CAN THIỆP:`);
    phacDo.tuyen.forEach((step, idx) => {
      const isDone = checkedOrders.has(`tuyen-${currentDisease.id}-${idx}`);
      lines.push(`  ${idx + 1}. [${isDone ? 'X' : ' '}] ${step}`);
    });

    lines.push(`\nII. Y LỆNH THUỐC & DƯỢC LÂM SÀNG:`);
    phacDo.thuoc.forEach(([drug, dose, note], idx) => {
      const isDone = checkedOrders.has(`thuoc-${currentDisease.id}-${idx}`);
      lines.push(`  ${idx + 1}. [${isDone ? 'X' : ' '}] ${drug} - Liều: ${dose} ${note ? `(${note})` : ''}`);
    });

    if (customOrders.length > 0) {
      lines.push(`\nIII. Y LỆNH BỔ SUNG CỦA BÁC SĨ:`);
      customOrders.forEach((co, idx) => {
        lines.push(`  ${idx + 1}. [${co.completed ? 'X' : ' '}] ${co.drug} - ${co.dosage} (${co.note})`);
      });
    }

    lines.push(`\nIV. THEO DÕI & MỤC TIÊU LÂM SÀNG:`);
    phacDo.theoDoi.forEach((m, idx) => {
      const isDone = checkedOrders.has(`theodoi-${currentDisease.id}-${idx}`);
      lines.push(`  - [${isDone ? 'X' : ' '}] ${m}`);
    });

    lines.push(`\nV. CẢNH BÁO AN TOÀN & LƯU Ý:`);
    phacDo.luuY.forEach((ly) => {
      lines.push(`  ! ${ly}`);
    });

    lines.push(`--------------------------------------------------------`);
    lines.push(`BÁC SĨ ĐIỀU TRỊ: Đã duyệt y lệnh điện tử`);
    lines.push(`========================================================`);

    try {
      await navigator.clipboard.writeText(lines.join('\n'));
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2500);
    } catch {
      // Fallback
    }
  };

  // Determine abnormal vitals for patient warning banner
  const abnormalVitalsSummary = useMemo(() => {
    if (!vitals) return [];
    const list: string[] = [];
    const t = parseFloat(vitals.vNhiet);
    const m = parseFloat(vitals.vMach);
    const hatt = parseFloat(vitals.vHATT);
    const hattr = parseFloat(vitals.vHATTr);
    const nt = parseFloat(vitals.vTho);
    const spo2 = parseFloat(vitals.vSpo2);

    if (!isNaN(t) && (t >= 38.0 || t < 36.0)) list.push(`T°: ${t}°C`);
    if (!isNaN(m) && (m > 100 || m < 60)) list.push(`Mạch: ${m} l/p`);
    if (!isNaN(hatt) && (hatt >= 140 || hatt < 90)) list.push(`HATT: ${hatt} mmHg`);
    if (!isNaN(hattr) && hattr >= 90) list.push(`HATTr: ${hattr} mmHg`);
    if (!isNaN(nt) && (nt > 22 || nt < 12)) list.push(`Thở: ${nt} l/p`);
    if (!isNaN(spo2) && spo2 < 94) list.push(`SpO₂: ${spo2}%`);
    return list;
  }, [vitals]);

  // CURB-65 total score
  const curbScoreTotal = useMemo(() => {
    return Object.values(curbScores).filter(Boolean).length;
  }, [curbScores]);

  return (
    <div className="flex flex-col gap-4">
      {/* Top Clinical Navigation Bar & Protocol Switcher */}
      <div className="bg-white border border-slate-200 rounded-lg p-3 sm:p-4 shadow-xs flex flex-wrap items-center justify-between gap-3">
        {/* Left: Back & Title */}
        <div className="flex items-center gap-3">
          <button
            id="btn-back-to-step2"
            onClick={onBackToAnalysis}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 text-xs font-semibold rounded-md transition-colors cursor-pointer"
            title="Quay lại bảng phân tích và chẩn đoán phân biệt"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Quay lại phân tích</span>
            <span className="sm:hidden">Quay lại</span>
          </button>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-display text-base sm:text-lg font-bold text-slate-800">
                Phác đồ điều trị & Y lệnh lâm sàng
              </h2>
              <span className="px-2 py-0.5 text-[10.5px] font-mono-custom bg-emerald-50 text-emerald-700 border border-emerald-200 rounded font-semibold">
                Clinical Pathway
              </span>
            </div>
            <p className="text-[11px] text-slate-500">
              Chuẩn hóa theo Hướng dẫn Bộ Y tế và Hiệp hội Quốc tế (AHA, ESC, ATS, GOLD)
            </p>
          </div>
        </div>

        {/* Right: Quick actions & selector */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Specialty Filter */}
          <div className="flex items-center gap-1">
            <Filter className="w-3.5 h-3.5 text-slate-400 hidden md:inline" />
            <select
              value={selectedSpecialty}
              onChange={(e) => setSelectedSpecialty(e.target.value)}
              className="border border-slate-200 rounded-md px-2 py-1.5 text-xs bg-slate-50 focus:outline-none focus:border-blue-500 text-slate-700 font-medium"
            >
              <option value="all">Tất cả chuyên khoa</option>
              {specialties.map((s) => (
                <option key={s} value={s}>
                  {GROUP_NAMES[s] || s}
                </option>
              ))}
            </select>
          </div>

          {/* Disease Selector Dropdown */}
          <select
            id="select-disease-protocol"
            value={currentDisease?.id || ''}
            onChange={(e) => onSelectDisease(e.target.value)}
            className="border border-slate-200 rounded-md px-2.5 py-1.5 text-xs font-semibold bg-slate-50 focus:outline-none focus:border-blue-500 text-slate-800 max-w-[240px] truncate"
          >
            {filteredDiseases.map((b) => (
              <option key={b.id} value={b.id}>
                {b.baoDong ? '⚑ ' : ''}
                {b.ten} ({b.icd})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Patient Vital Context Banner (If patient data exists) */}
      {(form || (vitals && Object.values(vitals).some(Boolean))) && (
        <div className="bg-slate-900 text-white rounded-lg p-3 px-4 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-3 flex-wrap">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-blue-500/20 text-blue-300 border border-blue-400/30 flex items-center justify-center font-bold text-xs">
                <User className="w-3.5 h-3.5" />
              </span>
              <span className="font-semibold text-slate-200">
                {form?.gioiTinh === 'nam' ? 'Nam' : form?.gioiTinh === 'nu' ? 'Nữ' : 'Bệnh nhân'}{' '}
                {form?.tuoi ? `· ${form.tuoi} tuổi` : ''}
              </span>
              {form?.ngheNghiep && (
                <span className="text-slate-400 hidden sm:inline">({form.ngheNghiep})</span>
              )}
            </div>

            {form?.lyDo && (
              <div className="text-slate-300 hidden md:flex items-center gap-1.5 border-l border-slate-700 pl-3">
                <span className="text-slate-400">Lý do vào viện:</span>
                <span className="font-medium text-white italic">"{form.lyDo}"</span>
              </div>
            )}
          </div>

          {/* Current Vitals Readings */}
          {vitals && (
            <div className="flex items-center gap-3 font-mono-custom text-[11px] text-slate-300 flex-wrap">
              <span className="flex items-center gap-1">
                <span className="text-slate-400">T°:</span>
                <b className={parseFloat(vitals.vNhiet) >= 38 ? 'text-amber-400' : 'text-slate-100'}>
                  {vitals.vNhiet || '—'}°C
                </b>
              </span>
              <span>·</span>
              <span className="flex items-center gap-1">
                <span className="text-slate-400">Mạch:</span>
                <b className={parseFloat(vitals.vMach) > 100 ? 'text-rose-400' : 'text-slate-100'}>
                  {vitals.vMach || '—'} l/p
                </b>
              </span>
              <span>·</span>
              <span className="flex items-center gap-1">
                <span className="text-slate-400">HA:</span>
                <b className="text-slate-100">
                  {vitals.vHATT || '—'}/{vitals.vHATTr || '—'}
                </b>
              </span>
              <span>·</span>
              <span className="flex items-center gap-1">
                <span className="text-slate-400">SpO₂:</span>
                <b className={parseFloat(vitals.vSpo2) < 94 ? 'text-rose-400' : 'text-emerald-400'}>
                  {vitals.vSpo2 || '—'}%
                </b>
              </span>
            </div>
          )}
        </div>
      )}

      {/* Abnormal Signs Quick Warning Alert */}
      {abnormalVitalsSummary.length > 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-2.5 px-3.5 flex items-center justify-between text-amber-900 text-xs shadow-2xs">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
            <span>
              <b>Lưu ý sinh hiệu người bệnh:</b> Phát hiện các thông số vượt ngưỡng tham chiếu:{' '}
              <span className="font-semibold">{abnormalVitalsSummary.join(' · ')}</span>. Ưu tiên các
              y lệnh ổn định huyết động và oxy liệu pháp.
            </span>
          </div>
        </div>
      )}

      {/* Main Protocol Presentation Card */}
      {currentDisease && (
        <div className="bg-white border border-slate-200 rounded-lg p-4 sm:p-6 shadow-xs flex flex-col gap-5">
          {/* Disease Header Banner & Metadata */}
          <div className="flex flex-wrap items-start justify-between gap-4 pb-4 border-b border-slate-200">
            <div className="flex flex-col gap-1.5 max-w-3xl">
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="font-display text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
                  {currentDisease.ten}
                </h3>
                <span className="px-2 py-0.5 text-xs font-mono-custom bg-slate-800 text-white rounded font-semibold">
                  {currentDisease.icd}
                </span>
                <span
                  className="px-2 py-0.5 text-[11px] font-semibold text-white rounded"
                  style={{ backgroundColor: GROUP_COLORS[currentDisease.nhom] || '#2563eb' }}
                >
                  {GROUP_NAMES[currentDisease.nhom] || currentDisease.nhom}
                </span>
                {currentDisease.baoDong && (
                  <span className="px-2.5 py-0.5 text-[11px] font-bold bg-red-50 text-red-700 border border-red-200 rounded flex items-center gap-1 animate-pulse">
                    <ShieldAlert className="w-3.5 h-3.5 text-red-600" />
                    <span>CẤP CỨU / NGUY KỊCH</span>
                  </span>
                )}
              </div>

              {currentDisease.baoDong && currentDisease.ghiChuBaoDong && (
                <div className="text-xs text-red-800 bg-red-50/80 p-2 rounded border border-red-200 font-medium">
                  ⚑ <b>Cảnh báo đỏ:</b> {currentDisease.ghiChuBaoDong}
                </div>
              )}

              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                {currentDisease.tomTat}
              </p>
            </div>

            {/* Reference Source Tag */}
            <div className="text-right flex flex-col items-end gap-1 font-mono-custom text-xs">
              <span className="text-slate-400 text-[11px]">Nguồn phác đồ:</span>
              <div className="flex flex-col items-end gap-1">
                {phacDo.nguon.map((src, i) => (
                  <span
                    key={i}
                    className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 border border-slate-200 font-medium text-[11px]"
                  >
                    {src}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Clinical Order Execution Progress Bar & Actions */}
          <div className="bg-slate-50 border border-slate-200 rounded-lg p-3.5 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3 flex-1 min-w-[240px]">
              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800">
                <ClipboardCheck className="w-4 h-4 text-blue-600" />
                <span>Tiến độ thực thi y lệnh:</span>
              </div>
              <div className="flex-1 max-w-xs bg-slate-200 rounded-full h-2.5 overflow-hidden">
                <div
                  className={`h-full transition-all duration-300 rounded-full ${
                    progressPercent >= 100
                      ? 'bg-emerald-600'
                      : progressPercent >= 50
                      ? 'bg-blue-600'
                      : 'bg-amber-500'
                  }`}
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
              <span className="font-mono-custom text-xs font-bold text-slate-700">
                {currentCheckedCount}/{totalAllOrders} ({progressPercent}%)
              </span>
            </div>

            {/* Quick Bulk Order Controls */}
            <div className="flex items-center gap-2 flex-wrap">
              <button
                type="button"
                id="btn-complete-all-orders"
                onClick={handleCompleteAll}
                className="px-2.5 py-1 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-md transition-colors cursor-pointer flex items-center gap-1"
                title="Đánh dấu tất cả y lệnh trong phác đồ đã hoàn thành"
              >
                <Check className="w-3.5 h-3.5" />
                <span>Hoàn tất tất cả</span>
              </button>

              <button
                type="button"
                id="btn-reset-orders"
                onClick={handleResetOrders}
                className="px-2 py-1 text-xs font-medium text-slate-600 hover:text-slate-900 bg-white border border-slate-200 hover:bg-slate-100 rounded-md transition-colors cursor-pointer"
                title="Bỏ chọn tất cả y lệnh"
              >
                <RotateCcw className="w-3 h-3" />
              </button>

              <button
                type="button"
                id="btn-copy-orders"
                onClick={handleCopyOrderSheet}
                className={`flex items-center gap-1.5 px-3 py-1 text-xs font-semibold rounded-md border transition-all cursor-pointer shadow-2xs ${
                  copySuccess
                    ? 'bg-emerald-600 text-white border-emerald-700'
                    : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200'
                }`}
                title="Sao chép toàn bộ y lệnh theo chuẩn EMR/HIS để dán vào hồ sơ bệnh viện"
              >
                {copySuccess ? (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    <span>Đã sao chép EMR!</span>
                  </>
                ) : (
                  <>
                    <ClipboardCopy className="w-3.5 h-3.5 text-slate-500" />
                    <span>Sao chép y lệnh (HIS)</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Section 1: Quy trình xử trí cấp cứu & Tuyến điều trị (phacDo.tuyen) */}
          <div className="bg-red-50/50 border border-red-200 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-display font-bold text-sm text-red-900 flex items-center gap-2">
                <HeartPulse className="w-4 h-4 text-red-600" />
                <span>1. Quy trình xử trí cấp cứu & Thứ tự can thiệp ưu tiên</span>
              </h4>
              <span className="text-[11px] text-red-700 font-semibold bg-red-100/80 px-2 py-0.5 rounded border border-red-200">
                Thực hiện khẩn
              </span>
            </div>

            <div className="flex flex-col gap-2">
              {phacDo.tuyen.map((item, idx) => {
                const key = `tuyen-${currentDisease.id}-${idx}`;
                const isChecked = checkedOrders.has(key);
                return (
                  <div
                    key={idx}
                    onClick={() => toggleOrder(key)}
                    className={`p-2.5 rounded-md border text-xs sm:text-sm flex items-start gap-3 cursor-pointer transition-all ${
                      isChecked
                        ? 'bg-emerald-50 border-emerald-300 text-emerald-950 font-medium'
                        : 'bg-white border-red-200/80 text-slate-800 hover:bg-red-50/40 hover:border-red-300'
                    }`}
                  >
                    <div className="mt-0.5 flex items-center justify-center shrink-0">
                      <div
                        className={`w-4 h-4 rounded flex items-center justify-center border transition-colors ${
                          isChecked
                            ? 'bg-emerald-600 border-emerald-600 text-white'
                            : 'border-slate-300 bg-white'
                        }`}
                      >
                        {isChecked && <Check className="w-3 h-3 stroke-[3]" />}
                      </div>
                    </div>

                    <div className="flex-1 flex items-start justify-between gap-2">
                      <div className="flex items-start gap-2">
                        <span className="font-mono-custom font-bold text-slate-500 text-xs shrink-0">
                          {idx + 1}.
                        </span>
                        <span className={isChecked ? 'line-through text-slate-500' : 'text-slate-800'}>
                          {item}
                        </span>
                      </div>
                      {idx === 0 && (
                        <span className="text-[10px] font-bold px-1.5 py-0.5 bg-red-100 text-red-700 rounded shrink-0 font-mono-custom">
                          ƯU TIÊN 1
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Section 2: Bảng y lệnh thuốc & Dược lâm sàng (phacDo.thuoc) */}
          <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-2xs">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded bg-blue-100 text-blue-700 flex items-center justify-center">
                  <Pill className="w-3.5 h-3.5" />
                </div>
                <div>
                  <h4 className="font-display font-bold text-sm text-slate-900">
                    2. Bảng y lệnh thuốc & Dược lâm sàng (Medical Order Sheet - Rx)
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    Chỉ định liều lượng, đường dùng và điều kiện sử dụng theo phác đồ chính thức
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setShowAddCustom(!showAddCustom)}
                className="flex items-center gap-1 px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-md transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Thêm y lệnh thuốc khác</span>
              </button>
            </div>

            {/* Custom order inline add form */}
            {showAddCustom && (
              <form
                onSubmit={handleAddCustomOrder}
                className="mb-3.5 p-3 bg-blue-50/60 border border-blue-200 rounded-lg flex flex-col sm:flex-row gap-2 items-end animate-fadeIn text-xs"
              >
                <div className="flex-1 w-full">
                  <label className="block font-semibold text-slate-700 mb-1">Tên thuốc / Hoạt chất</label>
                  <input
                    type="text"
                    required
                    value={newDrug}
                    onChange={(e) => setNewDrug(e.target.value)}
                    placeholder="VD: Paracetamol, Pantoprazol, Furosemid..."
                    className="w-full border border-slate-200 rounded p-1.5 bg-white text-xs text-slate-800"
                  />
                </div>
                <div className="flex-1 w-full">
                  <label className="block font-semibold text-slate-700 mb-1">Liều & Đường dùng</label>
                  <input
                    type="text"
                    value={newDosage}
                    onChange={(e) => setNewDosage(e.target.value)}
                    placeholder="VD: 500 mg TTM x 3 lần/ngày..."
                    className="w-full border border-slate-200 rounded p-1.5 bg-white text-xs text-slate-800"
                  />
                </div>
                <div className="flex-1 w-full">
                  <label className="block font-semibold text-slate-700 mb-1">Ghi chú điều kiện</label>
                  <input
                    type="text"
                    value={newNote}
                    onChange={(e) => setNewNote(e.target.value)}
                    placeholder="VD: Khi sốt >= 38.5°C..."
                    className="w-full border border-slate-200 rounded p-1.5 bg-white text-xs text-slate-800"
                  />
                </div>
                <div className="flex items-center gap-1.5 w-full sm:w-auto">
                  <button
                    type="submit"
                    className="px-3 py-1.5 bg-blue-600 text-white font-semibold rounded text-xs hover:bg-blue-700 cursor-pointer shadow-xs whitespace-nowrap"
                  >
                    Thêm y lệnh
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowAddCustom(false)}
                    className="px-2.5 py-1.5 bg-white border border-slate-200 text-slate-600 rounded text-xs hover:bg-slate-100 cursor-pointer"
                  >
                    Đóng
                  </button>
                </div>
              </form>
            )}

            {/* Medical Order Table */}
            <div className="overflow-x-auto border border-slate-200 rounded-lg">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50 text-slate-700 border-b border-slate-200 font-semibold">
                    <th className="p-2.5 w-10 text-center">Y lệnh</th>
                    <th className="p-2.5">Tên thuốc / Hoạt chất</th>
                    <th className="p-2.5">Liều lượng & Đường dùng</th>
                    <th className="p-2.5">Điều kiện / Ghi chú</th>
                    <th className="p-2.5 w-24 text-center">Trạng thái</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {/* Standard Protocol Drugs */}
                  {phacDo.thuoc.map(([drug, dosage, note], idx) => {
                    const key = `thuoc-${currentDisease.id}-${idx}`;
                    const isChecked = checkedOrders.has(key);
                    const isInjectable =
                      dosage.toLowerCase().includes('tm') ||
                      dosage.toLowerCase().includes('ttm') ||
                      dosage.toLowerCase().includes('tiêm') ||
                      dosage.toLowerCase().includes('tdd');

                    return (
                      <tr
                        key={idx}
                        onClick={() => toggleOrder(key)}
                        className={`cursor-pointer transition-colors ${
                          isChecked ? 'bg-emerald-50/70' : 'hover:bg-slate-50/80'
                        }`}
                      >
                        <td className="p-2.5 text-center">
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => {}}
                            className="rounded text-blue-600 cursor-pointer"
                          />
                        </td>
                        <td className="p-2.5 font-bold text-slate-900">
                          <div className="flex items-center gap-1.5">
                            {isInjectable ? (
                              <Syringe className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                            ) : (
                              <Pill className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                            )}
                            <span className={isChecked ? 'line-through text-slate-500' : ''}>
                              {drug}
                            </span>
                          </div>
                        </td>
                        <td className="p-2.5 font-mono-custom text-slate-800">
                          <span
                            className={`px-2 py-0.5 rounded font-semibold ${
                              isInjectable
                                ? 'bg-blue-50 text-blue-800 border border-blue-200'
                                : 'bg-slate-100 text-slate-800 border border-slate-200'
                            }`}
                          >
                            {dosage}
                          </span>
                        </td>
                        <td className="p-2.5 text-slate-600 italic">
                          {note || 'Theo phác đồ chuẩn'}
                        </td>
                        <td className="p-2.5 text-center">
                          {isChecked ? (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10.5px] font-bold bg-emerald-100 text-emerald-800">
                              <Check className="w-3 h-3" />
                              Đã y lệnh
                            </span>
                          ) : (
                            <span className="inline-block px-2 py-0.5 rounded-full text-[10.5px] bg-slate-100 text-slate-500">
                              Chờ duyệt
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })}

                  {/* Doctor's Custom Additions */}
                  {customOrders.map((co) => (
                    <tr
                      key={co.id}
                      onClick={() => toggleCustomOrder(co.id)}
                      className={`cursor-pointer transition-colors bg-blue-50/30 ${
                        co.completed ? 'bg-emerald-50/70' : 'hover:bg-blue-50/60'
                      }`}
                    >
                      <td className="p-2.5 text-center">
                        <input
                          type="checkbox"
                          checked={co.completed}
                          onChange={() => {}}
                          className="rounded text-blue-600 cursor-pointer"
                        />
                      </td>
                      <td className="p-2.5 font-bold text-slate-900">
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] px-1 bg-blue-600 text-white rounded font-mono-custom font-semibold">
                            BS
                          </span>
                          <span className={co.completed ? 'line-through text-slate-500' : ''}>
                            {co.drug}
                          </span>
                        </div>
                      </td>
                      <td className="p-2.5 font-mono-custom text-slate-800">
                        <span className="px-2 py-0.5 rounded bg-blue-100 text-blue-900 font-semibold">
                          {co.dosage}
                        </span>
                      </td>
                      <td className="p-2.5 text-slate-600 italic">
                        <div className="flex items-center justify-between gap-1">
                          <span>{co.note}</span>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              removeCustomOrder(co.id);
                            }}
                            className="text-slate-400 hover:text-red-600 p-1"
                            title="Xóa y lệnh tùy biến này"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      </td>
                      <td className="p-2.5 text-center">
                        {co.completed ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10.5px] font-bold bg-emerald-100 text-emerald-800">
                            <Check className="w-3 h-3" />
                            Đã y lệnh
                          </span>
                        ) : (
                          <span className="inline-block px-2 py-0.5 rounded-full text-[10.5px] bg-slate-100 text-slate-500">
                            Chờ duyệt
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Section 3: Quick Clinical Risk Calculator (CURB-65 / Killip) */}
          <div className="bg-slate-50 border border-slate-200 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2.5">
              <h4 className="font-display font-bold text-sm text-slate-800 flex items-center gap-2">
                <Calculator className="w-4 h-4 text-blue-600" />
                <span>3. Thang điểm lượng giá nguy cơ & Phân tầng xử trí nhanh</span>
              </h4>
              <button
                type="button"
                onClick={() => setShowCalculator(!showCalculator)}
                className="text-xs text-blue-600 font-semibold hover:underline cursor-pointer"
              >
                {showCalculator ? 'Ẩn bảng tính' : 'Mở rộng bảng tính chi tiết'}
              </button>
            </div>

            {/* CURB-65 Calculator for Pneumonia / Respiratory or General Sepsis */}
            {(currentDisease.id.includes('phoi') || currentDisease.id.includes('nhiem_trung') || showCalculator) && (
              <div className="bg-white border border-slate-200 rounded-lg p-3 text-xs mb-3">
                <div className="flex items-center justify-between pb-2 border-b border-slate-100 mb-2">
                  <span className="font-bold text-slate-800 flex items-center gap-1.5">
                    <span>Thang điểm CURB-65 (Viêm phổi mắc phải cộng đồng):</span>
                    <span className="font-mono-custom px-1.5 py-0.5 bg-blue-100 text-blue-800 rounded font-bold">
                      {curbScoreTotal} điểm
                    </span>
                  </span>
                  <span className="font-semibold text-slate-700">
                    Khuyến nghị:{' '}
                    <b
                      className={
                        curbScoreTotal >= 3
                          ? 'text-red-700'
                          : curbScoreTotal === 2
                          ? 'text-amber-700'
                          : 'text-emerald-700'
                      }
                    >
                      {curbScoreTotal >= 3
                        ? 'Nhập viện ICU / Khoa Hồi sức tích cực'
                        : curbScoreTotal === 2
                        ? 'Nhập viện Nội trú theo dõi sát'
                        : 'Điều trị ngoại trú an toàn'}
                    </b>
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-5 gap-2">
                  {[
                    { key: 'c', label: 'C - Rối loạn tri giác (Confusion)' },
                    { key: 'u', label: 'U - Ure > 7 mmol/L (Urea)' },
                    { key: 'r', label: 'R - Nhịp thở >= 30 l/p' },
                    { key: 'b', label: 'B - HA < 90/60 mmHg' },
                    { key: 'age', label: '65 - Tuổi >= 65' },
                  ].map((item) => (
                    <label
                      key={item.key}
                      className={`p-2 rounded border flex items-center gap-2 cursor-pointer transition-colors ${
                        curbScores[item.key as keyof typeof curbScores]
                          ? 'bg-blue-50 border-blue-300 font-semibold text-blue-900'
                          : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={curbScores[item.key as keyof typeof curbScores]}
                        onChange={(e) =>
                          setCurbScores((prev) => ({
                            ...prev,
                            [item.key]: e.target.checked,
                          }))
                        }
                        className="rounded text-blue-600"
                      />
                      <span className="text-[11px] leading-tight">{item.label}</span>
                    </label>
                  ))}
                </div>
              </div>
            )}

            {/* Killip Classification for Acute MI / Cardiac */}
            {(currentDisease.id.includes('tim') || currentDisease.nhom.includes('tim') || showCalculator) && (
              <div className="bg-white border border-slate-200 rounded-lg p-3 text-xs">
                <div className="flex items-center justify-between pb-2 border-b border-slate-100 mb-2">
                  <span className="font-bold text-slate-800 flex items-center gap-1.5">
                    <span>Phân độ Killip (Suy tim trong Nhồi máu cơ tim cấp):</span>
                    <span className="font-mono-custom px-1.5 py-0.5 bg-rose-100 text-rose-800 rounded font-bold">
                      Độ {killipClass}
                    </span>
                  </span>
                  <span className="text-slate-600">
                    Tử vong 30 ngày ước tính:{' '}
                    <b className="text-rose-700">
                      {killipClass === 'I'
                        ? '6%'
                        : killipClass === 'II'
                        ? '17%'
                        : killipClass === 'III'
                        ? '38% (Phù phổi cấp)'
                        : '67–81% (Sốc tim)'}
                    </b>
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    { val: 'I', text: 'Độ I: Không có dấu suy tim lâm sàng' },
                    { val: 'II', text: 'Độ II: Ran ẩm < 50% phế trường, T3 gallop' },
                    { val: 'III', text: 'Độ III: Phù phổi cấp nặng, ran > 50%' },
                    { val: 'IV', text: 'Độ IV: Sốc tim (HA tụt, tưới máu kém)' },
                  ].map((k) => (
                    <button
                      key={k.val}
                      type="button"
                      onClick={() => setKillipClass(k.val as any)}
                      className={`p-2 rounded border text-left cursor-pointer transition-colors ${
                        killipClass === k.val
                          ? 'bg-rose-50 border-rose-300 text-rose-900 font-bold'
                          : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      <div className="font-bold font-mono-custom">Killip {k.val}</div>
                      <div className="text-[10px] text-slate-500">{k.text}</div>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Section 4 & 5: Theo dõi diễn tiến & Cảnh báo an toàn */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Theo dõi */}
            <div className="bg-blue-50/50 border border-blue-200 rounded-lg p-4">
              <h4 className="font-display font-bold text-xs sm:text-sm text-blue-900 flex items-center gap-2 mb-2.5">
                <Activity className="w-4 h-4 text-blue-600" />
                <span>4. Chỉ tiêu theo dõi & Mục tiêu lâm sàng</span>
              </h4>
              <div className="flex flex-col gap-1.5 text-xs text-slate-800">
                {phacDo.theoDoi.map((item, idx) => {
                  const key = `theodoi-${currentDisease.id}-${idx}`;
                  const isChecked = checkedOrders.has(key);
                  return (
                    <div
                      key={idx}
                      onClick={() => toggleOrder(key)}
                      className={`p-2 rounded-md border flex items-start gap-2.5 cursor-pointer transition-colors ${
                        isChecked
                          ? 'bg-emerald-50 border-emerald-300 text-emerald-950 font-medium'
                          : 'bg-white border-blue-100 text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={() => {}}
                        className="mt-0.5 rounded text-blue-600 cursor-pointer"
                      />
                      <span className={isChecked ? 'line-through text-slate-400' : ''}>
                        {item}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Lưu ý & Cảnh báo */}
            <div className="bg-amber-50/60 border border-amber-200 rounded-lg p-4">
              <h4 className="font-display font-bold text-xs sm:text-sm text-amber-900 flex items-center gap-2 mb-2.5">
                <AlertTriangle className="w-4 h-4 text-amber-700" />
                <span>5. Cảnh báo an toàn, chống chỉ định & Lưu ý đặc biệt</span>
              </h4>
              <ul className="space-y-1.5 text-xs text-slate-800">
                {phacDo.luuY.map((item, idx) => (
                  <li key={idx} className="flex items-start gap-2 bg-white/70 p-2 rounded border border-amber-100">
                    <span className="text-amber-600 font-bold shrink-0 mt-0.5">⚠</span>
                    <span className="leading-relaxed">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Bottom Action Controls & Storage Integration */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-slate-200">
            <div className="flex items-center gap-2 flex-wrap">
              <button
                id="btn-save-protocol-postgres"
                onClick={onSaveToPostgres}
                className="flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-md cursor-pointer transition-colors shadow-xs"
              >
                <FileCheck className="w-3.5 h-3.5" />
                <span>Lưu phác đồ vào PostgreSQL</span>
              </button>

              <button
                id="btn-print-protocol-report"
                onClick={onPrintReport}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 font-medium text-xs rounded-md cursor-pointer transition-colors shadow-2xs"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>In hồ sơ bệnh án & y lệnh</span>
              </button>
            </div>

            <div className="flex items-center gap-3">
              <span className="text-[11px] text-slate-400 font-mono-custom hidden sm:inline">
                MedLens Clinical Decision Support v2.5
              </span>
              <button
                onClick={onBackToAnalysis}
                className="flex items-center gap-1 text-xs font-semibold text-blue-600 hover:underline cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Quay lại chẩn đoán</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
