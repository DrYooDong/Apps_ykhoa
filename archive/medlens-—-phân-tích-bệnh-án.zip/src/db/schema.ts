import { boolean, integer, jsonb, pgTable, serial, text, timestamp } from 'drizzle-orm/pg-core';
import { relations } from 'drizzle-orm';

// Users table (Medical staff / Doctors)
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  uid: text('uid').notNull().unique(), // Firebase UID or generated doctor ID
  email: text('email').notNull().unique(),
  name: text('name').notNull().default('Bác sĩ lâm sàng'),
  role: text('role').notNull().default('doctor'), // 'doctor' | 'specialist' | 'admin'
  passwordHash: text('password_hash'), // For JWT password credentials
  specialty: text('specialty').default('Nội tổng quát & Cấp cứu'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Patients table
export const patients = pgTable('patients', {
  id: serial('id').primaryKey(),
  patientCode: text('patient_code').notNull().unique(),
  fullName: text('full_name').notNull(),
  gender: text('gender').notNull().default('nam'), // 'nam' | 'nu' | 'khac'
  age: integer('age'),
  occupation: text('occupation'),
  phoneNumber: text('phone_number'),
  idCard: text('id_card'),
  address: text('address'),
  notes: text('notes'),
  createdByUid: text('created_by_uid'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Medical Records (Clinical Encounters & Diagnosis Analysis)
export const medicalRecords = pgTable('medical_records', {
  id: serial('id').primaryKey(),
  recordCode: text('record_code').notNull().unique(),
  patientId: integer('patient_id').references(() => patients.id),
  patientCode: text('patient_code').notNull(),
  patientName: text('patient_name').notNull(),
  gender: text('gender').notNull().default('nam'),
  age: integer('age'),
  occupation: text('occupation'),
  doctorUid: text('doctor_uid').notNull(),
  doctorName: text('doctor_name'),
  admissionReason: text('admission_reason'),
  clinicalSummary: text('clinical_summary'),
  vitals: jsonb('vitals'), // { vNhiet, vMach, vHATT, vHATTr, vTho, vSpo2 }
  labs: jsonb('labs'), // { lBC, lTC, lHct, lGlu, lTrop }
  selectedSymptoms: jsonb('selected_symptoms'), // string[]
  derivedSymptoms: jsonb('derived_symptoms'), // string[]
  negatedSymptoms: jsonb('negated_symptoms'), // string[]
  freeTexts: jsonb('free_texts'), // { cn, tt, tc, cls }
  primaryDiagnosis: jsonb('primary_diagnosis'), // { id, name, icd, percentage, score, max, alert }
  differentialDiagnoses: jsonb('differential_diagnoses'), // array of differentials
  treatmentProtocol: jsonb('treatment_protocol'), // { tuyen, thuoc, theoDoi, luuY, nguon }
  status: text('status').notNull().default('hoan_tat'), // 'dang_kham' | 'hoan_tat' | 'chuyen_vien'
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Relationships
export const patientsRelations = relations(patients, ({ many }) => ({
  records: many(medicalRecords),
}));

export const medicalRecordsRelations = relations(medicalRecords, ({ one }) => ({
  patient: one(patients, {
    fields: [medicalRecords.patientId],
    references: [patients.id],
  }),
}));
