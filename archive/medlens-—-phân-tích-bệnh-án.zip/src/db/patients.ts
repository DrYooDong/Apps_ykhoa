import { desc, eq, like, or } from 'drizzle-orm';
import { db } from './index.ts';
import { patients } from './schema.ts';

export interface CreatePatientInput {
  fullName: string;
  gender: string;
  age?: number;
  occupation?: string;
  phoneNumber?: string;
  idCard?: string;
  address?: string;
  notes?: string;
  createdByUid?: string;
}

export async function getPatients(query?: string) {
  try {
    if (query && query.trim()) {
      const q = `%${query.trim()}%`;
      return await db
        .select()
        .from(patients)
        .where(
          or(
            like(patients.fullName, q),
            like(patients.patientCode, q),
            like(patients.phoneNumber, q),
            like(patients.idCard, q)
          )
        )
        .orderBy(desc(patients.createdAt));
    }
    return await db.select().from(patients).orderBy(desc(patients.createdAt));
  } catch (error) {
    console.error('getPatients error:', error);
    throw new Error('Lỗi truy vấn danh sách bệnh nhân', { cause: error });
  }
}

export async function getPatientById(id: number) {
  try {
    const result = await db.select().from(patients).where(eq(patients.id, id)).limit(1);
    return result[0] || null;
  } catch (error) {
    console.error('getPatientById error:', error);
    throw new Error('Lỗi tìm thông tin bệnh nhân', { cause: error });
  }
}

export async function getOrCreatePatientByName(name: string, gender: string, age?: number, occupation?: string) {
  try {
    const existing = await db
      .select()
      .from(patients)
      .where(eq(patients.fullName, name))
      .limit(1);

    if (existing.length > 0) {
      return existing[0];
    }

    const patientCode = 'BN-' + new Date().getFullYear() + '-' + Math.floor(1000 + Math.random() * 9000);
    const created = await db
      .insert(patients)
      .values({
        patientCode,
        fullName: name,
        gender: gender || 'nam',
        age: age || undefined,
        occupation: occupation || undefined,
      })
      .returning();

    return created[0];
  } catch (error) {
    console.error('getOrCreatePatientByName error:', error);
    throw new Error('Lỗi tự động tạo hồ sơ bệnh nhân', { cause: error });
  }
}

export async function createPatient(data: CreatePatientInput) {
  try {
    const count = await db.select().from(patients);
    const patientCode = 'BN-' + new Date().getFullYear() + '-' + String(count.length + 1).padStart(4, '0');

    const result = await db
      .insert(patients)
      .values({
        patientCode,
        fullName: data.fullName,
        gender: data.gender || 'nam',
        age: data.age,
        occupation: data.occupation,
        phoneNumber: data.phoneNumber,
        idCard: data.idCard,
        address: data.address,
        notes: data.notes,
        createdByUid: data.createdByUid,
      })
      .returning();

    return result[0];
  } catch (error) {
    console.error('createPatient error:', error);
    throw new Error('Lỗi tạo bệnh nhân mới', { cause: error });
  }
}

export async function updatePatient(id: number, data: Partial<CreatePatientInput>) {
  try {
    const result = await db
      .update(patients)
      .set({
        ...data,
        updatedAt: new Date(),
      })
      .where(eq(patients.id, id))
      .returning();

    return result[0] || null;
  } catch (error) {
    console.error('updatePatient error:', error);
    throw new Error('Lỗi cập nhật thông tin bệnh nhân', { cause: error });
  }
}

export async function deletePatient(id: number) {
  try {
    const result = await db.delete(patients).where(eq(patients.id, id)).returning();
    return result[0] || null;
  } catch (error) {
    console.error('deletePatient error:', error);
    throw new Error('Lỗi xóa bệnh nhân', { cause: error });
  }
}
