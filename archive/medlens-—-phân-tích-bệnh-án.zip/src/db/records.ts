import { desc, eq, like, or } from 'drizzle-orm';
import { db } from './index.ts';
import { medicalRecords, patients } from './schema.ts';

export interface CreateRecordInput {
  patientId?: number;
  patientCode?: string;
  patientName: string;
  gender: string;
  age?: number;
  occupation?: string;
  doctorUid: string;
  doctorName?: string;
  admissionReason?: string;
  clinicalSummary?: string;
  vitals?: any;
  labs?: any;
  selectedSymptoms?: string[];
  derivedSymptoms?: string[];
  negatedSymptoms?: string[];
  freeTexts?: any;
  primaryDiagnosis?: any;
  differentialDiagnoses?: any;
  treatmentProtocol?: any;
  status?: string;
}

export async function getMedicalRecords(query?: string) {
  try {
    if (query && query.trim()) {
      const q = `%${query.trim()}%`;
      return await db
        .select()
        .from(medicalRecords)
        .where(
          or(
            like(medicalRecords.recordCode, q),
            like(medicalRecords.patientName, q),
            like(medicalRecords.patientCode, q),
            like(medicalRecords.admissionReason, q)
          )
        )
        .orderBy(desc(medicalRecords.createdAt));
    }

    return await db.select().from(medicalRecords).orderBy(desc(medicalRecords.createdAt));
  } catch (error) {
    console.error('getMedicalRecords error:', error);
    throw new Error('Lỗi truy vấn hồ sơ bệnh án', { cause: error });
  }
}

export async function getMedicalRecordById(id: number) {
  try {
    const result = await db.select().from(medicalRecords).where(eq(medicalRecords.id, id)).limit(1);
    return result[0] || null;
  } catch (error) {
    console.error('getMedicalRecordById error:', error);
    throw new Error('Lỗi tìm hồ sơ bệnh án', { cause: error });
  }
}

export async function createMedicalRecord(data: CreateRecordInput) {
  try {
    // Generate record code e.g. BA-2026-0001
    const count = await db.select().from(medicalRecords);
    const recordCode = 'BA-' + new Date().getFullYear() + '-' + String(count.length + 1).padStart(4, '0');

    let patientId = data.patientId;
    let patientCode = data.patientCode;

    // If patientId is not provided, ensure patient exists in patients table
    if (!patientId) {
      const existing = await db
        .select()
        .from(patients)
        .where(eq(patients.fullName, data.patientName))
        .limit(1);

      if (existing.length > 0) {
        patientId = existing[0].id;
        patientCode = existing[0].patientCode;
      } else {
        const pCount = await db.select().from(patients);
        patientCode = 'BN-' + new Date().getFullYear() + '-' + String(pCount.length + 1).padStart(4, '0');
        const newPatient = await db
          .insert(patients)
          .values({
            patientCode,
            fullName: data.patientName,
            gender: data.gender || 'nam',
            age: data.age,
            occupation: data.occupation,
            createdByUid: data.doctorUid,
          })
          .returning();
        patientId = newPatient[0].id;
      }
    }

    const inserted = await db
      .insert(medicalRecords)
      .values({
        recordCode,
        patientId,
        patientCode: patientCode || 'BN-UNKNOWN',
        patientName: data.patientName,
        gender: data.gender,
        age: data.age,
        occupation: data.occupation,
        doctorUid: data.doctorUid,
        doctorName: data.doctorName || 'Bác sĩ trực',
        admissionReason: data.admissionReason,
        clinicalSummary: data.clinicalSummary,
        vitals: data.vitals || {},
        labs: data.labs || {},
        selectedSymptoms: data.selectedSymptoms || [],
        derivedSymptoms: data.derivedSymptoms || [],
        negatedSymptoms: data.negatedSymptoms || [],
        freeTexts: data.freeTexts || {},
        primaryDiagnosis: data.primaryDiagnosis || null,
        differentialDiagnoses: data.differentialDiagnoses || [],
        treatmentProtocol: data.treatmentProtocol || null,
        status: data.status || 'hoan_tat',
      })
      .returning();

    return inserted[0];
  } catch (error) {
    console.error('createMedicalRecord error:', error);
    throw new Error('Lỗi lưu trữ bệnh án vào CSDL', { cause: error });
  }
}

export async function deleteMedicalRecord(id: number) {
  try {
    const result = await db.delete(medicalRecords).where(eq(medicalRecords.id, id)).returning();
    return result[0] || null;
  } catch (error) {
    console.error('deleteMedicalRecord error:', error);
    throw new Error('Lỗi xóa hồ sơ bệnh án', { cause: error });
  }
}
