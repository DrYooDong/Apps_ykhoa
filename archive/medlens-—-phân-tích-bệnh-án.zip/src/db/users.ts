import { eq } from 'drizzle-orm';
import bcrypt from 'bcryptjs';
import { db } from './index.ts';
import { users } from './schema.ts';

export async function getOrCreateUser(uid: string, email: string, name?: string) {
  try {
    const existing = await db.select().from(users).where(eq(users.uid, uid)).limit(1);
    if (existing.length > 0) {
      return existing[0];
    }

    const inserted = await db
      .insert(users)
      .values({
        uid,
        email,
        name: name || email.split('@')[0],
        role: 'doctor',
      })
      .returning();

    return inserted[0];
  } catch (error) {
    console.error('getOrCreateUser error:', error);
    throw new Error('Không thể xử lý thông tin người dùng trong CSDL', { cause: error });
  }
}

export async function findUserByEmail(email: string) {
  try {
    const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
    return result[0] || null;
  } catch (error) {
    console.error('findUserByEmail error:', error);
    throw new Error('Lỗi truy vấn người dùng', { cause: error });
  }
}

export async function registerDoctor(params: {
  email: string;
  password: string;
  name: string;
  role?: string;
  specialty?: string;
}) {
  try {
    const existing = await findUserByEmail(params.email);
    if (existing) {
      throw new Error('Email đã được đăng ký trong hệ thống');
    }

    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(params.password, salt);
    const uid = 'dr_' + Date.now().toString(36) + Math.random().toString(36).substring(2, 6);

    const inserted = await db
      .insert(users)
      .values({
        uid,
        email: params.email,
        name: params.name,
        role: params.role || 'doctor',
        passwordHash,
        specialty: params.specialty || 'Nội tổng quát & Cấp cứu',
      })
      .returning();

    return inserted[0];
  } catch (error: any) {
    console.error('registerDoctor error:', error);
    throw new Error(error.message || 'Lỗi tạo tài khoản bác sĩ', { cause: error });
  }
}

export async function verifyDoctorCredentials(email: string, passwordPlain: string) {
  try {
    const user = await findUserByEmail(email);
    if (!user || !user.passwordHash) {
      return null;
    }

    const isMatch = await bcrypt.compare(passwordPlain, user.passwordHash);
    if (!isMatch) {
      return null;
    }

    return user;
  } catch (error) {
    console.error('verifyDoctorCredentials error:', error);
    return null;
  }
}

export async function seedDefaultDoctor() {
  try {
    const defaultEmail = 'dr.minh@medlens.vn';
    const existing = await findUserByEmail(defaultEmail);
    if (!existing) {
      await registerDoctor({
        email: defaultEmail,
        password: 'Doctor@123',
        name: 'BS. CKII Nguyễn Tuấn Minh',
        role: 'doctor',
        specialty: 'Khoa Cấp cứu - Hồi sức tích cực',
      });
      console.log('Đã khởi tạo tài khoản Bác sĩ mẫu: dr.minh@medlens.vn / Doctor@123');
    }
  } catch (error) {
    console.warn('Lưu ý khi khởi tạo bác sĩ mẫu (bỏ qua nếu đã tồn tại):', error);
  }
}
