export type Gender = 'nam' | 'nu' | 'khac';
export type RoleType = 'dt' | 'gy' | 'ht' | 'loaitru'; // đặc trưng, gợi ý, hỗ trợ, loại trừ
export type CategoryType = 'cn' | 'tt' | 'tc' | 'cls'; // cơ năng, thực thể, tiền căn, cận lâm sàng

export interface ThresholdMap {
  fld: string;
  op: '>=' | '>' | '<=' | '<';
  val?: number;
  valNu?: number;
  valNam?: number;
}

export interface TrieuChung {
  id: string;
  ten: string;
  nhom: string;
  loai: CategoryType[];
  tuKhoa: string[];
  map: ThresholdMap | null;
}

export interface DanSo {
  gioiTinh: 'any' | 'nam' | 'nu';
  tuoiMin?: number | null;
  tuoiMax?: number | null;
}

export interface PhacDo {
  tuyen: string[];
  thuoc: [string, string, string][]; // [Tên thuốc, Liều / đường dùng, Ghi chú]
  theoDoi: string[];
  luuY: string[];
  nguon: string[];
}

export interface Benh {
  id: string;
  ten: string;
  icd: string;
  nhom: string;
  baoDong: boolean;
  ghiChuBaoDong: string;
  tomTat: string;
  danSo: DanSo;
  dd: [string, number, RoleType][]; // [trieuChungId, weight, role]
  phacDo: PhacDo;
}

export interface KnowledgeBase {
  meta: {
    ten: string;
    phienBan: number;
    capNhat: string;
  };
  trieuChung: TrieuChung[];
  benh: Benh[];
}

export interface ClinicalFormState {
  gioiTinh: Gender;
  tuoi: string;
  ngheNghiep: string;
  lyDo: string;
  text: {
    cn: string;
    tt: string;
    tc: string;
    cls: string;
  };
}

export interface VitalsState {
  vNhiet: string;
  vMach: string;
  vHATT: string;
  vHATTr: string;
  vTho: string;
  vSpo2: string;
}

export interface LabsState {
  lBC: string;
  lTC: string;
  lHct: string;
  lGlu: string;
  lTrop: string;
}

export interface MatchedEvidence {
  tc: TrieuChung;
  w: number;
  role: RoleType;
  via: 'chọn' | '⚙ tự suy' | 'mô tả';
}

export interface MissingEvidence {
  tc: TrieuChung;
  w: number;
  role: RoleType;
}

export interface AnalysisResult {
  b: Benh;
  pct: number;
  score: number;
  max: number;
  matched: MatchedEvidence[];
  missing: MissingEvidence[];
  notes: string[];
}

// Backend Entity Types
export interface DoctorUser {
  uid: string;
  email: string;
  name: string;
  role: string;
  specialty?: string;
}

export interface Patient {
  id: number;
  patientCode: string;
  fullName: string;
  gender: string;
  age?: number;
  occupation?: string;
  phoneNumber?: string;
  idCard?: string;
  address?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface MedicalRecord {
  id: number;
  recordCode: string;
  patientId?: number;
  patientCode: string;
  patientName: string;
  gender: string;
  age?: number;
  occupation?: string;
  doctorUid: string;
  doctorName?: string;
  admissionReason?: string;
  clinicalSummary?: string;
  vitals?: Partial<VitalsState>;
  labs?: Partial<LabsState>;
  selectedSymptoms?: string[];
  derivedSymptoms?: string[];
  negatedSymptoms?: string[];
  freeTexts?: { cn: string; tt: string; tc: string; cls: string };
  primaryDiagnosis?: {
    id: string;
    name: string;
    icd: string;
    percentage: number;
    score: number;
    max: number;
    alert?: boolean;
  };
  differentialDiagnoses?: Array<{
    id: string;
    name: string;
    icd: string;
    percentage: number;
  }>;
  treatmentProtocol?: PhacDo;
  status: string;
  createdAt: string;
  updatedAt: string;
}
