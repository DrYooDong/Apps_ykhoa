import React, { useMemo, useState } from 'react';
import { AuthProvider } from './context/AuthContext.tsx';
import { Header } from './components/Header.tsx';
import { StepNav, TabId } from './components/StepNav.tsx';
import { Step1DataIngestion } from './components/Step1DataIngestion.tsx';
import { Step2Analysis } from './components/Step2Analysis.tsx';
import { Step3Protocol } from './components/Step3Protocol.tsx';
import { Step4KnowledgeBase } from './components/Step4KnowledgeBase.tsx';
import { PatientRecordsModal } from './components/PatientRecordsModal.tsx';
import { AuthModal } from './components/AuthModal.tsx';
import { AboutModal } from './components/AboutModal.tsx';
import { PrintReportModal } from './components/PrintReportModal.tsx';
import { DEFAULT_KNOWLEDGE_BASE, SampleCase } from './data/seedData.ts';
import {
  ClinicalFormState,
  KnowledgeBase,
  LabsState,
  MedicalRecord,
  TrieuChung,
  VitalsState,
} from './types.ts';
import {
  analyzeClinicalCase,
  computeAllDerived,
  normalizeText,
} from './lib/clinicalEngine.ts';

const initialForm: ClinicalFormState = {
  gioiTinh: 'nam',
  tuoi: '58',
  ngheNghiep: 'Tài xế',
  lyDo: 'Đau ngực dữ dội',
  text: {
    cn: '',
    tt: '',
    tc: '',
    cls: '',
  },
};

const initialVitals: VitalsState = {
  vNhiet: '37.0',
  vMach: '95',
  vHATT: '135',
  vHATTr: '85',
  vTho: '20',
  vSpo2: '96',
};

const initialLabs: LabsState = {
  lBC: '9.2',
  lTC: '230',
  lHct: '41',
  lGlu: '6.2',
  lTrop: '45',
};

export function MainApp() {
  const [kb, setKb] = useState<KnowledgeBase>(DEFAULT_KNOWLEDGE_BASE);
  const [currentTab, setCurrentTab] = useState<TabId>('t1');
  const [completedSteps, setCompletedSteps] = useState<Set<TabId>>(new Set());

  // Clinical input states
  const [form, setForm] = useState<ClinicalFormState>(initialForm);
  const [vitals, setVitals] = useState<VitalsState>(initialVitals);
  const [labs, setLabs] = useState<LabsState>(initialLabs);
  const [selected, setSelected] = useState<Set<string>>(
    new Set(['dau_nguc_sau_xuong_uc', 'va_mo_hoi', 'kho_tho', 'tang_huyet_ap'])
  );
  const [negated, setNegated] = useState<Set<string>>(new Set(['sot']));

  // Protocol tab selection
  const [selectedDiseaseId, setSelectedDiseaseId] = useState<string | null>('nmct_stemi');

  // Modals state
  const [isRecordsOpen, setIsRecordsOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isAboutOpen, setIsAboutOpen] = useState(false);
  const [isPrintOpen, setIsPrintOpen] = useState(false);

  // Derived auto-symptoms from vitals and labs
  const { derived, vitalsList: derivedVitalsList, labsList: derivedLabsList } = useMemo(() => {
    return computeAllDerived(kb, vitals, labs, form.gioiTinh, selected);
  }, [kb, vitals, labs, form.gioiTinh, selected]);

  // Real-time Deduction Engine calculation
  const results = useMemo(() => {
    return analyzeClinicalCase(kb, form, selected, derived, negated);
  }, [kb, form, selected, derived, negated]);

  // Dynamic clinical summary text
  const summaryText = useMemo(() => {
    const parts: string[] = [];
    const ageStr = form.tuoi ? `${form.tuoi} tuổi` : '';
    const genderStr = form.gioiTinh === 'nam' ? 'Nam' : form.gioiTinh === 'nu' ? 'Nữ' : 'chưa rõ giới tính';
    const jobStr = form.ngheNghiep ? `, nghề nghiệp ${form.ngheNghiep}` : '';
    const reasonStr = form.lyDo ? `, vào viện vì ${form.lyDo}` : '';

    parts.push(`Bệnh nhân ${genderStr} ${ageStr}${jobStr}${reasonStr}.`);

    const vocabMap = new Map<string, TrieuChung>(kb.trieuChung.map((t) => [t.id, t]));
    const posNames = [...selected, ...derived].map((id) => vocabMap.get(id)?.ten || id);
    if (posNames.length > 0) {
      parts.push(`Ghi nhận các triệu chứng & dấu chứng dương tính: ${posNames.join(', ')}.`);
    }

    if (negated.size > 0) {
      const negNames = [...negated].map((id) => vocabMap.get(id)?.ten || id);
      parts.push(`Dữ kiện âm tính có giá trị loại trừ: không có ${negNames.join(', ')}.`);
    }

    const vitalsSummary: string[] = [];
    if (vitals.vNhiet) vitalsSummary.push(`T: ${vitals.vNhiet}°C`);
    if (vitals.vMach) vitalsSummary.push(`Mạch: ${vitals.vMach} l/p`);
    if (vitals.vHATT && vitals.vHATTr) vitalsSummary.push(`HA: ${vitals.vHATT}/${vitals.vHATTr} mmHg`);
    if (vitals.vTho) vitalsSummary.push(`NT: ${vitals.vTho} l/p`);
    if (vitals.vSpo2) vitalsSummary.push(`SpO₂: ${vitals.vSpo2}%`);

    if (vitalsSummary.length > 0) {
      parts.push(`Sinh hiệu: ${vitalsSummary.join(', ')}.`);
    }

    if (results.length > 0) {
      parts.push(
        `Nghĩ nhiều đến ${results[0].b.ten} (${results[0].b.icd}) với độ phù hợp ${results[0].pct}%.`
      );
    }

    return parts.join(' ');
  }, [form, selected, derived, negated, vitals, results, kb]);

  // Handlers
  const handleRunAnalysis = () => {
    setCompletedSteps((prev) => new Set(prev).add('t1').add('t2'));
    if (results.length > 0) {
      setSelectedDiseaseId(results[0].b.id);
    }
    setCurrentTab('t2');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleReset = () => {
    if (!confirm('Bạn có chắc muốn xóa tất cả dữ liệu bệnh án hiện tại để nhập ca mới?')) return;
    setForm({
      gioiTinh: 'nam',
      tuoi: '',
      ngheNghiep: '',
      lyDo: '',
      text: { cn: '', tt: '', tc: '', cls: '' },
    });
    setVitals({
      vNhiet: '',
      vMach: '',
      vHATT: '',
      vHATTr: '',
      vTho: '',
      vSpo2: '',
    });
    setLabs({
      lBC: '',
      lTC: '',
      lHct: '',
      lGlu: '',
      lTrop: '',
    });
    setSelected(new Set());
    setNegated(new Set());
    setCompletedSteps(new Set());
    setCurrentTab('t1');
  };

  const handleLoadSample = (sample: SampleCase) => {
    setForm({
      gioiTinh: sample.form.gioiTinh,
      tuoi: sample.form.tuoi,
      ngheNghiep: sample.form.ngheNghiep,
      lyDo: sample.form.lyDo,
      text: { ...sample.form.text },
    });
    if (sample.vitals) setVitals({ ...initialVitals, ...sample.vitals });
    if (sample.labs) setLabs({ ...initialLabs, ...sample.labs });
    if (sample.selected) setSelected(new Set(sample.selected));
    else if (sample.sel) setSelected(new Set(sample.sel));
    if (sample.negated) setNegated(new Set(sample.negated));
    else setNegated(new Set());
    setCompletedSteps(new Set(['t1', 't2']));
  };

  const handleExportCase = () => {
    const caseData = {
      version: 'medlens-1.0',
      timestamp: new Date().toISOString(),
      form,
      vitals,
      labs,
      selected: Array.from(selected),
      negated: Array.from(negated),
      summaryText,
    };
    const blob = new Blob([JSON.stringify(caseData, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `medlens-case-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportCase = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = JSON.parse(e.target?.result as string);
        if (data.form) setForm(data.form);
        if (data.vitals) setVitals(data.vitals);
        if (data.labs) setLabs(data.labs);
        if (data.selected) setSelected(new Set(data.selected));
        if (data.negated) setNegated(new Set(data.negated));
        setCompletedSteps(new Set(['t1', 't2']));
      } catch (err) {
        alert('File không hợp lệ: ' + (err as Error).message);
      }
    };
    reader.readAsText(file);
  };

  const handleExportKB = () => {
    const blob = new Blob([JSON.stringify(kb, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `medlens-kb-export-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportKB = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = JSON.parse(e.target?.result as string);
        if (data.benh && data.trieuChung) {
          setKb(data);
          alert(`Đã nạp thành công Kho tri thức: ${data.benh.length} bệnh, ${data.trieuChung.length} triệu chứng.`);
        } else {
          alert('Cấu trúc file Kho tri thức không đúng định dạng.');
        }
      } catch (err) {
        alert('Lỗi đọc file: ' + (err as Error).message);
      }
    };
    reader.readAsText(file);
  };

  const handleGoToProtocol = (diseaseId: string) => {
    setSelectedDiseaseId(diseaseId);
    setCompletedSteps((prev) => new Set(prev).add('t3'));
    setCurrentTab('t3');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleLoadRecordToState = (record: MedicalRecord) => {
    setForm((prev) => ({
      ...prev,
      tuoi: record.age ? String(record.age) : '',
      gioiTinh: (record.gender || 'nam') as any,
      lyDo: record.admissionReason || prev.lyDo,
      text: (record.freeTexts as any) || prev.text,
    }));
    if (record.vitals) setVitals((prev) => ({ ...prev, ...(record.vitals as any) }));
    if (record.labs) setLabs((prev) => ({ ...prev, ...(record.labs as any) }));
    if (record.selectedSymptoms) setSelected(new Set(record.selectedSymptoms));
    if (record.negatedSymptoms) setNegated(new Set(record.negatedSymptoms));
    if (record.primaryDiagnosis?.id) setSelectedDiseaseId(record.primaryDiagnosis.id);

    setCompletedSteps(new Set(['t1', 't2']));
    setCurrentTab('t2');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans antialiased">
      {/* App Header */}
      <Header
        kb={kb}
        onOpenKB={() => setCurrentTab('t4')}
        onOpenRecords={() => setIsRecordsOpen(true)}
        onOpenAuth={() => setIsAuthOpen(true)}
        onOpenAbout={() => setIsAboutOpen(true)}
        onExportKB={handleExportKB}
      />

      {/* 4-Step Navigation */}
      <StepNav
        currentTab={currentTab}
        completedSteps={completedSteps}
        onSelectTab={setCurrentTab}
      />

      {/* Main View Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-5">
        {currentTab === 't1' && (
          <Step1DataIngestion
            kb={kb}
            form={form}
            setForm={setForm}
            vitals={vitals}
            setVitals={setVitals}
            labs={labs}
            setLabs={setLabs}
            selected={selected}
            setSelected={setSelected}
            derived={derived}
            setDerived={() => {}}
            negated={negated}
            setNegated={setNegated}
            derivedVitalsList={derivedVitalsList}
            derivedLabsList={derivedLabsList}
            liveResults={results}
            onRunAnalysis={handleRunAnalysis}
            onReset={handleReset}
            onLoadSample={handleLoadSample}
            onExportCase={handleExportCase}
            onImportCase={handleImportCase}
            onSaveToPostgres={() => setIsRecordsOpen(true)}
            summaryText={summaryText}
          />
        )}

        {currentTab === 't2' && (
          <Step2Analysis
            kb={kb}
            results={results}
            form={form}
            vitals={vitals}
            labs={labs}
            selectedCount={selected.size}
            derivedCount={derived.size}
            negatedCount={negated.size}
            onGoToProtocol={handleGoToProtocol}
            onSaveToPostgres={() => setIsRecordsOpen(true)}
            onPrintReport={() => setIsPrintOpen(true)}
          />
        )}

        {currentTab === 't3' && (
          <Step3Protocol
            kb={kb}
            selectedDiseaseId={selectedDiseaseId}
            onSelectDisease={setSelectedDiseaseId}
            onBackToAnalysis={() => setCurrentTab('t2')}
            onSaveToPostgres={() => setIsRecordsOpen(true)}
            onPrintReport={() => setIsPrintOpen(true)}
            form={form}
            vitals={vitals}
            labs={labs}
          />
        )}

        {currentTab === 't4' && (
          <Step4KnowledgeBase
            kb={kb}
            onExportKB={handleExportKB}
            onImportKB={handleImportKB}
            onGoToProtocol={handleGoToProtocol}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="h-9 bg-white border-t border-slate-200 flex items-center justify-between px-4 sm:px-6 shrink-0 text-xs text-slate-500 no-print">
        <div className="max-w-7xl w-full mx-auto flex items-center justify-between gap-4">
          <div className="flex items-center gap-4 text-[11px]">
            <span className="flex items-center gap-1.5 font-medium text-slate-600">
              <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></span> Backend: Node.js/Express + PostgreSQL
            </span>
            <span className="hidden sm:flex items-center gap-1.5 font-medium text-slate-600">
              <span className="w-1.5 h-1.5 bg-blue-500 rounded-full"></span> Frontend: React/TypeScript
            </span>
          </div>
          <div className="text-[11px] text-slate-400 font-medium">
            MedLens Pro · High Density Clinical Core · Chuẩn Bộ Y tế
          </div>
        </div>
      </footer>

      {/* Modals */}
      <PatientRecordsModal
        isOpen={isRecordsOpen}
        onClose={() => setIsRecordsOpen(false)}
        onLoadRecordToState={handleLoadRecordToState}
        currentAnalysisData={{
          form,
          vitals,
          labs,
          selected,
          negated,
          results,
          summaryText,
        }}
      />

      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
      />

      <AboutModal
        isOpen={isAboutOpen}
        onClose={() => setIsAboutOpen(false)}
      />

      <PrintReportModal
        isOpen={isPrintOpen}
        onClose={() => setIsPrintOpen(false)}
        form={form}
        vitals={vitals}
        labs={labs}
        results={results}
        kb={kb}
        summaryText={summaryText}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
