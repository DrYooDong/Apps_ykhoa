import { Request, Response, NextFunction } from 'express';
import { verifyUserToken } from '../lib/jwt.ts';
import { adminAuth } from '../lib/firebase-admin.ts';

export interface AuthUser {
  uid: string;
  email: string;
  name: string;
  role: string;
  specialty?: string;
}

export interface AuthRequest extends Request {
  user?: AuthUser;
}

export const requireAuth = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Chưa xác thực: Thiếu JWT Token' });
  }

  const token = authHeader.split('Bearer ')[1];
  if (!token) {
    return res.status(401).json({ error: 'Chưa xác thực: Token không hợp lệ' });
  }

  // 1. Try verifying with local JWT
  const jwtPayload = verifyUserToken(token);
  if (jwtPayload) {
    req.user = jwtPayload;
    return next();
  }

  // 2. Try verifying with Firebase Admin
  try {
    const decodedToken = await adminAuth.verifyIdToken(token);
    req.user = {
      uid: decodedToken.uid,
      email: decodedToken.email || '',
      name: decodedToken.name || (decodedToken.email ? decodedToken.email.split('@')[0] : 'Bác sĩ'),
      role: 'doctor',
      specialty: 'Đa khoa & Cấp cứu',
    };
    return next();
  } catch (error) {
    console.error('Lỗi xác thực Token:', error);
    return res.status(401).json({ error: 'Chưa xác thực: Token đã hết hạn hoặc không hợp lệ' });
  }
};
