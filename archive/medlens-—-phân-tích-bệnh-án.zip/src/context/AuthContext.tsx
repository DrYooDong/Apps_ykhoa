import React, { createContext, useContext, useEffect, useState } from 'react';
import { signInWithPopup } from 'firebase/auth';
import { auth, googleAuthProvider } from '../lib/firebase.ts';
import { DoctorUser } from '../types.ts';
import {
  apiGetMe,
  apiGoogleAuthSync,
  apiLogin,
  apiRegister,
  getStoredToken,
  removeStoredToken,
} from '../lib/api.ts';

interface AuthContextType {
  user: DoctorUser | null;
  token: string | null;
  isLoading: boolean;
  loginWithPassword: (email: string, pass: string) => Promise<void>;
  registerDoctor: (email: string, pass: string, name: string, specialty?: string) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<DoctorUser | null>(null);
  const [token, setToken] = useState<string | null>(getStoredToken());
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Initialize session on mount
  useEffect(() => {
    async function checkAuth() {
      const stored = getStoredToken();
      if (stored) {
        try {
          const userData = await apiGetMe();
          if (userData) {
            setUser(userData);
          } else {
            setToken(null);
          }
        } catch (e) {
          console.error('Session expired or invalid:', e);
          removeStoredToken();
          setToken(null);
        }
      } else {
        // Auto-login default demo doctor for quick evaluation if user hasn't logged in yet
        try {
          const res = await apiLogin('dr.minh@medlens.vn', 'Doctor@123');
          setUser(res.user);
          setToken(res.token);
        } catch (err) {
          // Ignore auto-seed fallback error
        }
      }
      setIsLoading(false);
    }
    checkAuth();
  }, []);

  const loginWithPassword = async (email: string, pass: string) => {
    setIsLoading(true);
    try {
      const res = await apiLogin(email, pass);
      setUser(res.user);
      setToken(res.token);
    } finally {
      setIsLoading(false);
    }
  };

  const registerDoctor = async (email: string, pass: string, name: string, specialty?: string) => {
    setIsLoading(true);
    try {
      const res = await apiRegister(email, pass, name, specialty);
      setUser(res.user);
      setToken(res.token);
    } finally {
      setIsLoading(false);
    }
  };

  const loginWithGoogle = async () => {
    setIsLoading(true);
    try {
      const result = await signInWithPopup(auth, googleAuthProvider);
      const gUser = result.user;
      const res = await apiGoogleAuthSync(
        gUser.uid,
        gUser.email || `${gUser.uid}@hospital.vn`,
        gUser.displayName || 'Bác sĩ Google'
      );
      setUser(res.user);
      setToken(res.token);
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    removeStoredToken();
    setUser(null);
    setToken(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isLoading,
        loginWithPassword,
        registerDoctor,
        loginWithGoogle,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
