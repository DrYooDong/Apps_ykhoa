import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'medlens-default-secret-jwt-key-2026';

export interface JwtUserPayload {
  uid: string;
  email: string;
  name: string;
  role: string;
  specialty?: string;
}

export function signUserToken(payload: JwtUserPayload): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: '7d' });
}

export function verifyUserToken(token: string): JwtUserPayload | null {
  try {
    return jwt.verify(token, JWT_SECRET) as JwtUserPayload;
  } catch (err) {
    return null;
  }
}
