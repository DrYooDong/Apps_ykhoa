import { DoctorUser, MedicalRecord, Patient } from '../types.ts';

const TOKEN_KEY = 'medlens_jwt_token';

export function getStoredToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setStoredToken(token: string): void {
  localStorage.setItem(TOKEN_KEY, token);
}

export function removeStoredToken(): void {
  localStorage.removeItem(TOKEN_KEY);
}

async function apiRequest<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = getStoredToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string>),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(endpoint, {
    ...options,
    headers,
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
  }

  return response.json();
}

// Auth API
export async function apiLogin(email: string, password: string): Promise<{ token: string; user: DoctorUser }> {
  const result = await apiRequest<{ token: string; user: DoctorUser }>('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email, password }),
  });
  if (result.token) {
    setStoredToken(result.token);
  }
  return result;
}

export async function apiRegister(
  email: string,
  password: string,
  name: string,
  specialty?: string
): Promise<{ token: string; user: DoctorUser }> {
  const result = await apiRequest<{ token: string; user: DoctorUser }>('/api/auth/register', {
    method: 'POST',
    body: JSON.stringify({ email, password, name, specialty }),
  });
  if (result.token) {
    setStoredToken(result.token);
  }
  return result;
}

export async function apiGoogleAuthSync(
  uid: string,
  email: string,
  name: string
): Promise<{ token: string; user: DoctorUser }> {
  const result = await apiRequest<{ token: string; user: DoctorUser }>('/api/auth/google', {
    method: 'POST',
    body: JSON.stringify({ uid, email, name }),
  });
  if (result.token) {
    setStoredToken(result.token);
  }
  return result;
}

export async function apiGetMe(): Promise<DoctorUser | null> {
  try {
    const token = getStoredToken();
    if (!token) return null;
    const res = await apiRequest<{ user: DoctorUser }>('/api/auth/me');
    return res.user || null;
  } catch (err) {
    removeStoredToken();
    return null;
  }
}

// Patients API
export async function apiGetPatients(q?: string): Promise<Patient[]> {
  const query = q ? `?q=${encodeURIComponent(q)}` : '';
  return apiRequest<Patient[]>(`/api/patients${query}`);
}

export async function apiGetPatientById(id: number): Promise<Patient> {
  return apiRequest<Patient>(`/api/patients/${id}`);
}

export async function apiCreatePatient(data: Partial<Patient>): Promise<Patient> {
  return apiRequest<Patient>('/api/patients', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export async function apiUpdatePatient(id: number, data: Partial<Patient>): Promise<Patient> {
  return apiRequest<Patient>(`/api/patients/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  });
}

export async function apiDeletePatient(id: number): Promise<{ success: boolean }> {
  return apiRequest<{ success: boolean }>(`/api/patients/${id}`, {
    method: 'DELETE',
  });
}

// Medical Records API
export async function apiGetMedicalRecords(q?: string): Promise<MedicalRecord[]> {
  const query = q ? `?q=${encodeURIComponent(q)}` : '';
  return apiRequest<MedicalRecord[]>(`/api/records${query}`);
}

export async function apiGetMedicalRecordById(id: number): Promise<MedicalRecord> {
  return apiRequest<MedicalRecord>(`/api/records/${id}`);
}

export async function apiSaveMedicalRecord(data: any): Promise<MedicalRecord> {
  return apiRequest<MedicalRecord>('/api/records', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export async function apiDeleteMedicalRecord(id: number): Promise<{ success: boolean }> {
  return apiRequest<{ success: boolean }>(`/api/records/${id}`, {
    method: 'DELETE',
  });
}
