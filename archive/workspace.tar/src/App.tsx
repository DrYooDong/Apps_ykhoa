import { useState, useMemo } from 'react';
import type { CaseStudy, KnowledgeEntry, Finding } from './types';
import { useCases, useKnowledge } from './hooks/useStorage';
import ChestXRayCanvas from './components/ChestXRayCanvas';
import AbdomenXRayCanvas from './components/AbdomenXRayCanvas';
import {
  Stethoscope, BookOpen, Plus, Search, Trash2, Copy, Edit3,
  ChevronRight, X, Save, Eye, EyeOff, ZoomIn, ZoomOut, RotateCcw,
  Sun, Moon, Brain, FileText, FolderOpen, Tag, Calendar,
  AlertTriangle, CheckCircle, Info, ChevronDown, ChevronUp,
  Layout, Grid3X3, List
} from 'lucide-react';

type Tab = 'viewer' | 'cases' | 'knowledge';
type CaseView = 'list' | 'detail' | 'edit';

function severityColor(s: string) {
  switch (s) {
    case 'critical': return 'text-red-400 bg-red-500/10 border-red-500/30';
    case 'severe': return 'text-orange-400 bg-orange-500/10 border-orange-500/30';
    case 'moderate': return 'text-yellow-400 bg-yellow-500/10 border-yellow-500/30';
    default: return 'text-green-400 bg-green-500/10 border-green-500/30';
  }
}

function severityLabel(s: string) {
  switch (s) {
    case 'critical': return 'Nguy kịch';
    case 'severe': return 'Nặng';
    case 'moderate': return 'Trung bình';
    default: return 'Nhẹ';
  }
}

function examTypeLabel(t: string) {
  switch (t) {
    case 'chest_pa': return 'Ngực thẳng (PA)';
    case 'chest_lateral': return 'Ngực nghiêng';
    case 'abdomen_supine': return 'Bụng nằm ngửa';
    case 'abdomen_erect': return 'Bụng đứng';
    default: return t;
  }
}

export default function App() {
  const { cases, addCase, updateCase, deleteCase, duplicateCase } = useCases();
  const { entries, addEntry, updateEntry, deleteEntry } = useKnowledge();
  
  const [activeTab, setActiveTab] = useState<Tab>('viewer');
  const [selectedCase, setSelectedCase] = useState<CaseStudy | null>(null);
  const [caseView, setCaseView] = useState<CaseView>('list');
  const [activeFinding, setActiveFinding] = useState<string | null>(null);
  const [showOverlay, setShowOverlay] = useState(true);
  const [zoom, setZoom] = useState(1);
  const [brightness, setBrightness] = useState(0);
  const [contrast, setContrast] = useState(0);
  const [inverted, setInverted] = useState(false);
  const [searchCases, setSearchCases] = useState('');
  const [searchKnowledge, setSearchKnowledge] = useState('');
  const [expandedFinding, setExpandedFinding] = useState<string | null>(null);
  const [editingCase, setEditingCase] = useState<CaseStudy | null>(null);
  const [editingKnowledge, setEditingKnowledge] = useState<KnowledgeEntry | null>(null);
  const [knowledgeView, setKnowledgeView] = useState<'list' | 'edit'>('list');

  const filteredCases = useMemo(() => {
    if (!searchCases) return cases;
    const q = searchCases.toLowerCase();
    return cases.filter(c =>
      c.title.toLowerCase().includes(q) ||
      c.diagnosis.toLowerCase().includes(q) ||
      c.tags.some(t => t.toLowerCase().includes(q)) ||
      c.clinicalHistory.toLowerCase().includes(q)
    );
  }, [cases, searchCases]);

  const filteredKnowledge = useMemo(() => {
    if (!searchKnowledge) return entries;
    const q = searchKnowledge.toLowerCase();
    return entries.filter(e =>
      e.title.toLowerCase().includes(q) ||
      e.content.toLowerCase().includes(q) ||
      e.category.toLowerCase().includes(q) ||
      e.tags.some(t => t.toLowerCase().includes(q))
    );
  }, [entries, searchKnowledge]);

  const currentFindings: Finding[] = selectedCase?.findings || [];

  const handleSelectCase = (c: CaseStudy) => {
    setSelectedCase(c);
    setCaseView('detail');
    setActiveFinding(null);
    setExpandedFinding(null);
  };

  const handleCreateCase = () => {
    setEditingCase({
      id: `case-${Date.now()}`,
      title: '',
      patientAge: 0,
      patientGender: 'M',
      clinicalHistory: '',
      examType: 'chest_pa',
      findings: [],
      diagnosis: '',
      notes: '',
      tags: [],
      createdAt: new Date().toISOString().split('T')[0],
      isTemplate: false,
    });
    setCaseView('edit');
  };

  const handleSaveCase = () => {
    if (!editingCase) return;
    if (cases.find(c => c.id === editingCase.id)) {
      updateCase(editingCase);
    } else {
      addCase(editingCase);
    }
    setEditingCase(null);
    setCaseView('list');
  };

  const handleCreateKnowledge = () => {
    setEditingKnowledge({
      id: `kb-${Date.now()}`,
      title: '',
      category: '',
      content: '',
      tags: [],
      createdAt: new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0],
    });
    setKnowledgeView('edit');
  };

  const handleSaveKnowledge = () => {
    if (!editingKnowledge) return;
    if (entries.find(e => e.id === editingKnowledge.id)) {
      updateEntry(editingKnowledge);
    } else {
      addEntry(editingKnowledge);
    }
    setEditingKnowledge(null);
    setKnowledgeView('list');
  };

  return (
    <div className="h-screen w-screen flex flex-col bg-slate-950 text-slate-200 overflow-hidden">
      {/* Header */}
      <header className="flex items-center justify-between px-4 py-2 border-b border-slate-800 bg-slate-900/80 backdrop-blur-sm shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
            <Brain size={18} className="text-white" />
          </div>
          <div>
            <h1 className="text-sm font-bold text-white tracking-tight">RadAI Analyzer</h1>
            <p className="text-[10px] text-slate-400">Hệ thống phân tích X-quang thông minh</p>
          </div>
        </div>
        
        <nav className="flex gap-1 bg-slate-800/50 rounded-lg p-1">
          <button
            onClick={() => setActiveTab('viewer')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
              activeTab === 'viewer' ? 'bg-cyan-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Eye size={14} /> Phim X-quang
          </button>
          <button
            onClick={() => setActiveTab('cases')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
              activeTab === 'cases' ? 'bg-cyan-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'
            }`}
          >
            <FolderOpen size={14} /> Ca mẫu ({cases.length})
          </button>
          <button
            onClick={() => setActiveTab('knowledge')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
              activeTab === 'knowledge' ? 'bg-cyan-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'
            }`}
          >
            <BookOpen size={14} /> Kinh nghiệm ({entries.length})
          </button>
        </nav>

        <div className="flex items-center gap-2 text-[10px] text-slate-500">
          <Stethoscope size={12} />
          <span>Dành cho bác sĩ chuyên khoa</span>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex overflow-hidden">
        {/* Left Sidebar */}
        <aside className="w-72 border-r border-slate-800 bg-slate-900/50 flex flex-col overflow-hidden shrink-0">
          {activeTab === 'viewer' && (
            <>
              <div className="p-3 border-b border-slate-800">
                <h3 className="text-xs font-semibold text-slate-300 mb-2 flex items-center gap-2">
                  <Grid3X3 size={12} /> Ca lâm sàng
                </h3>
                <div className="space-y-1 max-h-[calc(100vh-200px)] overflow-y-auto custom-scrollbar">
                  {cases.map(c => (
                    <button
                      key={c.id}
                      onClick={() => handleSelectCase(c)}
                      className={`w-full text-left px-2.5 py-2 rounded-md text-xs transition-all ${
                        selectedCase?.id === c.id
                          ? 'bg-cyan-600/20 border border-cyan-500/30 text-cyan-300'
                          : 'hover:bg-slate-800 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      <div className="font-medium truncate">{c.title}</div>
                      <div className="text-[10px] text-slate-500 mt-0.5">
                        {c.patientGender === 'M' ? '♂' : '♀'} {c.patientAge}T • {examTypeLabel(c.examType)}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Controls */}
              <div className="p-3 border-b border-slate-800">
                <h3 className="text-xs font-semibold text-slate-300 mb-2 flex items-center gap-2">
                  <Layout size={12} /> Điều chỉnh phim
                </h3>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <button onClick={() => setZoom(z => Math.min(z + 0.2, 3))} className="p-1 rounded bg-slate-800 hover:bg-slate-700">
                      <ZoomIn size={12} />
                    </button>
                    <span className="text-[10px] text-slate-400 w-10 text-center">{Math.round(zoom * 100)}%</span>
                    <button onClick={() => setZoom(z => Math.max(z - 0.2, 0.5))} className="p-1 rounded bg-slate-800 hover:bg-slate-700">
                      <ZoomOut size={12} />
                    </button>
                    <button onClick={() => setZoom(1)} className="p-1 rounded bg-slate-800 hover:bg-slate-700">
                      <RotateCcw size={12} />
                    </button>
                  </div>
                  <div className="flex items-center gap-2">
                    <Sun size={12} className="text-slate-400" />
                    <input type="range" min="-2" max="2" step="0.1" value={brightness}
                      onChange={e => setBrightness(parseFloat(e.target.value))}
                      className="flex-1 h-1 accent-cyan-500" />
                  </div>
                  <div className="flex items-center gap-2">
                    <Moon size={12} className="text-slate-400" />
                    <input type="range" min="-0.5" max="0.5" step="0.05" value={contrast}
                      onChange={e => setContrast(parseFloat(e.target.value))}
                      className="flex-1 h-1 accent-cyan-500" />
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setInverted(!inverted)}
                      className={`px-2 py-1 rounded text-[10px] ${inverted ? 'bg-cyan-600 text-white' : 'bg-slate-800 text-slate-400'}`}
                    >
                      Đảo ngược
                    </button>
                    <button
                      onClick={() => setShowOverlay(!showOverlay)}
                      className={`px-2 py-1 rounded text-[10px] flex items-center gap-1 ${showOverlay ? 'bg-cyan-600 text-white' : 'bg-slate-800 text-slate-400'}`}
                    >
                      {showOverlay ? <Eye size={10} /> : <EyeOff size={10} />} Tổn thương
                    </button>
                  </div>
                </div>
              </div>

              {/* Findings list */}
              {selectedCase && (
                <div className="flex-1 overflow-y-auto custom-scrollbar p-3">
                  <h3 className="text-xs font-semibold text-slate-300 mb-2 flex items-center gap-2">
                    <AlertTriangle size={12} /> Phát hiện ({currentFindings.length})
                  </h3>
                  <div className="space-y-1.5">
                    {currentFindings.map(f => (
                      <div key={f.id}>
                        <button
                          onClick={() => {
                            setActiveFinding(activeFinding === f.id ? null : f.id);
                            setExpandedFinding(expandedFinding === f.id ? null : f.id);
                          }}
                          className={`w-full text-left px-2.5 py-2 rounded-md text-xs border-l-2 transition-all ${
                            activeFinding === f.id
                              ? 'bg-cyan-600/20 border-l-cyan-400 text-cyan-200'
                              : `border-l-slate-600 hover:bg-slate-800 text-slate-300`
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-medium truncate flex-1">{f.name}</span>
                            <span className={`text-[9px] px-1.5 py-0.5 rounded border ${severityColor(f.severity)}`}>
                              {severityLabel(f.severity)}
                            </span>
                          </div>
                          <div className="text-[10px] text-slate-500 mt-0.5">{f.location}</div>
                        </button>
                        {expandedFinding === f.id && (
                          <div className="ml-2 mt-1 p-2 rounded bg-slate-800/50 text-[10px] text-slate-300 space-y-1.5 animate-in">
                            <p>{f.description}</p>
                            <div>
                              <span className="text-cyan-400 font-medium">Dấu hiệu X-quang:</span>
                              <p className="text-slate-400">{f.radiographicSign}</p>
                            </div>
                            <div>
                              <span className="text-cyan-400 font-medium">Chẩn đoán phân biệt:</span>
                              <ul className="text-slate-400 list-disc list-inside">
                                {f.differentialDiagnosis.map((d, i) => <li key={i}>{d}</li>)}
                              </ul>
                            </div>
                            <div>
                              <span className="text-cyan-400 font-medium">Tương quan lâm sàng:</span>
                              <p className="text-slate-400">{f.clinicalCorrelation}</p>
                            </div>
                            <div className="flex items-center gap-1 pt-1">
                              <div className="flex-1 bg-slate-700 rounded-full h-1">
                                <div className="bg-cyan-500 h-1 rounded-full" style={{ width: `${f.confidence * 100}%` }} />
                              </div>
                              <span className="text-cyan-400">{Math.round(f.confidence * 100)}%</span>
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}

          {activeTab === 'cases' && (
            <>
              <div className="p-3 border-b border-slate-800">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-xs font-semibold text-slate-300">Thư viện ca mẫu</h3>
                  <button onClick={handleCreateCase} className="p-1.5 rounded bg-cyan-600 hover:bg-cyan-500 text-white">
                    <Plus size={12} />
                  </button>
                </div>
                <div className="relative">
                  <Search size={12} className="absolute left-2 top-1/2 -translate-y-1/2 text-slate-500" />
                  <input
                    type="text"
                    placeholder="Tìm kiếm ca bệnh..."
                    value={searchCases}
                    onChange={e => setSearchCases(e.target.value)}
                    className="w-full pl-7 pr-2 py-1.5 rounded bg-slate-800 border border-slate-700 text-xs text-slate-200 placeholder:text-slate-500 focus:border-cyan-500 focus:outline-none"
                  />
                </div>
              </div>
              <div className="flex-1 overflow-y-auto custom-scrollbar p-2 space-y-1.5">
                {filteredCases.map(c => (
                  <div
                    key={c.id}
                    className={`p-2.5 rounded-lg border transition-all cursor-pointer ${
                      selectedCase?.id === c.id
                        ? 'border-cyan-500/50 bg-cyan-600/10'
                        : 'border-slate-800 hover:border-slate-700 bg-slate-900/50'
                    }`}
                    onClick={() => handleSelectCase(c)}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1 min-w-0">
                        <h4 className="text-xs font-medium text-slate-200 truncate">{c.title}</h4>
                        <div className="flex items-center gap-2 mt-1 text-[10px] text-slate-500">
                          <span>{c.patientGender === 'M' ? '♂' : '♀'} {c.patientAge}T</span>
                          <span>•</span>
                          <span>{examTypeLabel(c.examType)}</span>
                        </div>
                        <div className="flex flex-wrap gap-1 mt-1.5">
                          {c.tags.slice(0, 3).map(t => (
                            <span key={t} className="px-1.5 py-0.5 rounded bg-slate-800 text-[9px] text-slate-400">{t}</span>
                          ))}
                        </div>
                      </div>
                      <div className="flex gap-0.5 ml-2 shrink-0">
                        <button
                          onClick={e => { e.stopPropagation(); duplicateCase(c.id); }}
                          className="p-1 rounded hover:bg-slate-700 text-slate-500 hover:text-slate-300"
                          title="Nhân bản"
                        >
                          <Copy size={10} />
                        </button>
                        <button
                          onClick={e => { e.stopPropagation(); setEditingCase({...c}); setCaseView('edit'); }}
                          className="p-1 rounded hover:bg-slate-700 text-slate-500 hover:text-slate-300"
                          title="Chỉnh sửa"
                        >
                          <Edit3 size={10} />
                        </button>
                        <button
                          onClick={e => { e.stopPropagation(); if (confirm('Xóa ca này?')) deleteCase(c.id); }}
                          className="p-1 rounded hover:bg-red-900/50 text-slate-500 hover:text-red-400"
                          title="Xóa"
                        >
                          <Trash2 size={10} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}

          {activeTab === 'knowledge' && (
            <>
              <div className="p-3 border-b border-slate-800">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-xs font-semibold text-slate-300">Kinh nghiệm phân tích</h3>
                  <button onClick={handleCreateKnowledge} className="p-1.5 rounded bg-cyan-600 hover:bg-cyan-500 text-white">
                    <Plus size={12} />
                  </button>
                </div>
                <div className="relative">
                  <Search size={12} className="absolute left-2 top-1/2 -translate-y-1/2 text-slate-500" />
                  <input
                    type="text"
                    placeholder="Tìm kiếm kinh nghiệm..."
                    value={searchKnowledge}
                    onChange={e => setSearchKnowledge(e.target.value)}
                    className="w-full pl-7 pr-2 py-1.5 rounded bg-slate-800 border border-slate-700 text-xs text-slate-200 placeholder:text-slate-500 focus:border-cyan-500 focus:outline-none"
                  />
                </div>
              </div>
              <div className="flex-1 overflow-y-auto custom-scrollbar p-2 space-y-1.5">
                {filteredKnowledge.map(e => (
                  <div
                    key={e.id}
                    className="p-2.5 rounded-lg border border-slate-800 hover:border-slate-700 bg-slate-900/50 transition-all"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1 min-w-0">
                        <h4 className="text-xs font-medium text-slate-200">{e.title}</h4>
                        <span className="inline-block mt-1 px-1.5 py-0.5 rounded bg-blue-500/10 text-blue-400 text-[9px]">
                          {e.category}
                        </span>
                        <p className="text-[10px] text-slate-500 mt-1 line-clamp-2">
                          {e.content.substring(0, 120)}...
                        </p>
                        <div className="flex flex-wrap gap-1 mt-1.5">
                          {e.tags.slice(0, 3).map(t => (
                            <span key={t} className="px-1.5 py-0.5 rounded bg-slate-800 text-[9px] text-slate-400">{t}</span>
                          ))}
                        </div>
                      </div>
                      <div className="flex gap-0.5 ml-2 shrink-0">
                        <button
                          onClick={() => { setEditingKnowledge({...e}); setKnowledgeView('edit'); }}
                          className="p-1 rounded hover:bg-slate-700 text-slate-500 hover:text-slate-300"
                        >
                          <Edit3 size={10} />
                        </button>
                        <button
                          onClick={() => { if (confirm('Xóa?')) deleteEntry(e.id); }}
                          className="p-1 rounded hover:bg-red-900/50 text-slate-500 hover:text-red-400"
                        >
                          <Trash2 size={10} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </aside>

        {/* Center - Viewer */}
        <section className="flex-1 flex flex-col overflow-hidden">
          {activeTab === 'viewer' && (
            <div className="flex-1 relative bg-black">
              {selectedCase ? (
                selectedCase.examType.startsWith('chest') ? (
                  <ChestXRayCanvas
                    findings={currentFindings}
                    activeFinding={activeFinding}
                    showOverlay={showOverlay}
                    zoom={zoom}
                    panX={0}
                    panY={0}
                    brightness={brightness}
                    contrast={contrast}
                    inverted={inverted}
                  />
                ) : (
                  <AbdomenXRayCanvas
                    findings={currentFindings}
                    activeFinding={activeFinding}
                    showOverlay={showOverlay}
                    zoom={zoom}
                    panX={0}
                    panY={0}
                    brightness={brightness}
                    contrast={contrast}
                    inverted={inverted}
                  />
                )
              ) : (
                <div className="flex items-center justify-center h-full">
                  <div className="text-center">
                    <Eye size={48} className="text-slate-700 mx-auto mb-3" />
                    <p className="text-slate-500 text-sm">Chọn một ca lâm sàng để bắt đầu phân tích</p>
                    <p className="text-slate-600 text-xs mt-1">Hoặc tạo ca mới từ thư viện</p>
                  </div>
                </div>
              )}
              
              {/* Info overlay */}
              {selectedCase && (
                <div className="absolute top-3 left-3 bg-black/70 backdrop-blur-sm rounded-lg px-3 py-2 text-[10px] text-slate-300 space-y-0.5">
                  <div className="font-semibold text-cyan-400">{selectedCase.title}</div>
                  <div>{selectedCase.patientGender === 'M' ? 'Nam' : 'Nữ'} {selectedCase.patientAge} tuổi</div>
                  <div>{examTypeLabel(selectedCase.examType)}</div>
                  <div className="text-slate-500">{selectedCase.createdAt}</div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'cases' && caseView === 'edit' && editingCase && (
            <div className="flex-1 overflow-y-auto p-6 custom-scrollbar">
              <div className="max-w-3xl mx-auto space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-bold text-white">
                    {cases.find(c => c.id === editingCase.id) ? 'Chỉnh sửa ca mẫu' : 'Tạo ca mẫu mới'}
                  </h2>
                  <div className="flex gap-2">
                    <button onClick={() => { setEditingCase(null); setCaseView('list'); }}
                      className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs hover:bg-slate-700">
                      Hủy
                    </button>
                    <button onClick={handleSaveCase}
                      className="px-3 py-1.5 rounded-lg bg-cyan-600 text-white text-xs hover:bg-cyan-500 flex items-center gap-1">
                      <Save size={12} /> Lưu
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs text-slate-400 mb-1 block">Tiêu đề ca bệnh</label>
                    <input
                      type="text"
                      value={editingCase.title}
                      onChange={e => setEditingCase({...editingCase, title: e.target.value})}
                      className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-sm text-slate-200 focus:border-cyan-500 focus:outline-none"
                      placeholder="VD: Viêm phổi thùy phải dưới"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-slate-400 mb-1 block">Loại phim</label>
                    <select
                      value={editingCase.examType}
                      onChange={e => setEditingCase({...editingCase, examType: e.target.value as any})}
                      className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-sm text-slate-200 focus:border-cyan-500 focus:outline-none"
                    >
                      <option value="chest_pa">Ngực thẳng (PA)</option>
                      <option value="chest_lateral">Ngực nghiêng</option>
                      <option value="abdomen_supine">Bụng nằm ngửa</option>
                      <option value="abdomen_erect">Bụng đứng</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs text-slate-400 mb-1 block">Tuổi</label>
                    <input
                      type="number"
                      value={editingCase.patientAge}
                      onChange={e => setEditingCase({...editingCase, patientAge: parseInt(e.target.value) || 0})}
                      className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-sm text-slate-200 focus:border-cyan-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-slate-400 mb-1 block">Giới tính</label>
                    <select
                      value={editingCase.patientGender}
                      onChange={e => setEditingCase({...editingCase, patientGender: e.target.value as 'M' | 'F'})}
                      className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-sm text-slate-200 focus:border-cyan-500 focus:outline-none"
                    >
                      <option value="M">Nam</option>
                      <option value="F">Nữ</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-xs text-slate-400 mb-1 block">Bệnh cảnh lâm sàng</label>
                  <textarea
                    value={editingCase.clinicalHistory}
                    onChange={e => setEditingCase({...editingCase, clinicalHistory: e.target.value})}
                    rows={3}
                    className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-sm text-slate-200 focus:border-cyan-500 focus:outline-none resize-none"
                    placeholder="Mô tả triệu chứng, tiền sử, xét nghiệm..."
                  />
                </div>

                <div>
                  <label className="text-xs text-slate-400 mb-1 block">Chẩn đoán</label>
                  <input
                    type="text"
                    value={editingCase.diagnosis}
                    onChange={e => setEditingCase({...editingCase, diagnosis: e.target.value})}
                    className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-sm text-slate-200 focus:border-cyan-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs text-slate-400 mb-1 block">Ghi chú / Hướng xử trí</label>
                  <textarea
                    value={editingCase.notes}
                    onChange={e => setEditingCase({...editingCase, notes: e.target.value})}
                    rows={3}
                    className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-sm text-slate-200 focus:border-cyan-500 focus:outline-none resize-none"
                  />
                </div>

                <div>
                  <label className="text-xs text-slate-400 mb-1 block">Tags (phân cách bằng dấu phẩy)</label>
                  <input
                    type="text"
                    value={editingCase.tags.join(', ')}
                    onChange={e => setEditingCase({...editingCase, tags: e.target.value.split(',').map(t => t.trim()).filter(Boolean)})}
                    className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-sm text-slate-200 focus:border-cyan-500 focus:outline-none"
                    placeholder="viêm phổi, COPD, cấp cứu..."
                  />
                </div>

                {/* Findings Editor */}
                <div className="border border-slate-700 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-sm font-semibold text-white">Tổn thương / Phát hiện</h3>
                    <button
                      onClick={() => setEditingCase({
                        ...editingCase,
                        findings: [...editingCase.findings, {
                          id: `f-${Date.now()}`,
                          name: 'Tổn thương mới',
                          description: '',
                          severity: 'moderate',
                          location: '',
                          radiographicSign: '',
                          differentialDiagnosis: [],
                          clinicalCorrelation: '',
                          confidence: 0.8,
                          x: 300, y: 350, radius: 50,
                          type: 'opacity',
                        }]
                      })}
                      className="px-2 py-1 rounded bg-cyan-600 text-white text-[10px] flex items-center gap-1"
                    >
                      <Plus size={10} /> Thêm tổn thương
                    </button>
                  </div>
                  <div className="space-y-3">
                    {editingCase.findings.map((f, idx) => (
                      <div key={f.id} className="border border-slate-700 rounded-lg p-3 bg-slate-800/30">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-xs font-medium text-cyan-400">Tổn thương #{idx + 1}</span>
                          <button
                            onClick={() => setEditingCase({
                              ...editingCase,
                              findings: editingCase.findings.filter(ff => ff.id !== f.id)
                            })}
                            className="p-1 rounded hover:bg-red-900/50 text-red-400"
                          >
                            <Trash2 size={10} />
                          </button>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <input
                            type="text"
                            value={f.name}
                            onChange={e => setEditingCase({
                              ...editingCase,
                              findings: editingCase.findings.map(ff => ff.id === f.id ? {...ff, name: e.target.value} : ff)
                            })}
                            placeholder="Tên tổn thương"
                            className="px-2 py-1.5 rounded bg-slate-800 border border-slate-700 text-xs text-slate-200 focus:border-cyan-500 focus:outline-none"
                          />
                          <select
                            value={f.type}
                            onChange={e => setEditingCase({
                              ...editingCase,
                              findings: editingCase.findings.map(ff => ff.id === f.id ? {...ff, type: e.target.value as any} : ff)
                            })}
                            className="px-2 py-1.5 rounded bg-slate-800 border border-slate-700 text-xs text-slate-200 focus:border-cyan-500 focus:outline-none"
                          >
                            <option value="opacity">Đục / Đông đặc</option>
                            <option value="lucency">Sáng / Giảm tỷ trọng</option>
                            <option value="mass">Khối u</option>
                            <option value="effusion">Tràn dịch</option>
                            <option value="pneumothorax">Tràn khí</option>
                            <option value="fracture">Gãy xương</option>
                            <option value="calcification">Vôi hóa</option>
                            <option value="cardiomegaly">Bóng tim to</option>
                            <option value="foreign_body">Dị vật</option>
                          </select>
                        </div>
                        <div className="grid grid-cols-2 gap-2 mt-2">
                          <input
                            type="text"
                            value={f.location}
                            onChange={e => setEditingCase({
                              ...editingCase,
                              findings: editingCase.findings.map(ff => ff.id === f.id ? {...ff, location: e.target.value} : ff)
                            })}
                            placeholder="Vị trí"
                            className="px-2 py-1.5 rounded bg-slate-800 border border-slate-700 text-xs text-slate-200 focus:border-cyan-500 focus:outline-none"
                          />
                          <select
                            value={f.severity}
                            onChange={e => setEditingCase({
                              ...editingCase,
                              findings: editingCase.findings.map(ff => ff.id === f.id ? {...ff, severity: e.target.value as any} : ff)
                            })}
                            className="px-2 py-1.5 rounded bg-slate-800 border border-slate-700 text-xs text-slate-200 focus:border-cyan-500 focus:outline-none"
                          >
                            <option value="mild">Nhẹ</option>
                            <option value="moderate">Trung bình</option>
                            <option value="severe">Nặng</option>
                            <option value="critical">Nguy kịch</option>
                          </select>
                        </div>
                        <textarea
                          value={f.description}
                          onChange={e => setEditingCase({
                            ...editingCase,
                            findings: editingCase.findings.map(ff => ff.id === f.id ? {...ff, description: e.target.value} : ff)
                          })}
                          placeholder="Mô tả tổn thương..."
                          rows={2}
                          className="w-full mt-2 px-2 py-1.5 rounded bg-slate-800 border border-slate-700 text-xs text-slate-200 focus:border-cyan-500 focus:outline-none resize-none"
                        />
                        <textarea
                          value={f.radiographicSign}
                          onChange={e => setEditingCase({
                            ...editingCase,
                            findings: editingCase.findings.map(ff => ff.id === f.id ? {...ff, radiographicSign: e.target.value} : ff)
                          })}
                          placeholder="Dấu hiệu X-quang đặc trưng..."
                          rows={2}
                          className="w-full mt-2 px-2 py-1.5 rounded bg-slate-800 border border-slate-700 text-xs text-slate-200 focus:border-cyan-500 focus:outline-none resize-none"
                        />
                        <div className="flex items-center gap-2 mt-2">
                          <span className="text-[10px] text-slate-400">Độ tin cậy:</span>
                          <input
                            type="range"
                            min="0" max="1" step="0.05"
                            value={f.confidence}
                            onChange={e => setEditingCase({
                              ...editingCase,
                              findings: editingCase.findings.map(ff => ff.id === f.id ? {...ff, confidence: parseFloat(e.target.value)} : ff)
                            })}
                            className="flex-1 h-1 accent-cyan-500"
                          />
                          <span className="text-[10px] text-cyan-400">{Math.round(f.confidence * 100)}%</span>
                        </div>
                        <div className="grid grid-cols-4 gap-2 mt-2">
                          <div>
                            <label className="text-[9px] text-slate-500">X</label>
                            <input type="number" value={f.x} onChange={e => setEditingCase({
                              ...editingCase,
                              findings: editingCase.findings.map(ff => ff.id === f.id ? {...ff, x: parseInt(e.target.value)} : ff)
                            })} className="w-full px-1 py-1 rounded bg-slate-800 border border-slate-700 text-[10px] text-slate-200 focus:outline-none" />
                          </div>
                          <div>
                            <label className="text-[9px] text-slate-500">Y</label>
                            <input type="number" value={f.y} onChange={e => setEditingCase({
                              ...editingCase,
                              findings: editingCase.findings.map(ff => ff.id === f.id ? {...ff, y: parseInt(e.target.value)} : ff)
                            })} className="w-full px-1 py-1 rounded bg-slate-800 border border-slate-700 text-[10px] text-slate-200 focus:outline-none" />
                          </div>
                          <div>
                            <label className="text-[9px] text-slate-500">Bán kính</label>
                            <input type="number" value={f.radius} onChange={e => setEditingCase({
                              ...editingCase,
                              findings: editingCase.findings.map(ff => ff.id === f.id ? {...ff, radius: parseInt(e.target.value)} : ff)
                            })} className="w-full px-1 py-1 rounded bg-slate-800 border border-slate-700 text-[10px] text-slate-200 focus:outline-none" />
                          </div>
                          <div className="flex items-end">
                            <button
                              onClick={() => {
                                const dd = prompt('Chẩn đoán phân biệt (phân cách bằng dấu phẩy):', f.differentialDiagnosis.join(', '));
                                if (dd) setEditingCase({
                                  ...editingCase,
                                  findings: editingCase.findings.map(ff => ff.id === f.id ? {...ff, differentialDiagnosis: dd.split(',').map(s => s.trim()).filter(Boolean)} : ff)
                                });
                              }}
                              className="w-full px-1 py-1 rounded bg-slate-700 text-[9px] text-slate-300 hover:bg-slate-600"
                            >
                              Chđoán phân biệt
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'cases' && caseView === 'detail' && selectedCase && (
            <div className="flex-1 overflow-y-auto p-6 custom-scrollbar">
              <div className="max-w-3xl mx-auto">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h2 className="text-lg font-bold text-white">{selectedCase.title}</h2>
                    <div className="flex items-center gap-3 mt-1 text-xs text-slate-400">
                      <span>{selectedCase.patientGender === 'M' ? '♂ Nam' : '♀ Nữ'} {selectedCase.patientAge} tuổi</span>
                      <span>•</span>
                      <span>{examTypeLabel(selectedCase.examType)}</span>
                      <span>•</span>
                      <span>{selectedCase.createdAt}</span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => { setEditingCase({...selectedCase}); setCaseView('edit'); }}
                      className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs hover:bg-slate-700 flex items-center gap-1"
                    >
                      <Edit3 size={12} /> Sửa
                    </button>
                    <button
                      onClick={() => { setActiveTab('viewer'); }}
                      className="px-3 py-1.5 rounded-lg bg-cyan-600 text-white text-xs hover:bg-cyan-500 flex items-center gap-1"
                    >
                      <Eye size={12} /> Xem phim
                    </button>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700">
                    <h3 className="text-xs font-semibold text-cyan-400 mb-2 flex items-center gap-1">
                      <FileText size={12} /> Bệnh cảnh lâm sàng
                    </h3>
                    <p className="text-sm text-slate-300">{selectedCase.clinicalHistory}</p>
                  </div>

                  <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700">
                    <h3 className="text-xs font-semibold text-cyan-400 mb-2 flex items-center gap-1">
                      <CheckCircle size={12} /> Chẩn đoán
                    </h3>
                    <p className="text-sm text-slate-300 font-medium">{selectedCase.diagnosis}</p>
                  </div>

                  <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700">
                    <h3 className="text-xs font-semibold text-cyan-400 mb-3 flex items-center gap-1">
                      <AlertTriangle size={12} /> Các phát hiện ({selectedCase.findings.length})
                    </h3>
                    <div className="space-y-3">
                      {selectedCase.findings.map((f, idx) => (
                        <div key={f.id} className="border border-slate-700 rounded-lg p-3">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-bold text-white">{idx + 1}. {f.name}</span>
                              <span className={`text-[9px] px-1.5 py-0.5 rounded border ${severityColor(f.severity)}`}>
                                {severityLabel(f.severity)}
                              </span>
                            </div>
                            <span className="text-[10px] text-cyan-400">{Math.round(f.confidence * 100)}% tin cậy</span>
                          </div>
                          <p className="text-xs text-slate-300 mb-2">{f.description}</p>
                          <div className="grid grid-cols-2 gap-3 text-[11px]">
                            <div>
                              <span className="text-slate-500">Vị trí:</span>
                              <span className="text-slate-300 ml-1">{f.location}</span>
                            </div>
                            <div>
                              <span className="text-slate-500">Dấu hiệu XQ:</span>
                              <span className="text-slate-300 ml-1">{f.radiographicSign}</span>
                            </div>
                          </div>
                          <div className="mt-2 text-[11px]">
                            <span className="text-slate-500">Chẩn đoán phân biệt:</span>
                            <span className="text-slate-300 ml-1">{f.differentialDiagnosis.join(', ')}</span>
                          </div>
                          <div className="mt-1 text-[11px]">
                            <span className="text-slate-500">Tương quan lâm sàng:</span>
                            <span className="text-slate-300 ml-1">{f.clinicalCorrelation}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {selectedCase.notes && (
                    <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700">
                      <h3 className="text-xs font-semibold text-cyan-400 mb-2 flex items-center gap-1">
                        <Info size={12} /> Ghi chú / Hướng xử trí
                      </h3>
                      <p className="text-sm text-slate-300">{selectedCase.notes}</p>
                    </div>
                  )}

                  <div className="flex flex-wrap gap-1.5">
                    {selectedCase.tags.map(t => (
                      <span key={t} className="px-2 py-1 rounded-full bg-slate-800 text-[10px] text-slate-400 border border-slate-700">
                        #{t}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'cases' && caseView === 'list' && (
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center">
                <FolderOpen size={48} className="text-slate-700 mx-auto mb-3" />
                <p className="text-slate-500 text-sm">Chọn một ca mẫu từ danh sách bên trái</p>
                <p className="text-slate-600 text-xs mt-1">hoặc tạo ca mới</p>
              </div>
            </div>
          )}

          {activeTab === 'knowledge' && knowledgeView === 'edit' && editingKnowledge && (
            <div className="flex-1 overflow-y-auto p-6 custom-scrollbar">
              <div className="max-w-3xl mx-auto space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-bold text-white">
                    {entries.find(e => e.id === editingKnowledge.id) ? 'Chỉnh sửa kinh nghiệm' : 'Thêm kinh nghiệm mới'}
                  </h2>
                  <div className="flex gap-2">
                    <button onClick={() => { setEditingKnowledge(null); setKnowledgeView('list'); }}
                      className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs hover:bg-slate-700">
                      Hủy
                    </button>
                    <button onClick={handleSaveKnowledge}
                      className="px-3 py-1.5 rounded-lg bg-cyan-600 text-white text-xs hover:bg-cyan-500 flex items-center gap-1">
                      <Save size={12} /> Lưu
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs text-slate-400 mb-1 block">Tiêu đề</label>
                    <input
                      type="text"
                      value={editingKnowledge.title}
                      onChange={e => setEditingKnowledge({...editingKnowledge, title: e.target.value})}
                      className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-sm text-slate-200 focus:border-cyan-500 focus:outline-none"
                      placeholder="VD: Phương pháp đọc phim ngực hệ thống"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-slate-400 mb-1 block">Danh mục</label>
                    <select
                      value={editingKnowledge.category}
                      onChange={e => setEditingKnowledge({...editingKnowledge, category: e.target.value})}
                      className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-sm text-slate-200 focus:border-cyan-500 focus:outline-none"
                    >
                      <option value="">Chọn danh mục</option>
                      <option value="Phương pháp">Phương pháp</option>
                      <option value="Dấu hiệu">Dấu hiệu</option>
                      <option value="Chẩn đoán phân biệt">Chẩn đoán phân biệt</option>
                      <option value="Kinh nghiệm">Kinh nghiệm</option>
                      <option value="Cấp cứu">Cấp cứu</option>
                      <option value="Nhi khoa">Nhi khoa</option>
                      <option value="Chấn thương">Chấn thương</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-xs text-slate-400 mb-1 block">Nội dung (hỗ trợ Markdown)</label>
                  <textarea
                    value={editingKnowledge.content}
                    onChange={e => setEditingKnowledge({...editingKnowledge, content: e.target.value})}
                    rows={20}
                    className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-sm text-slate-200 focus:border-cyan-500 focus:outline-none resize-none font-mono"
                    placeholder="Viết kinh nghiệm, hướng dẫn phân tích..."
                  />
                </div>

                <div>
                  <label className="text-xs text-slate-400 mb-1 block">Tags (phân cách bằng dấu phẩy)</label>
                  <input
                    type="text"
                    value={editingKnowledge.tags.join(', ')}
                    onChange={e => setEditingKnowledge({...editingKnowledge, tags: e.target.value.split(',').map(t => t.trim()).filter(Boolean)})}
                    className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-sm text-slate-200 focus:border-cyan-500 focus:outline-none"
                    placeholder="phương pháp, đọc phim, hệ thống..."
                  />
                </div>
              </div>
            </div>
          )}

          {activeTab === 'knowledge' && knowledgeView === 'list' && (
            <div className="flex-1 overflow-y-auto p-6 custom-scrollbar">
              <div className="max-w-3xl mx-auto">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-bold text-white">Kinh nghiệm phân tích X-quang</h2>
                  <button onClick={handleCreateKnowledge}
                    className="px-3 py-1.5 rounded-lg bg-cyan-600 text-white text-xs hover:bg-cyan-500 flex items-center gap-1">
                    <Plus size={12} /> Thêm mới
                  </button>
                </div>
                <div className="space-y-4">
                  {filteredKnowledge.map(entry => (
                    <div key={entry.id} className="border border-slate-800 rounded-xl p-5 bg-slate-900/50 hover:border-slate-700 transition-all">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h3 className="text-sm font-bold text-white">{entry.title}</h3>
                          <div className="flex items-center gap-2 mt-1">
                            <span className="px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-400 text-[10px]">
                              {entry.category}
                            </span>
                            <span className="text-[10px] text-slate-500">Cập nhật: {entry.updatedAt}</span>
                          </div>
                        </div>
                        <div className="flex gap-1">
                          <button
                            onClick={() => { setEditingKnowledge({...entry}); setKnowledgeView('edit'); }}
                            className="p-1.5 rounded hover:bg-slate-700 text-slate-500 hover:text-slate-300"
                          >
                            <Edit3 size={12} />
                          </button>
                          <button
                            onClick={() => { if (confirm('Xóa?')) deleteEntry(entry.id); }}
                            className="p-1.5 rounded hover:bg-red-900/50 text-slate-500 hover:text-red-400"
                          >
                            <Trash2 size={12} />
                          </button>
                        </div>
                      </div>
                      <div className="prose prose-sm prose-invert max-w-none">
                        {entry.content.split('\n').map((line, i) => {
                          if (line.startsWith('## ')) return <h3 key={i} className="text-sm font-bold text-cyan-400 mt-3 mb-1">{line.replace('## ', '')}</h3>;
                          if (line.startsWith('### ')) return <h4 key={i} className="text-xs font-semibold text-slate-300 mt-2 mb-1">{line.replace('### ', '')}</h4>;
                          if (line.startsWith('- **')) {
                            const match = line.match(/- \*\*(.+?)\*\*:?\s*(.*)/);
                            if (match) return (
                              <div key={i} className="text-xs text-slate-300 ml-3 mb-0.5">
                                <span className="text-cyan-400 font-medium">• {match[1]}:</span> {match[2]}
                              </div>
                            );
                          }
                          if (line.startsWith('- ')) return <div key={i} className="text-xs text-slate-400 ml-3 mb-0.5">• {line.replace('- ', '')}</div>;
                          if (line.trim() === '') return <br key={i} />;
                          return <p key={i} className="text-xs text-slate-300 mb-1">{line}</p>;
                        })}
                      </div>
                      <div className="flex flex-wrap gap-1.5 mt-3 pt-3 border-t border-slate-800">
                        {entry.tags.map(t => (
                          <span key={t} className="px-2 py-0.5 rounded-full bg-slate-800 text-[9px] text-slate-400">#{t}</span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </section>

        {/* Right Panel - Detail */}
        {activeTab === 'viewer' && selectedCase && (
          <aside className="w-80 border-l border-slate-800 bg-slate-900/50 flex flex-col overflow-hidden shrink-0">
            <div className="p-3 border-b border-slate-800">
              <h3 className="text-xs font-semibold text-slate-300 flex items-center gap-2">
                <FileText size={12} /> Thông tin ca bệnh
              </h3>
            </div>
            <div className="flex-1 overflow-y-auto custom-scrollbar p-3 space-y-3">
              <div className="p-3 rounded-lg bg-slate-800/50 border border-slate-700">
                <h4 className="text-[10px] font-semibold text-cyan-400 mb-1">BỆNH CẢNH LÂM SÀNG</h4>
                <p className="text-[11px] text-slate-300 leading-relaxed">{selectedCase.clinicalHistory}</p>
              </div>

              <div className="p-3 rounded-lg bg-slate-800/50 border border-slate-700">
                <h4 className="text-[10px] font-semibold text-cyan-400 mb-1">CHẨN ĐOÁN</h4>
                <p className="text-[11px] text-slate-200 font-medium">{selectedCase.diagnosis}</p>
              </div>

              {activeFinding && (
                <div className="p-3 rounded-lg bg-cyan-600/5 border border-cyan-500/30 animate-in">
                  <h4 className="text-[10px] font-semibold text-cyan-400 mb-2 flex items-center gap-1">
                    <Brain size={10} /> PHÂN TÍCH CHI TIẾT
                  </h4>
                  {(() => {
                    const f = currentFindings.find(ff => ff.id === activeFinding);
                    if (!f) return null;
                    return (
                      <div className="space-y-2">
                        <div>
                          <span className="text-[10px] text-slate-400">Tổn thương:</span>
                          <span className="text-xs text-white font-medium ml-1">{f.name}</span>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-400">Mô tả:</span>
                          <p className="text-[11px] text-slate-300 mt-0.5">{f.description}</p>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-400">Dấu hiệu X-quang:</span>
                          <p className="text-[11px] text-slate-300 mt-0.5">{f.radiographicSign}</p>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-400">Chẩn đoán phân biệt:</span>
                          <ul className="text-[11px] text-slate-300 mt-0.5 space-y-0.5">
                            {f.differentialDiagnosis.map((d, i) => (
                              <li key={i} className="flex items-center gap-1">
                                <ChevronRight size={8} className="text-cyan-400 shrink-0" /> {d}
                              </li>
                            ))}
                          </ul>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-400">Tương quan lâm sàng:</span>
                          <p className="text-[11px] text-slate-300 mt-0.5">{f.clinicalCorrelation}</p>
                        </div>
                        <div className="pt-1">
                          <div className="flex items-center justify-between text-[10px]">
                            <span className="text-slate-400">Độ tin cậy AI:</span>
                            <span className="text-cyan-400 font-bold">{Math.round(f.confidence * 100)}%</span>
                          </div>
                          <div className="mt-1 bg-slate-700 rounded-full h-1.5">
                            <div
                              className="bg-gradient-to-r from-cyan-500 to-blue-500 h-1.5 rounded-full transition-all"
                              style={{ width: `${f.confidence * 100}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    );
                  })()}
                </div>
              )}

              {selectedCase.notes && (
                <div className="p-3 rounded-lg bg-slate-800/50 border border-slate-700">
                  <h4 className="text-[10px] font-semibold text-cyan-400 mb-1">GHI CHÚ / XỬ TRÍ</h4>
                  <p className="text-[11px] text-slate-300 leading-relaxed">{selectedCase.notes}</p>
                </div>
              )}
            </div>
          </aside>
        )}
      </main>
    </div>
  );
}
