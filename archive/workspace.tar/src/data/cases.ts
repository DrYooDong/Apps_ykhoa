export type FindingType = 
  | 'pneumothorax'
  | 'pleural_effusion'
  | 'cardiomegaly'
  | 'lung_nodule'
  | 'consolidation'
  | 'rib_fracture'
  | 'pulmonary_edema'
  | 'atelectasis'
  | 'hiatal_hernia'
  | 'intestinal_obstruction'
  | 'free_air'
  | 'calcification'
  | 'foreign_body'
  | 'scoliosis'
  | 'mediastinal_shift';

export type Severity = 'mild' | 'moderate' | 'severe' | 'critical';

export interface Finding {
  id: string;
  type: FindingType;
  name: string;
  nameVi: string;
  description: string;
  location: string;
  severity: Severity;
  confidence: number;
  measurements?: { label: string; value: string }[];
  clinicalSignificance: string;
  differentialDiagnosis: string[];
  recommendedActions: string[];
}

export interface Case {
  id: string;
  patientId: string;
  patientName: string;
  age: number;
  gender: 'M' | 'F';
  examDate: string;
  examType: 'chest_pa' | 'chest_lateral' | 'abdomen_supine' | 'abdomen_erect';
  clinicalHistory: string;
  findings: Finding[];
  impression: string;
}

export const cases: Case[] = [
  {
    id: 'case-001',
    patientId: 'BN-2024-0847',
    patientName: 'Nguyễn Văn A.',
    age: 67,
    gender: 'M',
    examDate: '2024-03-15',
    examType: 'chest_pa',
    clinicalHistory: 'Khó thở tăng dần 3 ngày, đau ngực phải, tiền sử COPD 10 năm, hút thuốc 40 gói-năm.',
    findings: [
      {
        id: 'f1',
        type: 'pneumothorax',
        name: 'Right Pneumothorax',
        nameVi: 'Tràn khí màng phổi phải',
        description: 'Đường tràn khí màng phổi phải nhìn thấy rõ ở vùng đỉnh phổi, cách thành ngực 2.3cm. Nhu mô phổi bị xẹp khoảng 30%.',
        location: 'Vùng đỉnh phổi phải',
        severity: 'moderate',
        confidence: 94,
        measurements: [
          { label: 'Khoảng cách màng phổi-thành ngực', value: '2.3 cm' },
          { label: 'Thể tích xẹp phổi ước tính', value: '~30%' },
          { label: 'Đường giữa', value: 'Không lệch' }
        ],
        clinicalSignificance: 'Tràn khí màng phổi kích thước trung bình, có thể cần dẫn lưu nếu bệnh nhân không ổn định.',
        differentialDiagnosis: ['Tràn khí màng phổi tự phát', 'Tràn khí thứ phát do vỡ bóng khí', 'Tràn khí do chấn thương'],
        recommendedActions: ['Theo dõi SpO2 liên tục', 'Chụp X-quang kiểm tra sau 6h', 'Xem xét dẫn lưu màng phổi nếu khó thở tăng']
      },
      {
        id: 'f2',
        type: 'consolidation',
        name: 'Right Lower Lobe Consolidation',
        nameVi: 'Đông đặc thùy dưới phải',
        description: 'Opacity dạng mảng không đồng nhất ở thùy dưới phải, có hình ảnh air bronchogram. Ranh giới không rõ với cơ hoành phải.',
        location: 'Thùy dưới phải (S6-S10)',
        severity: 'moderate',
        confidence: 89,
        measurements: [
          { label: 'Kích thước vùng đông đặc', value: '8.5 × 6.2 cm' },
          { label: 'Air bronchogram', value: 'Có' }
        ],
        clinicalSignificance: 'Phù hợp với viêm phổi thùy, cần kết hợp lâm sàng và xét nghiệm.',
        differentialDiagnosis: ['Viêm phổi mắc phải cộng đồng', 'Viêm phổi hít', 'Ung thư phế quản-phế nang'],
        recommendedActions: ['Công thức máu, CRP, procalcitonin', 'Cấy đờm, cấy máu', 'Kháng sinh empiric theo hướng dẫn']
      },
      {
        id: 'f3',
        type: 'cardiomegaly',
        name: 'Cardiomegaly',
        nameVi: 'Bóng tim to',
        description: 'Chỉ số tim/ngực (CTR) = 0.58, vượt ngưỡng bình thường (≤0.50). Cung dưới trái giãn, cung trên trái phồng.',
        location: 'Trung thất',
        severity: 'mild',
        confidence: 91,
        measurements: [
          { label: 'CTR', value: '0.58' },
          { label: 'Ngưỡng bình thường', value: '≤ 0.50' }
        ],
        clinicalSignificance: 'Giãn buồng tim, có thể do bệnh van tim hoặc bệnh cơ tim. Cần siêu âm tim.',
        differentialDiagnosis: ['Suy tim ứ huyết', 'Bệnh van 2 lá', 'Tràn dịch màng ngoài tim'],
        recommendedActions: ['Siêu âm tim qua thành ngực', 'BNP/NT-proBNP', 'ECG 12 chuyển đạo']
      }
    ],
    impression: '1. Tràn khí màng phổi phải ~30%. 2. Đông đặc thùy dưới phải - viêm phổi. 3. Bóng tim to (CTR 0.58). Đề nghị: dẫn lưu MKMP nếu khó thở tăng, kháng sinh điều trị viêm phổi, siêu âm tim đánh giá.'
  },
  {
    id: 'case-002',
    patientId: 'BN-2024-0912',
    patientName: 'Trần Thị B.',
    age: 54,
    gender: 'F',
    examDate: '2024-03-18',
    examType: 'chest_pa',
    clinicalHistory: 'Ho ra máu lượng ít, sụt cân 5kg/2 tháng, tiền sử hút thuốc lá.',
    findings: [
      {
        id: 'f4',
        type: 'lung_nodule',
        name: 'Right Upper Lobe Mass',
        nameVi: 'Khối u vùng phổi trên phải',
        description: 'Tổn thương dạng khối kích thước lớn, bờ không đều, có gai tua (spiculated), vùng rốn phổi phải. Có dấu hiệu co kéo phế quản.',
        location: 'Thùy trên phải, vùng rốn phổi',
        severity: 'critical',
        confidence: 96,
        measurements: [
          { label: 'Kích thước khối u', value: '4.2 × 3.8 cm' },
          { label: 'Đặc điểm bờ', value: 'Gai tua, không đều' },
          { label: 'Hạch trung thất', value: 'Nghi ngờ hạch rốn phổi phải' }
        ],
        clinicalSignificance: 'Rất nghi ngờ ung thư phổi nguyên phát. Cần sinh thiết và đánh giá giai đoạn.',
        differentialDiagnosis: ['Ung thư phổi tế bào không nhỏ', 'Ung thư tế bào nhỏ', 'Lao phổi', 'Áp xe phổi'],
        recommendedActions: ['CT ngực có cản quang', 'PET-CT đánh giá giai đoạn', 'Sinh thiết qua phế quản hoặc qua da', 'Xét nghiệm tế bào học đờm']
      },
      {
        id: 'f5',
        type: 'atelectasis',
        name: 'Right Upper Lobe Atelectasis',
        nameVi: 'Xẹp thùy trên phải',
        description: 'Dấu hiệu xẹp thùy trên phải: nâng rốn phổi phải, khe fissure ngang di chuyển lên trên, opacity dạng dải.',
        location: 'Thùy trên phải',
        severity: 'moderate',
        confidence: 87,
        measurements: [
          { label: 'Mức độ xẹp', value: 'Phân thùy trước và sau' },
          { label: 'Dịch chuyển khe fissure', value: 'Lên trên ~2cm' }
        ],
        clinicalSignificance: 'Xẹp phổi do tắc nghẽn phế quản, có thể do khối u chèn ép.',
        differentialDiagnosis: ['Tắc nghẽn do u', 'Nút nhầy', 'Dị vật'],
        recommendedActions: ['Nội soi phế quản', 'Vật lý trị liệu hô hấp']
      }
    ],
    impression: 'Khối u vùng rốn phổi phải 4.2cm, bờ gai tua - rất nghi ngờ ung thư phổi. Xẹp thùy trên phải do tắc nghẽn. Đề nghị: CT ngực cản quang, PET-CT, sinh thiết.'
  },
  {
    id: 'case-003',
    patientId: 'BN-2024-0956',
    patientName: 'Lê Văn C.',
    age: 72,
    gender: 'M',
    examDate: '2024-03-20',
    examType: 'chest_pa',
    clinicalHistory: 'Khó thở nặng, phù hai chân, tiền sử suy tim, rung nhĩ.',
    findings: [
      {
        id: 'f6',
        type: 'pulmonary_edema',
        name: 'Bilateral Pulmonary Edema',
        nameVi: 'Phù phổi hai bên',
        description: 'Opacity dạng kính mờ lan tỏa hai bên, tập trung vùng cạnh rốn phổi (hình cánh bướm). Đường Kerley B ở vùng đáy. Tràn dịch màng phổi hai bên.',
        location: 'Hai bên, ưu thế cạnh rốn phổi',
        severity: 'severe',
        confidence: 95,
        measurements: [
          { label: 'Mức độ phù phổi', value: 'Nặng - hình cánh bướm' },
          { label: 'Đường Kerley B', value: 'Có ở cả hai đáy phổi' },
          { label: 'Tràn dịch màng phổi', value: 'Hai bên, phải > trái' }
        ],
        clinicalSignificance: 'Phù phổi cấp do suy tim mất bù. Cần điều trị khẩn cấp.',
        differentialDiagnosis: ['Phù phổi do tim', 'ARDS', 'Viêm phổi hai bên'],
        recommendedActions: ['Furosemide TM', 'Thở oxy/CPAP', 'Siêu âm tim cấp cứu', 'Troponin, BNP']
      },
      {
        id: 'f7',
        type: 'cardiomegaly',
        name: 'Severe Cardiomegaly',
        nameVi: 'Bóng tim to nặng',
        description: 'CTR = 0.68, bóng tim to toàn bộ, cung dưới trái phồng, cung trên trái giãn. Tĩnh mạch phổi trên giãn.',
        location: 'Trung thất',
        severity: 'severe',
        confidence: 97,
        measurements: [
          { label: 'CTR', value: '0.68' },
          { label: 'Tĩnh mạch phổi trên', value: 'Giãn' }
        ],
        clinicalSignificance: 'Giãn buồng tim nặng, phù hợp suy tim giai đoạn cuối.',
        differentialDiagnosis: ['Suy tim giãn', 'Bệnh van tim', 'Bệnh cơ tim'],
        recommendedActions: ['Siêu âm tim', 'Đánh giá chức năng thất trái', 'Tối ưu hóa điều trị suy tim']
      },
      {
        id: 'f8',
        type: 'pleural_effusion',
        name: 'Bilateral Pleural Effusion',
        nameVi: 'Tràn dịch màng phổi hai bên',
        description: 'Mờ đáy phổi hai bên, mất góc sườn-hoành. Bên phải nhiều hơn bên trái. Mức nước-electrolyte thấy rõ bên phải.',
        location: 'Hai khoang màng phổi',
        severity: 'moderate',
        confidence: 93,
        measurements: [
          { label: 'Bên phải', value: 'Trung bình, mức dịch thấy rõ' },
          { label: 'Bên trái', value: 'Ít, chỉ mờ góc sườn-hoành' }
        ],
        clinicalSignificance: 'Tràn dịch màng phổi do suy tim, dịch thấm.',
        differentialDiagnosis: ['Suy tim', 'Viêm màng phổi', 'Ung thư'],
        recommendedActions: ['Chọc dịch màng phổi nếu không đáp ứng điều trị', 'Xét nghiệm dịch: Light criteria']
      }
    ],
    impression: 'Phù phổi hai bên mức độ nặng (hình cánh bướm), bóng tim to (CTR 0.68), tràn dịch màng phổi hai bên. Phù hợp suy tim mất bù cấp. Đề nghị điều trị khẩn.'
  },
  {
    id: 'case-004',
    patientId: 'BN-2024-1003',
    patientName: 'Phạm Văn D.',
    age: 45,
    gender: 'M',
    examDate: '2024-03-22',
    examType: 'abdomen_supine',
    clinicalHistory: 'Đau bụng dữ dội, nôn, không trung tiện 2 ngày. Tiền sử mổ ruột thừa.',
    findings: [
      {
        id: 'f9',
        type: 'intestinal_obstruction',
        name: 'Small Bowel Obstruction',
        nameVi: 'Tắc ruột non',
        description: 'Quai ruột non giãn nhiều, đường kính >3cm, có mức nước-hơi bậc thang. Ruột đại tràng xẹp.',
        location: 'Vùng giữa bụng, ruột non',
        severity: 'severe',
        confidence: 96,
        measurements: [
          { label: 'Đường kính quai ruột lớn nhất', value: '4.8 cm' },
          { label: 'Số mức nước-hơi', value: '>6 mức' },
          { label: 'Đại tràng', value: 'Xẹp, ít hơi' }
        ],
        clinicalSignificance: 'Tắc ruột non cơ học, có thể do dính sau mổ. Cần đánh giá ngoại khoa.',
        differentialDiagnosis: ['Tắc do dính', 'Thoát vị nghẹt', 'Lồng ruột', 'U chèn ép'],
        recommendedActions: ['Đặt sonde dạ dày', 'Bù dịch điện giải', 'CT bụng có thuốc cản quang', 'Hội chẩn ngoại khoa']
      },
      {
        id: 'f10',
        type: 'foreign_body',
        name: 'Surgical Clips',
        nameVi: 'Kẹp phẫu thuật',
        description: 'Hình ảnh cản quang dạng kẹp nhỏ vùng hố chậu phải, phù hợp kẹp phẫu thuật sau mổ ruột thừa.',
        location: 'Hố chậu phải',
        severity: 'mild',
        confidence: 99,
        measurements: [
          { label: 'Số lượng', value: '2 kẹp' },
          { label: 'Vị trí', value: 'Phù hợp vị trí mổ cũ' }
        ],
        clinicalSignificance: 'Bình thường sau phẫu thuật, không liên quan bệnh lý hiện tại.',
        differentialDiagnosis: [],
        recommendedActions: ['Không cần xử trí']
      }
    ],
    impression: 'Tắc ruột non cơ học, quai ruột giãn đến 4.8cm, nhiều mức nước-hơi. Đại tràng xẹp. Kẹp phẫu thuật vùng HCP sau mổ cũ. Đề nghị: hội chẩn ngoại khoa.'
  },
  {
    id: 'case-005',
    patientId: 'BN-2024-1045',
    patientName: 'Hoàng Thị E.',
    age: 58,
    gender: 'F',
    examDate: '2024-03-25',
    examType: 'abdomen_erect',
    clinicalHistory: 'Đau bụng đột ngột, bụng cứng, nghi thủng tạng rỗng.',
    findings: [
      {
        id: 'f11',
        type: 'free_air',
        name: 'Pneumoperitoneum',
        nameVi: 'Hơi tự do ổ bụng',
        description: 'Hình liềm sáng dưới cơ hoành phải, rõ trên phim tư thế đứng. Dấu hiệu Rigler: thấy rõ cả hai mặt của thành ruột.',
        location: 'Dưới cơ hoành phải',
        severity: 'critical',
        confidence: 98,
        measurements: [
          { label: 'Kích thước liềm hơi', value: 'Chiều cao ~3cm' },
          { label: 'Dấu hiệu Rigler', value: 'Dương tính' },
          { label: 'Dấu hiệu Cupola', value: 'Có' }
        ],
        clinicalSignificance: 'Thủng tạng rỗng - cấp cứu ngoại khoa. Cần mổ cấp cứu.',
        differentialDiagnosis: ['Thủng loét dạ dày-tá tràng', 'Thủng ruột', 'Viêm túi thừa thủng'],
        recommendedActions: ['MỔ CẤP CỨU', 'Kháng sinh phổ rộng TM', 'Bù dịch, hồi sức', 'Chuẩn bị trước mổ']
      },
      {
        id: 'f12',
        type: 'calcification',
        name: 'Aortic Calcification',
        nameVi: 'Vôi hóa động mạch chủ',
        description: 'Hình ảnh vôi hóa thành động mạch chủ bụng, chạy dọc cột sống.',
        location: 'Đường giữa, vùng cạnh cột sống',
        severity: 'mild',
        confidence: 92,
        measurements: [
          { label: 'Mức độ vôi hóa', value: 'Trung bình' },
          { label: 'Phân bố', value: 'ĐM chủ bụng đoạn dưới thận' }
        ],
        clinicalSignificance: 'Xơ vữa động mạch, yếu tố nguy cơ tim mạch.',
        differentialDiagnosis: [],
        recommendedActions: ['Siêu âm ĐM chủ bụng', 'Đánh giá yếu tố nguy cơ tim mạch']
      }
    ],
    impression: 'Hơi tự do ổ bụng - thủng tạng rỗng. CẤP CỨU NGOẠI KHOA. Vôi hóa ĐM chủ bụng. Đề nghị: mổ cấp cứu ngay.'
  },
  {
    id: 'case-006',
    patientId: 'BN-2024-1089',
    patientName: 'Vũ Văn F.',
    age: 34,
    gender: 'M',
    examDate: '2024-03-28',
    examType: 'chest_pa',
    clinicalHistory: 'Tai nạn giao thông, đau ngực trái, khó thở sau chấn thương 2 giờ.',
    findings: [
      {
        id: 'f13',
        type: 'rib_fracture',
        name: 'Multiple Rib Fractures',
        nameVi: 'Gãy nhiều xương sườn',
        description: 'Gãy xương sườn 4, 5, 6 bên trái ở vị trí cung trước-ngoài. Có di lệch nhẹ. Gãy xương sườn 7 bên phải.',
        location: 'Cung trước-ngoài sườn 4-6 trái, sườn 7 phải',
        severity: 'severe',
        confidence: 97,
        measurements: [
          { label: 'Số xương sườn gãy', value: '4 (3 trái, 1 phải)' },
          { label: 'Di lệch', value: 'Có, nhẹ' },
          { label: 'Mảng sườn di động', value: 'Nghi ngờ' }
        ],
        clinicalSignificance: 'Gãy nhiều xương sườn, nguy cơ mảng sườn di động và suy hô hấp.',
        differentialDiagnosis: [],
        recommendedActions: ['Giảm đau tích cực', 'Theo dõi SpO2, khí máu', 'CT ngực đánh giá tổn thương phổi', 'Vật lý trị liệu hô hấp']
      },
      {
        id: 'f14',
        type: 'pneumothorax',
        name: 'Left Traumatic Pneumothorax',
        nameVi: 'Tràn khí màng phổi trái do chấn thương',
        description: 'Tràn khí màng phổi trái, đường tràn khí thấy rõ, phổi xẹp khoảng 40%. Có kèm tràn máu màng phổi mức nhẹ.',
        location: 'Khoang màng phổi trái',
        severity: 'severe',
        confidence: 95,
        measurements: [
          { label: 'Mức độ tràn khí', value: '~40%' },
          { label: 'Tràn máu', value: 'Có, mức nhẹ' },
          { label: 'Đường giữa', value: 'Lệch phải nhẹ' }
        ],
        clinicalSignificance: 'Tràn máu khí màng phổi do chấn thương. Cần dẫn lưu.',
        differentialDiagnosis: [],
        recommendedActions: ['Dẫn lưu màng phổi cấp cứu', 'Theo dõi lượng máu dẫn lưu', 'Đánh giá mổ nếu máu >1500ml']
      },
      {
        id: 'f15',
        type: 'consolidation',
        name: 'Left Lung Contusion',
        nameVi: 'Đụng dập phổi trái',
        description: 'Opacity dạng mảng không đều ở phổi trái, vùng ngoại vi, tương ứng vùng chấn thương.',
        location: 'Phổi trái, vùng ngoại vi',
        severity: 'moderate',
        confidence: 88,
        measurements: [
          { label: 'Kích thước vùng đụng dập', value: '6 × 4 cm' },
          { label: 'Tiến triển', value: 'Có thể tăng trong 24-48h' }
        ],
        clinicalSignificance: 'Đụng dập phổi, cần theo dõi sát vì có thể tiến triển nặng.',
        differentialDiagnosis: ['Viêm phổi hít', 'Xuất huyết phổi'],
        recommendedActions: ['Thở oxy', 'Hạn chế dịch', 'Chụp CT kiểm tra sau 24h']
      }
    ],
    impression: 'Chấn thương ngực kín: gãy sườn 4-6 trái + sườn 7 phải, tràn máu khí màng phổi trái ~40%, đụng dập phổi trái. Đề nghị: dẫn lưu MKP, theo dõi sát.'
  }
];

export const findingTypeLabels: Record<FindingType, { vi: string; color: string; icon: string }> = {
  pneumothorax: { vi: 'Tràn khí màng phổi', color: '#ef4444', icon: '💨' },
  pleural_effusion: { vi: 'Tràn dịch màng phổi', color: '#3b82f6', icon: '💧' },
  cardiomegaly: { vi: 'Bóng tim to', color: '#f59e0b', icon: '❤️' },
  lung_nodule: { vi: 'Nốt/Khối phổi', color: '#dc2626', icon: '⚫' },
  consolidation: { vi: 'Đông đặc phổi', color: '#f97316', icon: '🫁' },
  rib_fracture: { vi: 'Gãy xương sườn', color: '#a855f7', icon: '🦴' },
  pulmonary_edema: { vi: 'Phù phổi', color: '#06b6d4', icon: '🌊' },
  atelectasis: { vi: 'Xẹp phổi', color: '#64748b', icon: '📉' },
  hiatal_hernia: { vi: 'Thoát vị hoành', color: '#84cc16', icon: '⬆️' },
  intestinal_obstruction: { vi: 'Tắc ruột', color: '#eab308', icon: '🚫' },
  free_air: { vi: 'Hơi tự do', color: '#dc2626', icon: '⚠️' },
  calcification: { vi: 'Vôi hóa', color: '#94a3b8', icon: '⚪' },
  foreign_body: { vi: 'Dị vật', color: '#78716c', icon: '📌' },
  scoliosis: { vi: 'Vẹo cột sống', color: '#6366f1', icon: '📐' },
  mediastinal_shift: { vi: 'Lệch trung thất', color: '#be123c', icon: '↔️' }
};
