import { useState, useEffect, useCallback } from 'react';
import type { CaseStudy, KnowledgeEntry } from '../types';
import { DEFAULT_CASES, DEFAULT_KNOWLEDGE } from '../data/defaults';

const CASES_KEY = 'radai_cases';
const KNOWLEDGE_KEY = 'radai_knowledge';

function loadFromStorage<T>(key: string, defaults: T[]): T[] {
  try {
    const stored = localStorage.getItem(key);
    if (stored) return JSON.parse(stored);
  } catch (e) {
    console.error('Error loading from storage:', e);
  }
  return defaults;
}

function saveToStorage<T>(key: string, data: T[]) {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (e) {
    console.error('Error saving to storage:', e);
  }
}

export function useCases() {
  const [cases, setCases] = useState<CaseStudy[]>(() => loadFromStorage(CASES_KEY, DEFAULT_CASES));

  useEffect(() => {
    saveToStorage(CASES_KEY, cases);
  }, [cases]);

  const addCase = useCallback((newCase: CaseStudy) => {
    setCases(prev => [newCase, ...prev]);
  }, []);

  const updateCase = useCallback((updatedCase: CaseStudy) => {
    setCases(prev => prev.map(c => c.id === updatedCase.id ? updatedCase : c));
  }, []);

  const deleteCase = useCallback((id: string) => {
    setCases(prev => prev.filter(c => c.id !== id));
  }, []);

  const duplicateCase = useCallback((id: string) => {
    setCases(prev => {
      const original = prev.find(c => c.id === id);
      if (!original) return prev;
      const copy: CaseStudy = {
        ...original,
        id: `case-${Date.now()}`,
        title: `${original.title} (Bản sao)`,
        createdAt: new Date().toISOString().split('T')[0],
        isTemplate: false,
      };
      return [copy, ...prev];
    });
  }, []);

  return { cases, addCase, updateCase, deleteCase, duplicateCase };
}

export function useKnowledge() {
  const [entries, setEntries] = useState<KnowledgeEntry[]>(() => loadFromStorage(KNOWLEDGE_KEY, DEFAULT_KNOWLEDGE));

  useEffect(() => {
    saveToStorage(KNOWLEDGE_KEY, entries);
  }, [entries]);

  const addEntry = useCallback((entry: KnowledgeEntry) => {
    setEntries(prev => [entry, ...prev]);
  }, []);

  const updateEntry = useCallback((entry: KnowledgeEntry) => {
    setEntries(prev => prev.map(e => e.id === entry.id ? entry : e));
  }, []);

  const deleteEntry = useCallback((id: string) => {
    setEntries(prev => prev.filter(e => e.id !== id));
  }, []);

  return { entries, addEntry, updateEntry, deleteEntry };
}
