export type Severity = 'mild' | 'moderate' | 'severe' | 'critical';

export interface Finding {
  id: string;
  name: string;
  description: string;
  severity: Severity;
  location: string;
  radiographicSign: string;
  differentialDiagnosis: string[];
  clinicalCorrelation: string;
  confidence: number;
  x: number;
  y: number;
  radius: number;
  type: 'opacity' | 'lucency' | 'fracture' | 'calcification' | 'mass' | 'effusion' | 'foreign_body' | 'deformity' | 'pneumothorax' | 'cardiomegaly';
}

export interface CaseStudy {
  id: string;
  title: string;
  patientAge: number;
  patientGender: 'M' | 'F';
  clinicalHistory: string;
  examType: 'chest_pa' | 'chest_lateral' | 'abdomen_supine' | 'abdomen_erect';
  findings: Finding[];
  diagnosis: string;
  notes: string;
  tags: string[];
  createdAt: string;
  isTemplate: boolean;
}

export interface KnowledgeEntry {
  id: string;
  title: string;
  category: string;
  content: string;
  tags: string[];
  createdAt: string;
  updatedAt: string;
}
