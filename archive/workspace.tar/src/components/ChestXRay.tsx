import React from 'react';
import { FindingType } from '../data/cases';

interface ChestXRayProps {
  activeFindings: Set<FindingType>;
  view?: 'PA' | 'Lateral';
  highlightedFinding?: FindingType | null;
}

const ChestXRay: React.FC<ChestXRayProps> = ({ activeFindings, view = 'PA', highlightedFinding }) => {
  const isActive = (type: FindingType) => activeFindings.has(type);
  const isHighlighted = (type: FindingType) => highlightedFinding === type;

  return (
    <svg viewBox="0 0 600 700" className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
      <defs>
        {/* Film background gradient - simulates X-ray film */}
        <radialGradient id="filmBg" cx="50%" cy="45%" r="55%">
          <stop offset="0%" stopColor="#1a1a2e" />
          <stop offset="70%" stopColor="#0d0d1a" />
          <stop offset="100%" stopColor="#050510" />
        </radialGradient>

        {/* Lung field gradient */}
        <radialGradient id="lungFieldRight" cx="35%" cy="45%" r="50%">
          <stop offset="0%" stopColor="#2a2a3e" stopOpacity="0.3" />
          <stop offset="60%" stopColor="#1e1e30" stopOpacity="0.5" />
          <stop offset="100%" stopColor="#15152a" stopOpacity="0.8" />
        </radialGradient>
        <radialGradient id="lungFieldLeft" cx="65%" cy="45%" r="50%">
          <stop offset="0%" stopColor="#2a2a3e" stopOpacity="0.3" />
          <stop offset="60%" stopColor="#1e1e30" stopOpacity="0.5" />
          <stop offset="100%" stopColor="#15152a" stopOpacity="0.8" />
        </radialGradient>

        {/* Heart gradient */}
        <radialGradient id="heartGrad" cx="45%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#4a4a5e" stopOpacity="0.9" />
          <stop offset="70%" stopColor="#3a3a50" stopOpacity="0.95" />
          <stop offset="100%" stopColor="#2a2a40" />
        </radialGradient>

        {/* Enlarged heart gradient */}
        <radialGradient id="heartGradLarge" cx="45%" cy="50%" r="55%">
          <stop offset="0%" stopColor="#5a5a6e" stopOpacity="0.9" />
          <stop offset="70%" stopColor="#4a4a60" stopOpacity="0.95" />
          <stop offset="100%" stopColor="#3a3a50" />
        </radialGradient>

        {/* Bone gradient */}
        <linearGradient id="boneGrad" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#8a8a9a" stopOpacity="0.6" />
          <stop offset="50%" stopColor="#b0b0c0" stopOpacity="0.8" />
          <stop offset="100%" stopColor="#8a8a9a" stopOpacity="0.6" />
        </linearGradient>

        {/* Consolidation gradient */}
        <radialGradient id="consolidationGrad" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#6a6a7e" stopOpacity="0.7" />
          <stop offset="60%" stopColor="#5a5a6e" stopOpacity="0.5" />
          <stop offset="100%" stopColor="#4a4a5e" stopOpacity="0.2" />
        </radialGradient>

        {/* Nodule gradient */}
        <radialGradient id="noduleGrad" cx="40%" cy="40%" r="50%">
          <stop offset="0%" stopColor="#7a7a8e" stopOpacity="0.9" />
          <stop offset="60%" stopColor="#5a5a6e" stopOpacity="0.8" />
          <stop offset="100%" stopColor="#4a4a5e" stopOpacity="0.6" />
        </radialGradient>

        {/* Effusion gradient */}
        <linearGradient id="effusionGrad" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#4a4a5e" stopOpacity="0.3" />
          <stop offset="50%" stopColor="#5a5a70" stopOpacity="0.7" />
          <stop offset="100%" stopColor="#6a6a80" stopOpacity="0.9" />
        </linearGradient>

        {/* Pulmonary edema */}
        <radialGradient id="edemaGrad" cx="50%" cy="40%" r="60%">
          <stop offset="0%" stopColor="#5a5a70" stopOpacity="0.6" />
          <stop offset="50%" stopColor="#4a4a60" stopOpacity="0.4" />
          <stop offset="100%" stopColor="#3a3a50" stopOpacity="0.1" />
        </radialGradient>

        {/* Pneumothorax - lucent area */}
        <linearGradient id="ptxGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#0a0a15" stopOpacity="0.9" />
          <stop offset="100%" stopColor="#050510" stopOpacity="0.7" />
        </linearGradient>

        {/* Glow filter for highlighted findings */}
        <filter id="glow">
          <feGaussianBlur stdDeviation="3" result="coloredBlur" />
          <feMerge>
            <feMergeNode in="coloredBlur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>

        {/* Film grain */}
        <filter id="grain">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="4" result="noise" />
          <feColorMatrix type="saturate" values="0" in="noise" result="grayNoise" />
          <feBlend in="SourceGraphic" in2="grayNoise" mode="multiply" />
        </filter>

        <filter id="softBlur">
          <feGaussianBlur stdDeviation="1.5" />
        </filter>

        {/* Vascular marking pattern */}
        <pattern id="vascularPattern" x="0" y="0" width="100" height="100" patternUnits="userSpaceOnUse">
          <path d="M50,10 Q55,30 50,50 Q45,70 50,90" stroke="#3a3a4e" strokeWidth="0.5" fill="none" opacity="0.4" />
          <path d="M30,20 Q35,40 30,60 Q25,80 30,100" stroke="#3a3a4e" strokeWidth="0.3" fill="none" opacity="0.3" />
          <path d="M70,15 Q75,35 70,55 Q65,75 70,95" stroke="#3a3a4e" strokeWidth="0.3" fill="none" opacity="0.3" />
        </pattern>
      </defs>

      {/* Background - X-ray film */}
      <rect width="600" height="700" fill="url(#filmBg)" />
      
      {/* Film border */}
      <rect x="5" y="5" width="590" height="690" fill="none" stroke="#1a1a2e" strokeWidth="2" rx="3" />

      {/* Patient info overlay (top) */}
      <text x="20" y="25" fill="#4a4a5e" fontSize="9" fontFamily="monospace">R  |  CHEST PA  |  2024-03-15</text>
      <text x="430" y="25" fill="#4a4a5e" fontSize="9" fontFamily="monospace">SID: 180cm | 72kVp</text>

      {/* Soft tissue outline - body contour */}
      <path d="M150,80 Q140,90 130,120 Q120,160 115,200 Q110,280 108,350 Q105,420 108,500 Q110,560 115,600 Q120,640 130,660 L470,660 Q480,640 485,600 Q490,560 492,500 Q495,420 492,350 Q490,280 485,200 Q480,160 470,120 Q460,90 450,80" 
        fill="none" stroke="#2a2a3e" strokeWidth="1.5" opacity="0.5" />

      {/* Shoulder soft tissue */}
      <path d="M150,80 Q130,85 100,100 Q80,115 70,140" fill="none" stroke="#2a2a3e" strokeWidth="2" opacity="0.4" />
      <path d="M450,80 Q470,85 500,100 Q520,115 530,140" fill="none" stroke="#2a2a3e" strokeWidth="2" opacity="0.4" />

      {/* Clavicles */}
      <path d="M300,95 Q250,90 200,95 Q160,100 130,110" fill="none" stroke="url(#boneGrad)" strokeWidth="6" strokeLinecap="round" opacity="0.7" />
      <path d="M300,95 Q350,90 400,95 Q440,100 470,110" fill="none" stroke="url(#boneGrad)" strokeWidth="6" strokeLinecap="round" opacity="0.7" />

      {/* Spine - vertebral bodies */}
      {Array.from({ length: 12 }, (_, i) => (
        <g key={`vert-${i}`}>
          <rect x="280" y={110 + i * 42} width="40" height="35" rx="3" fill="#3a3a4e" opacity="0.6" />
          <line x1="300" y1={110 + i * 42} x2="300" y2={145 + i * 42} stroke="#4a4a5e" strokeWidth="1" opacity="0.4" />
          {/* Spinous process */}
          <line x1="300" y1={127 + i * 42} x2="300" y2={135 + i * 42} stroke="#5a5a6e" strokeWidth="3" opacity="0.5" />
        </g>
      ))}

      {/* Ribs - Right side (viewer's left = patient's right) */}
      {/* Posterior ribs */}
      {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((i) => (
        <path key={`rib-post-r-${i}`}
          d={`M280,${130 + i * 42} Q240,${135 + i * 42} 200,${145 + i * 42} Q160,${155 + i * 42} 130,${170 + i * 42}`}
          fill="none" stroke="#7a7a8e" strokeWidth="4" opacity={0.5 - i * 0.02} strokeLinecap="round"
        />
      ))}
      {/* Anterior ribs - Right */}
      {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((i) => (
        <path key={`rib-ant-r-${i}`}
          d={`M280,${135 + i * 42} Q250,${150 + i * 42} 220,${170 + i * 42} Q190,${190 + i * 42} 170,${210 + i * 42}`}
          fill="none" stroke="#6a6a7e" strokeWidth="3" opacity={0.4 - i * 0.02} strokeLinecap="round"
        />
      ))}

      {/* Ribs - Left side */}
      {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((i) => (
        <path key={`rib-post-l-${i}`}
          d={`M320,${130 + i * 42} Q360,${135 + i * 42} 400,${145 + i * 42} Q440,${155 + i * 42} 470,${170 + i * 42}`}
          fill="none" stroke="#7a7a8e" strokeWidth="4" opacity={0.5 - i * 0.02} strokeLinecap="round"
        />
      ))}
      {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((i) => (
        <path key={`rib-ant-l-${i}`}
          d={`M320,${135 + i * 42} Q350,${150 + i * 42} 380,${170 + i * 42} Q410,${190 + i * 42} 430,${210 + i * 42}`}
          fill="none" stroke="#6a6a7e" strokeWidth="3" opacity={0.4 - i * 0.02} strokeLinecap="round"
        />
      ))}

      {/* Lung fields - vascular markings */}
      <rect x="120" y="100" width="170" height="450" fill="url(#vascularPattern)" opacity="0.5" />
      <rect x="310" y="100" width="170" height="450" fill="url(#vascularPattern)" opacity="0.5" />

      {/* Bronchovascular markings - Right lung */}
      <g opacity="0.5">
        <path d="M290,180 Q260,220 240,280 Q220,340 210,400" stroke="#3a3a50" strokeWidth="2" fill="none" />
        <path d="M285,200 Q250,240 230,300" stroke="#3a3a50" strokeWidth="1.5" fill="none" />
        <path d="M280,220 Q255,260 240,320 Q225,380 220,430" stroke="#3a3a50" strokeWidth="1" fill="none" />
        <path d="M275,250 Q250,290 235,350" stroke="#3a3a50" strokeWidth="1" fill="none" />
        <path d="M270,280 Q245,320 230,380 Q220,420 215,450" stroke="#3a3a50" strokeWidth="0.8" fill="none" />
      </g>

      {/* Bronchovascular markings - Left lung */}
      <g opacity="0.5">
        <path d="M310,180 Q340,220 360,280 Q380,340 390,400" stroke="#3a3a50" strokeWidth="2" fill="none" />
        <path d="M315,200 Q350,240 370,300" stroke="#3a3a50" strokeWidth="1.5" fill="none" />
        <path d="M320,220 Q345,260 360,320 Q375,380 380,430" stroke="#3a3a50" strokeWidth="1" fill="none" />
        <path d="M325,250 Q350,290 365,350" stroke="#3a3a50" strokeWidth="1" fill="none" />
        <path d="M330,280 Q355,320 370,380 Q380,420 385,450" stroke="#3a3a50" strokeWidth="0.8" fill="none" />
      </g>

      {/* Horizontal fissure - Right */}
      <path d="M285,280 Q240,275 190,285 Q160,290 140,300" stroke="#4a4a5e" strokeWidth="1.5" fill="none" opacity="0.5" strokeDasharray="3,2" />
      
      {/* Oblique fissure - Right */}
      <path d="M290,200 Q260,300 230,400 Q210,470 200,520" stroke="#4a4a5e" strokeWidth="1" fill="none" opacity="0.4" strokeDasharray="3,2" />
      
      {/* Oblique fissure - Left */}
      <path d="M310,200 Q340,300 370,400 Q390,470 400,520" stroke="#4a4a5e" strokeWidth="1" fill="none" opacity="0.4" strokeDasharray="3,2" />

      {/* Trachea */}
      <path d="M295,50 L295,130 M305,50 L305,130" stroke="#5a5a6e" strokeWidth="2" fill="none" opacity="0.6" />
      <rect x="293" y="50" width="14" height="80" fill="#1a1a2e" opacity="0.5" rx="2" />

      {/* Carina */}
      <path d="M300,130 Q280,150 260,170" stroke="#5a5a6e" strokeWidth="2" fill="none" opacity="0.5" />
      <path d="M300,130 Q320,150 340,170" stroke="#5a5a6e" strokeWidth="2" fill="none" opacity="0.5" />

      {/* Hila */}
      <ellipse cx="260" cy="200" rx="30" ry="40" fill="#4a4a5e" opacity="0.5" />
      <ellipse cx="340" cy="205" rx="25" ry="35" fill="#4a4a5e" opacity="0.5" />

      {/* Diaphragm */}
      <path d="M120,520 Q180,480 240,490 Q280,495 300,500 Q320,495 360,490 Q420,480 480,520" 
        fill="none" stroke="#6a6a7e" strokeWidth="3" opacity="0.7" />
      {/* Right hemidiaphragm */}
      <path d="M130,520 Q180,485 240,492 Q270,497 300,502" 
        fill="none" stroke="#7a7a8e" strokeWidth="2.5" opacity="0.6" />
      {/* Left hemidiaphragm */}
      <path d="M300,502 Q330,497 360,492 Q420,485 470,520" 
        fill="none" stroke="#7a7a8e" strokeWidth="2.5" opacity="0.6" />

      {/* Costophrenic angles */}
      <path d="M120,520 Q115,540 118,560" stroke="#5a5a6e" strokeWidth="2" fill="none" opacity="0.5" />
      <path d="M480,520 Q485,540 482,560" stroke="#5a5a6e" strokeWidth="2" fill="none" opacity="0.5" />

      {/* ============ PATHOLOGICAL FINDINGS ============ */}

      {/* PNEUMOTHORAX - Right */}
      {isActive('pneumothorax') && (
        <g filter={isHighlighted('pneumothorax') ? 'url(#glow)' : undefined} className="transition-opacity duration-500">
          {/* Lucent area - no lung markings */}
          <path d="M130,100 Q120,120 118,180 Q115,250 120,320 Q125,350 135,370 L170,370 Q165,300 168,230 Q170,170 175,130 Q178,110 170,100 Z"
            fill="url(#ptxGrad)" opacity="0.8" />
          {/* Visceral pleural line */}
          <path d="M170,100 Q175,130 170,170 Q168,230 165,300 Q163,340 170,370"
            fill="none" stroke="#8a8a9e" strokeWidth="1.5" opacity="0.9" />
          {/* Absent peripheral markings */}
          <text x="135" y="200" fill="#ef4444" fontSize="8" opacity="0.8">← PTX</text>
        </g>
      )}

      {/* PLEURAL EFFUSION */}
      {isActive('pleural_effusion') && (
        <g filter={isHighlighted('pleural_effusion') ? 'url(#glow)' : undefined} className="transition-opacity duration-500">
          {/* Right effusion - meniscus sign */}
          <path d="M120,480 Q140,440 180,430 Q220,425 260,435 Q280,440 290,460 L290,560 L120,560 Z"
            fill="url(#effusionGrad)" opacity="0.7" />
          {/* Left effusion - smaller */}
          <path d="M310,490 Q350,470 400,465 Q440,462 470,480 L480,560 L310,560 Z"
            fill="url(#effusionGrad)" opacity="0.5" />
          {/* Meniscus curves */}
          <path d="M120,480 Q140,440 180,430 Q220,425 260,435 Q280,440 290,460"
            fill="none" stroke="#6a6a80" strokeWidth="1.5" opacity="0.8" />
          {/* Blunted costophrenic angle */}
          <path d="M120,520 Q125,510 130,505" stroke="#5a5a70" strokeWidth="2" fill="none" opacity="0.7" />
        </g>
      )}

      {/* CARDIOMEGALY */}
      {isActive('cardiomegaly') && (
        <g filter={isHighlighted('cardiomegaly') ? 'url(#glow)' : undefined} className="transition-opacity duration-500">
          {/* Enlarged cardiac silhouette */}
          <path d="M300,150 Q280,160 250,180 Q220,210 200,260 Q180,320 175,380 Q170,430 180,470 Q190,500 220,510 Q260,520 300,515 Q340,520 380,510 Q410,500 420,470 Q430,430 425,380 Q420,320 400,260 Q380,210 350,180 Q320,160 300,150"
            fill="url(#heartGradLarge)" opacity="0.85" />
          {/* Left heart border - prominent */}
          <path d="M200,260 Q180,320 175,380 Q170,430 180,470 Q190,500 220,510"
            fill="none" stroke="#6a6a7e" strokeWidth="2" opacity="0.7" />
          {/* Right heart border */}
          <path d="M400,260 Q420,320 425,380 Q430,430 420,470 Q410,500 380,510"
            fill="none" stroke="#6a6a7e" strokeWidth="2" opacity="0.7" />
          {/* CTR measurement lines */}
          <line x1="175" y1="540" x2="425" y2="540" stroke="#f59e0b" strokeWidth="0.5" strokeDasharray="3,2" opacity="0.6" />
          <line x1="175" y1="535" x2="175" y2="545" stroke="#f59e0b" strokeWidth="1" opacity="0.6" />
          <line x1="425" y1="535" x2="425" y2="545" stroke="#f59e0b" strokeWidth="1" opacity="0.6" />
          <text x="285" y="555" fill="#f59e0b" fontSize="8" opacity="0.7">CTR = 0.58-0.68</text>
        </g>
      )}

      {/* Default heart (when no cardiomegaly) */}
      {!isActive('cardiomegaly') && (
        <path d="M300,160 Q285,170 270,190 Q250,220 240,260 Q230,310 235,360 Q238,400 250,430 Q265,460 290,470 Q310,475 330,470 Q355,460 370,430 Q382,400 385,360 Q388,310 378,260 Q368,220 348,190 Q333,170 300,160"
          fill="url(#heartGrad)" opacity="0.8" />
      )}

      {/* LUNG NODULE / MASS */}
      {isActive('lung_nodule') && (
        <g filter={isHighlighted('lung_nodule') ? 'url(#glow)' : undefined} className="transition-opacity duration-500">
          {/* Spiculated mass */}
          <ellipse cx="240" cy="200" rx="28" ry="25" fill="url(#noduleGrad)" opacity="0.9" />
          {/* Spiculations */}
          {[0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330].map((angle, i) => {
            const rad = (angle * Math.PI) / 180;
            const x1 = 240 + Math.cos(rad) * 25;
            const y1 = 200 + Math.sin(rad) * 22;
            const x2 = 240 + Math.cos(rad) * (32 + (i % 3) * 4);
            const y2 = 200 + Math.sin(rad) * (28 + (i % 2) * 3);
            return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#7a7a8e" strokeWidth="1.5" opacity="0.7" />;
          })}
          {/* Central density variation */}
          <ellipse cx="235" cy="195" rx="12" ry="10" fill="#8a8a9e" opacity="0.4" />
        </g>
      )}

      {/* CONSOLIDATION */}
      {isActive('consolidation') && (
        <g filter={isHighlighted('consolidation') ? 'url(#glow)' : undefined} className="transition-opacity duration-500">
          {/* Right lower lobe consolidation */}
          <path d="M140,380 Q160,350 200,340 Q240,335 270,350 Q285,360 280,400 Q275,440 260,470 Q240,490 200,495 Q160,498 140,480 Q125,460 130,430 Q135,400 140,380"
            fill="url(#consolidationGrad)" opacity="0.7" />
          {/* Air bronchograms */}
          <line x1="200" y1="360" x2="195" y2="420" stroke="#2a2a3e" strokeWidth="1.5" opacity="0.6" />
          <line x1="220" y1="370" x2="215" y2="440" stroke="#2a2a3e" strokeWidth="1" opacity="0.5" />
          <line x1="180" y1="380" x2="178" y2="450" stroke="#2a2a3e" strokeWidth="1" opacity="0.5" />
          <line x1="240" y1="365" x2="235" y2="430" stroke="#2a2a3e" strokeWidth="1" opacity="0.4" />
          {/* Silhouette sign with diaphragm */}
          <path d="M140,490 Q180,485 220,488 Q250,490 270,495"
            fill="none" stroke="#5a5a6e" strokeWidth="1" opacity="0.4" strokeDasharray="2,2" />
        </g>
      )}

      {/* RIB FRACTURE */}
      {isActive('rib_fracture') && (
        <g filter={isHighlighted('rib_fracture') ? 'url(#glow)' : undefined} className="transition-opacity duration-500">
          {/* Fracture lines on ribs 4, 5, 6 - left side (viewer's right) */}
          {/* Rib 4 fracture */}
          <line x1="395" y1="285" x2="410" y2="295" stroke="#ffffff" strokeWidth="2" opacity="0.9" />
          <line x1="400" y1="282" x2="405" y2="298" stroke="#ffffff" strokeWidth="1.5" opacity="0.7" />
          {/* Displacement */}
          <path d="M395,285 Q400,280 405,283" stroke="#a855f7" strokeWidth="1" fill="none" opacity="0.8" />
          
          {/* Rib 5 fracture */}
          <line x1="405" y1="325" x2="420" y2="338" stroke="#ffffff" strokeWidth="2" opacity="0.9" />
          <line x1="410" y1="322" x2="415" y2="340" stroke="#ffffff" strokeWidth="1.5" opacity="0.7" />
          
          {/* Rib 6 fracture */}
          <line x1="415" y1="368" x2="430" y2="380" stroke="#ffffff" strokeWidth="2" opacity="0.9" />
          <line x1="420" y1="365" x2="425" y2="382" stroke="#ffffff" strokeWidth="1.5" opacity="0.7" />

          {/* Rib 7 fracture - right side */}
          <line x1="175" y1="405" x2="165" y2="415" stroke="#ffffff" strokeWidth="1.5" opacity="0.8" />

          {/* Soft tissue swelling */}
          <path d="M390,270 Q420,290 430,320 Q435,350 430,380"
            fill="none" stroke="#4a4a5e" strokeWidth="8" opacity="0.3" filter="url(#softBlur)" />
        </g>
      )}

      {/* PULMONARY EDEMA */}
      {isActive('pulmonary_edema') && (
        <g filter={isHighlighted('pulmonary_edema') ? 'url(#glow)' : undefined} className="transition-opacity duration-500">
          {/* Butterfly pattern - central opacity */}
          <path d="M200,250 Q230,220 270,230 Q290,235 300,240 Q310,235 330,230 Q370,220 400,250 Q420,280 410,320 Q400,360 370,380 Q340,395 300,390 Q260,395 230,380 Q200,360 190,320 Q180,280 200,250"
            fill="url(#edemaGrad)" opacity="0.6" />
          {/* Kerley B lines - right */}
          {[0, 1, 2, 3, 4].map((i) => (
            <line key={`kb-r-${i}`} x1={140 + i * 20} y1={500 - i * 5} x2={155 + i * 20} y2={500 - i * 5}
              stroke="#5a5a70" strokeWidth="1.5" opacity="0.7" />
          ))}
          {/* Kerley B lines - left */}
          {[0, 1, 2, 3, 4].map((i) => (
            <line key={`kb-l-${i}`} x1={420 + i * 15} y1={498 - i * 5} x2={435 + i * 15} y2={498 - i * 5}
              stroke="#5a5a70" strokeWidth="1.5" opacity="0.7" />
          ))}
          {/* Upper lobe vessel dilation */}
          <path d="M260,160 Q250,180 245,210" stroke="#5a5a70" strokeWidth="3" fill="none" opacity="0.5" />
          <path d="M340,160 Q350,180 355,210" stroke="#5a5a70" strokeWidth="3" fill="none" opacity="0.5" />
          {/* Peribronchial cuffing */}
          <circle cx="230" cy="280" r="8" fill="none" stroke="#5a5a70" strokeWidth="2" opacity="0.4" />
          <circle cx="370" cy="285" r="7" fill="none" stroke="#5a5a70" strokeWidth="2" opacity="0.4" />
        </g>
      )}

      {/* ATELECTASIS */}
      {isActive('atelectasis') && (
        <g filter={isHighlighted('atelectasis') ? 'url(#glow)' : undefined} className="transition-opacity duration-500">
          {/* Volume loss - elevated hilum */}
          <path d="M230,160 Q240,150 260,155 Q270,158 275,165"
            fill="none" stroke="#64748b" strokeWidth="2" opacity="0.7" />
          {/* Horizontal fissure displacement upward */}
          <path d="M275,240 Q240,230 200,235 Q170,240 150,250"
            fill="none" stroke="#64748b" strokeWidth="2" opacity="0.7" strokeDasharray="4,2" />
          {/* Linear atelectasis */}
          <path d="M180,180 Q200,175 230,180" stroke="#64748b" strokeWidth="1.5" fill="none" opacity="0.6" />
          <path d="M175,200 Q200,195 235,200" stroke="#64748b" strokeWidth="1" fill="none" opacity="0.5" />
          <path d="M185,220 Q210,215 240,220" stroke="#64748b" strokeWidth="1" fill="none" opacity="0.5" />
          {/* Tracheal deviation */}
          <path d="M298,50 L296,130" stroke="#64748b" strokeWidth="1" opacity="0.5" />
        </g>
      )}

      {/* MEDIASTINAL SHIFT */}
      {isActive('mediastinal_shift') && (
        <g filter={isHighlighted('mediastinal_shift') ? 'url(#glow)' : undefined} className="transition-opacity duration-500">
          {/* Tracheal deviation arrow */}
          <path d="M300,70 L320,70" stroke="#be123c" strokeWidth="2" opacity="0.8" />
          <polygon points="320,67 327,70 320,73" fill="#be123c" opacity="0.8" />
          {/* Heart displacement */}
          <path d="M300,300 Q330,300 350,310" stroke="#be123c" strokeWidth="1" fill="none" opacity="0.6" strokeDasharray="3,2" />
        </g>
      )}

      {/* Film edge markers */}
      <text x="15" y="350" fill="#3a3a4e" fontSize="12" fontWeight="bold" opacity="0.4">R</text>
      <text x="575" y="350" fill="#3a3a4e" fontSize="12" fontWeight="bold" opacity="0.4">L</text>

      {/* Scale markers */}
      <line x1="560" y1="100" x2="560" y2="600" stroke="#2a2a3e" strokeWidth="0.5" opacity="0.3" />
      {[0, 1, 2, 3, 4, 5].map((i) => (
        <g key={`scale-${i}`}>
          <line x1="555" y1={100 + i * 100} x2="565" y2={100 + i * 100} stroke="#2a2a3e" strokeWidth="0.5" opacity="0.3" />
          <text x="545" y={103 + i * 100} fill="#2a2a3e" fontSize="7" opacity="0.3">{i * 5}cm</text>
        </g>
      ))}
    </svg>
  );
};

export default ChestXRay;
