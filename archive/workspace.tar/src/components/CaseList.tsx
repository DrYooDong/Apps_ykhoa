import React from 'react';
import { Case, findingTypeLabels } from '../data/cases';
import { User, Calendar, FileText, AlertCircle } from 'lucide-react';

interface CaseListProps {
  cases: Case[];
  selectedCaseId: string;
  onSelectCase: (id: string) => void;
}

const CaseList: React.FC<CaseListProps> = ({ cases, selectedCaseId, onSelectCase }) => {
  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="px-4 py-3 border-b border-slate-700/50 bg-slate-800/50">
        <h2 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
          <FileText className="w-4 h-4 text-cyan-400" />
          Danh Sách Ca Bệnh
          <span className="ml-auto text-xs text-slate-500">{cases.length} cases</span>
        </h2>
      </div>

      {/* Case list */}
      <div className="flex-1 overflow-y-auto custom-scrollbar">
        {cases.map((c) => {
          const isSelected = c.id === selectedCaseId;
          const severityOrder: Record<string, number> = { mild: 0, moderate: 1, severe: 2, critical: 3 };
          const maxSeverity = c.findings.reduce<string>((max, f) => {
            return severityOrder[f.severity] > severityOrder[max] ? f.severity : max;
          }, 'mild');

          const severityColors: Record<string, string> = {
            mild: 'border-l-green-500',
            moderate: 'border-l-yellow-500',
            severe: 'border-l-orange-500',
            critical: 'border-l-red-500',
          };

          return (
            <button
              key={c.id}
              onClick={() => onSelectCase(c.id)}
              className={`w-full text-left px-4 py-3 border-b border-slate-700/30 border-l-3 transition-all duration-200 ${
                isSelected
                  ? 'bg-cyan-500/10 border-l-cyan-400'
                  : `hover:bg-slate-800/40 ${severityColors[maxSeverity]}`
              }`}
            >
              {/* Patient info */}
              <div className="flex items-center gap-2">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                  c.gender === 'M' ? 'bg-blue-500/20 text-blue-400' : 'bg-pink-500/20 text-pink-400'
                }`}>
                  <User className="w-4 h-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium text-slate-200 truncate">{c.patientName}</span>
                    {maxSeverity === 'critical' && (
                      <AlertCircle className="w-3.5 h-3.5 text-red-400 animate-pulse shrink-0" />
                    )}
                  </div>
                  <div className="flex items-center gap-2 text-[10px] text-slate-500">
                    <span>{c.patientId}</span>
                    <span>•</span>
                    <span>{c.age}T, {c.gender === 'M' ? 'Nam' : 'Nữ'}</span>
                  </div>
                </div>
              </div>

              {/* Exam info */}
              <div className="mt-2 flex items-center gap-3 text-[10px] text-slate-500">
                <span className="flex items-center gap-1">
                  <Calendar className="w-3 h-3" />
                  {c.examDate}
                </span>
                <span className="px-1.5 py-0.5 bg-slate-700/50 rounded text-slate-400">
                  {c.examType === 'chest_pa' ? 'Ngực thẳng' :
                   c.examType === 'chest_lateral' ? 'Ngực nghiêng' :
                   c.examType === 'abdomen_supine' ? 'Bụng nằm' : 'Bụng đứng'}
                </span>
              </div>

              {/* Finding tags */}
              <div className="mt-2 flex flex-wrap gap-1">
                {c.findings.slice(0, 3).map((f) => (
                  <span
                    key={f.id}
                    className="text-[9px] px-1.5 py-0.5 rounded-full border"
                    style={{
                      borderColor: findingTypeLabels[f.type].color + '40',
                      color: findingTypeLabels[f.type].color,
                      backgroundColor: findingTypeLabels[f.type].color + '15',
                    }}
                  >
                    {findingTypeLabels[f.type].icon} {findingTypeLabels[f.type].vi}
                  </span>
                ))}
                {c.findings.length > 3 && (
                  <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-slate-700/50 text-slate-400">
                    +{c.findings.length - 3}
                  </span>
                )}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default CaseList;
