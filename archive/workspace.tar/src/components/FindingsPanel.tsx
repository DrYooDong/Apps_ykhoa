import React from 'react';
import { Finding, findingTypeLabels } from '../data/cases';
import { AlertTriangle, Activity, Stethoscope, ClipboardList, Ruler, TrendingUp } from 'lucide-react';

interface FindingsPanelProps {
  findings: Finding[];
  activeFindings: Set<string>;
  highlightedFinding: string | null;
  onToggleFinding: (id: string) => void;
  onHighlightFinding: (id: string | null) => void;
  impression: string;
}

const severityConfig = {
  mild: { label: 'Nhẹ', color: 'bg-green-500/20 text-green-400 border-green-500/30', dot: 'bg-green-400' },
  moderate: { label: 'Trung bình', color: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30', dot: 'bg-yellow-400' },
  severe: { label: 'Nặng', color: 'bg-orange-500/20 text-orange-400 border-orange-500/30', dot: 'bg-orange-400' },
  critical: { label: 'Nguy kịch', color: 'bg-red-500/20 text-red-400 border-red-500/30', dot: 'bg-red-400 animate-pulse' },
};

const FindingsPanel: React.FC<FindingsPanelProps> = ({
  findings,
  activeFindings,
  highlightedFinding,
  onToggleFinding,
  onHighlightFinding,
  impression,
}) => {
  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="px-4 py-3 border-b border-slate-700/50 bg-slate-800/50">
        <h2 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
          <Activity className="w-4 h-4 text-cyan-400" />
          Phân Tích Tổn Thương
          <span className="ml-auto text-xs text-slate-500">{findings.length} phát hiện</span>
        </h2>
      </div>

      {/* Findings list */}
      <div className="flex-1 overflow-y-auto custom-scrollbar">
        {findings.map((finding) => {
          const typeInfo = findingTypeLabels[finding.type];
          const sevConfig = severityConfig[finding.severity];
          const isActive = activeFindings.has(finding.id);
          const isHighlighted = highlightedFinding === finding.id;

          return (
            <div
              key={finding.id}
              className={`border-b border-slate-700/30 transition-all duration-300 ${
                isHighlighted ? 'bg-slate-700/40 ring-1 ring-cyan-500/30' : 'hover:bg-slate-800/30'
              }`}
              onMouseEnter={() => onHighlightFinding(finding.id)}
              onMouseLeave={() => onHighlightFinding(null)}
            >
              {/* Finding header */}
              <div className="px-4 py-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-lg">{typeInfo.icon}</span>
                      <h3 className="text-sm font-medium text-slate-200">{finding.nameVi}</h3>
                      <span className={`text-[10px] px-1.5 py-0.5 rounded border ${sevConfig.color}`}>
                        {sevConfig.label}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5 italic">{finding.name}</p>
                  </div>
                  <button
                    onClick={() => onToggleFinding(finding.id)}
                    className={`relative w-10 h-5 rounded-full transition-all duration-300 ${
                      isActive ? 'bg-cyan-500' : 'bg-slate-600'
                    }`}
                  >
                    <span
                      className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-all duration-300 ${
                        isActive ? 'left-5.5' : 'left-0.5'
                      }`}
                      style={{ left: isActive ? '22px' : '2px' }}
                    />
                  </button>
                </div>

                {/* Confidence bar */}
                <div className="mt-2 flex items-center gap-2">
                  <span className="text-[10px] text-slate-500">Độ tin cậy:</span>
                  <div className="flex-1 h-1.5 bg-slate-700 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{
                        width: `${finding.confidence}%`,
                        backgroundColor: finding.confidence > 90 ? '#22c55e' : finding.confidence > 75 ? '#eab308' : '#ef4444',
                      }}
                    />
                  </div>
                  <span className="text-[10px] font-mono text-slate-400">{finding.confidence}%</span>
                </div>
              </div>

              {/* Expanded details */}
              {isActive && (
                <div className="px-4 pb-4 space-y-3 animate-in fade-in duration-300">
                  {/* Description */}
                  <div className="bg-slate-800/50 rounded-lg p-3 border border-slate-700/30">
                    <p className="text-xs text-slate-300 leading-relaxed">{finding.description}</p>
                    <div className="mt-2 flex items-center gap-1">
                      <Ruler className="w-3 h-3 text-slate-500" />
                      <span className="text-[10px] text-slate-500">Vị trí: {finding.location}</span>
                    </div>
                  </div>

                  {/* Measurements */}
                  {finding.measurements && finding.measurements.length > 0 && (
                    <div className="bg-slate-800/50 rounded-lg p-3 border border-slate-700/30">
                      <h4 className="text-[10px] font-semibold text-cyan-400 uppercase tracking-wider mb-2 flex items-center gap-1">
                        <Ruler className="w-3 h-3" />
                        Đo lường
                      </h4>
                      <div className="space-y-1.5">
                        {finding.measurements.map((m, i) => (
                          <div key={i} className="flex justify-between items-center">
                            <span className="text-[11px] text-slate-400">{m.label}</span>
                            <span className="text-[11px] font-mono text-slate-200 bg-slate-700/50 px-2 py-0.5 rounded">
                              {m.value}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Clinical Significance */}
                  <div className="bg-slate-800/50 rounded-lg p-3 border border-slate-700/30">
                    <h4 className="text-[10px] font-semibold text-amber-400 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                      <AlertTriangle className="w-3 h-3" />
                      Ý nghĩa lâm sàng
                    </h4>
                    <p className="text-[11px] text-slate-300 leading-relaxed">{finding.clinicalSignificance}</p>
                  </div>

                  {/* Differential Diagnosis */}
                  {finding.differentialDiagnosis.length > 0 && (
                    <div className="bg-slate-800/50 rounded-lg p-3 border border-slate-700/30">
                      <h4 className="text-[10px] font-semibold text-purple-400 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                        <Stethoscope className="w-3 h-3" />
                        Chẩn đoán phân biệt
                      </h4>
                      <ul className="space-y-1">
                        {finding.differentialDiagnosis.map((dd, i) => (
                          <li key={i} className="text-[11px] text-slate-400 flex items-start gap-1.5">
                            <span className="text-purple-400 mt-0.5">•</span>
                            {dd}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Recommended Actions */}
                  <div className="bg-slate-800/50 rounded-lg p-3 border border-slate-700/30">
                    <h4 className="text-[10px] font-semibold text-emerald-400 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                      <ClipboardList className="w-3 h-3" />
                      Đề xuất xử trí
                    </h4>
                    <ul className="space-y-1">
                      {finding.recommendedActions.map((action, i) => (
                        <li key={i} className="text-[11px] text-slate-300 flex items-start gap-1.5">
                          <TrendingUp className="w-3 h-3 text-emerald-400 mt-0.5 shrink-0" />
                          {action}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Impression */}
      <div className="px-4 py-3 border-t border-slate-700/50 bg-slate-800/50">
        <h3 className="text-[10px] font-semibold text-cyan-400 uppercase tracking-wider mb-1.5 flex items-center gap-1">
          <ClipboardList className="w-3 h-3" />
          Kết luận
        </h3>
        <p className="text-xs text-slate-300 leading-relaxed">{impression}</p>
      </div>
    </div>
  );
};

export default FindingsPanel;
