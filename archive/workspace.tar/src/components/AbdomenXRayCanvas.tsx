import { useEffect, useRef, useCallback } from 'react';
import type { Finding } from '../types';

interface Props {
  findings: Finding[];
  activeFinding: string | null;
  showOverlay: boolean;
  zoom: number;
  panX: number;
  panY: number;
  brightness: number;
  contrast: number;
  inverted: boolean;
}

function createNoise(width: number, height: number, scale: number = 1): Float32Array {
  const data = new Float32Array(width * height);
  for (let octave = 0; octave < 3; octave++) {
    const freq = scale * Math.pow(2, octave);
    const amp = 1 / Math.pow(2, octave);
    const gridW = Math.ceil(width / freq) + 2;
    const gridH = Math.ceil(height / freq) + 2;
    const grid = new Float32Array(gridW * gridH);
    for (let i = 0; i < grid.length; i++) grid[i] = Math.random();
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const gx = x / freq;
        const gy = y / freq;
        const ix = Math.floor(gx);
        const iy = Math.floor(gy);
        const fx = gx - ix;
        const fy = gy - iy;
        const sx = fx * fx * (3 - 2 * fx);
        const sy = fy * fy * (3 - 2 * fy);
        const v00 = grid[iy * gridW + ix];
        const v10 = grid[iy * gridW + ix + 1];
        const v01 = grid[(iy + 1) * gridW + ix];
        const v11 = grid[(iy + 1) * gridW + ix + 1];
        const v = v00 * (1-sx) * (1-sy) + v10 * sx * (1-sy) + v01 * (1-sx) * sy + v11 * sx * sy;
        data[y * width + x] += v * amp;
      }
    }
  }
  return data;
}

export default function AbdomenXRayCanvas({ findings, activeFinding, showOverlay, zoom, panX, panY, brightness, contrast, inverted }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const baseCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const W = 600;
  const H = 750;

  const renderBase = useCallback(() => {
    const offscreen = document.createElement('canvas');
    offscreen.width = W;
    offscreen.height = H;
    const ctx = offscreen.getContext('2d')!;

    // === FILM BASE ===
    const filmGrad = ctx.createRadialGradient(W/2, H/2, 50, W/2, H/2, W*0.8);
    filmGrad.addColorStop(0, '#1c1c1c');
    filmGrad.addColorStop(0.5, '#121212');
    filmGrad.addColorStop(1, '#060606');
    ctx.fillStyle = filmGrad;
    ctx.fillRect(0, 0, W, H);

    // === SOFT TISSUE / ABDOMINAL WALL ===
    ctx.save();
    ctx.filter = 'blur(6px)';
    const bodyGrad = ctx.createRadialGradient(W/2, H/2, 50, W/2, H/2, 280);
    bodyGrad.addColorStop(0, 'rgba(55,55,55,0.3)');
    bodyGrad.addColorStop(0.5, 'rgba(50,50,50,0.4)');
    bodyGrad.addColorStop(0.8, 'rgba(40,40,40,0.3)');
    bodyGrad.addColorStop(1, 'rgba(20,20,20,0)');
    ctx.fillStyle = bodyGrad;
    ctx.beginPath();
    ctx.ellipse(W/2, H/2, 250, 340, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // === PSOAS SHADOWS ===
    ctx.save();
    ctx.filter = 'blur(4px)';
    ctx.globalAlpha = 0.25;
    // Right psoas
    const psoasR = ctx.createLinearGradient(270, 200, 230, 600);
    psoasR.addColorStop(0, 'rgba(55,55,55,0.6)');
    psoasR.addColorStop(1, 'rgba(35,35,35,0)');
    ctx.fillStyle = psoasR;
    ctx.beginPath();
    ctx.moveTo(280, 200);
    ctx.lineTo(290, 200);
    ctx.lineTo(260, 600);
    ctx.lineTo(240, 600);
    ctx.closePath();
    ctx.fill();
    // Left psoas
    const psoasL = ctx.createLinearGradient(330, 200, 370, 600);
    psoasL.addColorStop(0, 'rgba(55,55,55,0.6)');
    psoasL.addColorStop(1, 'rgba(35,35,35,0)');
    ctx.fillStyle = psoasL;
    ctx.beginPath();
    ctx.moveTo(320, 200);
    ctx.lineTo(310, 200);
    ctx.lineTo(340, 600);
    ctx.lineTo(360, 600);
    ctx.closePath();
    ctx.fill();
    ctx.restore();

    // === SPINE (Lumbar) ===
    ctx.save();
    ctx.filter = 'blur(2px)';
    const spineGrad = ctx.createLinearGradient(280, 0, 320, 0);
    spineGrad.addColorStop(0, 'rgba(50,50,50,0.3)');
    spineGrad.addColorStop(0.3, 'rgba(70,70,70,0.5)');
    spineGrad.addColorStop(0.5, 'rgba(85,85,85,0.6)');
    spineGrad.addColorStop(0.7, 'rgba(70,70,70,0.5)');
    spineGrad.addColorStop(1, 'rgba(50,50,50,0.3)');
    ctx.fillStyle = spineGrad;
    ctx.fillRect(285, 100, 30, 500);
    
    // Lumbar vertebral bodies (larger than thoracic)
    for (let i = 0; i < 5; i++) {
      const y = 200 + i * 70;
      const vw = 50 + i * 3;
      const vh = 45;
      const vertGrad = ctx.createLinearGradient(300 - vw/2, y, 300 + vw/2, y);
      vertGrad.addColorStop(0, 'rgba(55,55,55,0.3)');
      vertGrad.addColorStop(0.3, 'rgba(80,80,80,0.5)');
      vertGrad.addColorStop(0.5, 'rgba(90,90,90,0.6)');
      vertGrad.addColorStop(0.7, 'rgba(80,80,80,0.5)');
      vertGrad.addColorStop(1, 'rgba(55,55,55,0.3)');
      ctx.fillStyle = vertGrad;
      ctx.fillRect(300 - vw/2, y, vw, vh);
      // Endplates
      ctx.fillStyle = 'rgba(95,95,95,0.4)';
      ctx.fillRect(300 - vw/2, y, vw, 3);
      ctx.fillRect(300 - vw/2, y + vh - 3, vw, 3);
      // Disc space
      ctx.fillStyle = 'rgba(15,15,15,0.5)';
      ctx.fillRect(300 - vw/2 + 5, y + vh, vw - 10, 12);
      // Transverse processes
      ctx.fillStyle = 'rgba(65,65,65,0.3)';
      ctx.fillRect(300 - vw/2 - 25, y + 10, 25, 8);
      ctx.fillRect(300 + vw/2, y + 10, 25, 8);
    }
    ctx.restore();

    // === PELVIS ===
    ctx.save();
    ctx.filter = 'blur(3px)';
    // Sacrum
    const sacrumGrad = ctx.createRadialGradient(300, 560, 10, 300, 560, 60);
    sacrumGrad.addColorStop(0, 'rgba(80,80,80,0.5)');
    sacrumGrad.addColorStop(1, 'rgba(50,50,50,0)');
    ctx.fillStyle = sacrumGrad;
    ctx.beginPath();
    ctx.moveTo(270, 530);
    ctx.bezierCurveTo(260, 560, 270, 600, 300, 610);
    ctx.bezierCurveTo(330, 600, 340, 560, 330, 530);
    ctx.closePath();
    ctx.fill();

    // Iliac wings
    ctx.globalAlpha = 0.4;
    ctx.strokeStyle = 'rgba(85,85,85,0.8)';
    ctx.lineWidth = 5;
    // Right ilium
    ctx.beginPath();
    ctx.moveTo(270, 540);
    ctx.bezierCurveTo(220, 520, 140, 530, 100, 580);
    ctx.bezierCurveTo(80, 620, 90, 660, 120, 680);
    ctx.stroke();
    // Left ilium
    ctx.beginPath();
    ctx.moveTo(330, 540);
    ctx.bezierCurveTo(380, 520, 460, 530, 500, 580);
    ctx.bezierCurveTo(520, 620, 510, 660, 480, 680);
    ctx.stroke();
    
    // Hip joints
    ctx.fillStyle = 'rgba(75,75,75,0.5)';
    ctx.beginPath();
    ctx.arc(160, 650, 35, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(440, 650, 35, 0, Math.PI * 2);
    ctx.fill();
    
    // Femoral heads
    ctx.fillStyle = 'rgba(90,90,90,0.5)';
    ctx.beginPath();
    ctx.arc(165, 655, 20, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(435, 655, 20, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // === LOWER RIBS (visible in abdomen film) ===
    ctx.save();
    ctx.filter = 'blur(2px)';
    ctx.globalAlpha = 0.2;
    ctx.strokeStyle = 'rgba(85,85,85,0.8)';
    ctx.lineWidth = 3;
    for (let i = 0; i < 4; i++) {
      const y = 100 + i * 30;
      ctx.beginPath();
      ctx.moveTo(300, y);
      ctx.bezierCurveTo(240, y - 5, 160, y + 10, 80, y + 25);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(300, y);
      ctx.bezierCurveTo(360, y - 5, 440, y + 10, 520, y + 25);
      ctx.stroke();
    }
    ctx.restore();

    // === LIVER SHADOW (right upper quadrant) ===
    ctx.save();
    ctx.filter = 'blur(5px)';
    const liverGrad = ctx.createRadialGradient(200, 200, 20, 200, 200, 120);
    liverGrad.addColorStop(0, 'rgba(55,55,55,0.4)');
    liverGrad.addColorStop(0.6, 'rgba(45,45,45,0.3)');
    liverGrad.addColorStop(1, 'rgba(30,30,30,0)');
    ctx.fillStyle = liverGrad;
    ctx.beginPath();
    ctx.ellipse(200, 200, 130, 90, -0.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // === SPLEEN (left upper quadrant) ===
    ctx.save();
    ctx.filter = 'blur(5px)';
    const spleenGrad = ctx.createRadialGradient(430, 220, 10, 430, 220, 70);
    spleenGrad.addColorStop(0, 'rgba(50,50,50,0.35)');
    spleenGrad.addColorStop(1, 'rgba(30,30,30,0)');
    ctx.fillStyle = spleenGrad;
    ctx.beginPath();
    ctx.ellipse(430, 220, 70, 55, 0.3, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // === KIDNEY SHADOWS ===
    ctx.save();
    ctx.filter = 'blur(3px)';
    ctx.globalAlpha = 0.3;
    // Right kidney
    const kidneyGradR = ctx.createRadialGradient(240, 350, 5, 240, 350, 45);
    kidneyGradR.addColorStop(0, 'rgba(60,60,60,0.6)');
    kidneyGradR.addColorStop(1, 'rgba(40,40,40,0)');
    ctx.fillStyle = kidneyGradR;
    ctx.beginPath();
    ctx.ellipse(240, 350, 25, 50, -0.15, 0, Math.PI * 2);
    ctx.fill();
    // Left kidney
    const kidneyGradL = ctx.createRadialGradient(360, 340, 5, 360, 340, 45);
    kidneyGradL.addColorStop(0, 'rgba(60,60,60,0.6)');
    kidneyGradL.addColorStop(1, 'rgba(40,40,40,0)');
    ctx.fillStyle = kidneyGradL;
    ctx.beginPath();
    ctx.ellipse(360, 340, 25, 50, 0.15, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // === GAS PATTERNS ===
    // Stomach bubble (LUQ)
    ctx.save();
    ctx.filter = 'blur(2px)';
    const stomachGrad = ctx.createRadialGradient(400, 160, 5, 400, 160, 50);
    stomachGrad.addColorStop(0, 'rgba(5,5,5,0.7)');
    stomachGrad.addColorStop(0.7, 'rgba(8,8,8,0.4)');
    stomachGrad.addColorStop(1, 'rgba(15,15,15,0)');
    ctx.fillStyle = stomachGrad;
    ctx.beginPath();
    ctx.ellipse(400, 160, 50, 40, 0.2, 0, Math.PI * 2);
    ctx.fill();
    // Air-fluid level in stomach
    ctx.strokeStyle = 'rgba(50,50,50,0.5)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(360, 170);
    ctx.lineTo(440, 165);
    ctx.stroke();
    ctx.restore();

    // Scattered bowel gas
    ctx.save();
    ctx.filter = 'blur(2px)';
    ctx.globalAlpha = 0.3;
    const bowelPositions = [
      [180, 380, 20, 15], [350, 400, 25, 18], [420, 380, 18, 14],
      [200, 450, 22, 16], [380, 460, 20, 15], [250, 500, 18, 14],
    ];
    bowelPositions.forEach(([bx, by, bw, bh]) => {
      const bGrad = ctx.createRadialGradient(bx, by, 0, bx, by, bw);
      bGrad.addColorStop(0, 'rgba(5,5,5,0.5)');
      bGrad.addColorStop(1, 'rgba(15,15,15,0)');
      ctx.fillStyle = bGrad;
      ctx.beginPath();
      ctx.ellipse(bx, by, bw, bh, 0, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.restore();

    // === FILM GRAIN ===
    const noise = createNoise(W, H, 3);
    const imageData = ctx.getImageData(0, 0, W, H);
    const data = imageData.data;
    for (let i = 0; i < noise.length; i++) {
      const grain = (noise[i] - 0.5) * 12;
      data[i * 4] = Math.max(0, Math.min(255, data[i * 4] + grain));
      data[i * 4 + 1] = Math.max(0, Math.min(255, data[i * 4 + 1] + grain));
      data[i * 4 + 2] = Math.max(0, Math.min(255, data[i * 4 + 2] + grain));
    }
    ctx.putImageData(imageData, 0, 0);

    // === VIGNETTE ===
    const vigGrad = ctx.createRadialGradient(W/2, H/2, W*0.25, W/2, H/2, W*0.7);
    vigGrad.addColorStop(0, 'rgba(0,0,0,0)');
    vigGrad.addColorStop(0.7, 'rgba(0,0,0,0.1)');
    vigGrad.addColorStop(1, 'rgba(0,0,0,0.5)');
    ctx.fillStyle = vigGrad;
    ctx.fillRect(0, 0, W, H);

    // === MARKERS ===
    ctx.save();
    ctx.font = 'bold 16px monospace';
    ctx.fillStyle = 'rgba(200,200,200,0.8)';
    ctx.fillText('R', 560, 30);
    ctx.fillText('SUPINE', 20, 30);
    ctx.restore();

    baseCanvasRef.current = offscreen;
    return offscreen;
  }, []);

  const renderFindings = useCallback((baseImage: HTMLCanvasElement) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d')!;
    ctx.drawImage(baseImage, 0, 0);

    if (brightness !== 0 || contrast !== 0) {
      const imageData = ctx.getImageData(0, 0, W, H);
      const data = imageData.data;
      const factor = (259 * (contrast * 255 + 255)) / (255 * (259 - contrast * 255));
      for (let i = 0; i < data.length; i += 4) {
        for (let c = 0; c < 3; c++) {
          let val = data[i + c];
          val += brightness * 50;
          val = factor * (val - 128) + 128;
          data[i + c] = Math.max(0, Math.min(255, val));
        }
      }
      ctx.putImageData(imageData, 0, 0);
    }

    if (inverted) {
      const imageData = ctx.getImageData(0, 0, W, H);
      const data = imageData.data;
      for (let i = 0; i < data.length; i += 4) {
        data[i] = 255 - data[i];
        data[i + 1] = 255 - data[i + 1];
        data[i + 2] = 255 - data[i + 2];
      }
      ctx.putImageData(imageData, 0, 0);
    }

    if (showOverlay) {
      findings.forEach(finding => {
        const isActive = activeFinding === finding.id;
        ctx.save();
        
        switch (finding.type) {
          case 'lucency': {
            // Dilated bowel loops
            const grad = ctx.createRadialGradient(finding.x, finding.y, 0, finding.x, finding.y, finding.radius);
            grad.addColorStop(0, 'rgba(3,3,3,0.7)');
            grad.addColorStop(0.6, 'rgba(5,5,5,0.4)');
            grad.addColorStop(1, 'rgba(10,10,10,0)');
            ctx.filter = 'blur(3px)';
            ctx.fillStyle = grad;
            ctx.beginPath();
            ctx.ellipse(finding.x, finding.y, finding.radius, finding.radius * 0.6, 0, 0, Math.PI * 2);
            ctx.fill();
            // Air-fluid levels
            ctx.strokeStyle = 'rgba(55,55,55,0.6)';
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(finding.x - finding.radius * 0.7, finding.y);
            ctx.lineTo(finding.x + finding.radius * 0.7, finding.y);
            ctx.stroke();
            break;
          }
          case 'opacity': {
            // Organomegaly or mass
            const grad = ctx.createRadialGradient(finding.x, finding.y, 0, finding.x, finding.y, finding.radius);
            grad.addColorStop(0, 'rgba(75,75,75,0.6)');
            grad.addColorStop(0.6, 'rgba(60,60,60,0.4)');
            grad.addColorStop(1, 'rgba(40,40,40,0)');
            ctx.filter = 'blur(5px)';
            ctx.fillStyle = grad;
            ctx.beginPath();
            ctx.ellipse(finding.x, finding.y, finding.radius, finding.radius * 0.8, 0, 0, Math.PI * 2);
            ctx.fill();
            break;
          }
          case 'calcification': {
            // Calcification / stones
            ctx.filter = 'blur(1px)';
            ctx.fillStyle = 'rgba(130,130,130,0.8)';
            ctx.beginPath();
            ctx.arc(finding.x, finding.y, finding.radius * 0.3, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = 'rgba(150,150,150,0.5)';
            ctx.beginPath();
            ctx.arc(finding.x, finding.y, finding.radius * 0.15, 0, Math.PI * 2);
            ctx.fill();
            break;
          }
          case 'foreign_body': {
            // Free air under diaphragm
            ctx.filter = 'blur(2px)';
            const airGrad = ctx.createRadialGradient(finding.x, finding.y, 0, finding.x, finding.y, finding.radius);
            airGrad.addColorStop(0, 'rgba(2,2,2,0.7)');
            airGrad.addColorStop(1, 'rgba(8,8,8,0)');
            ctx.fillStyle = airGrad;
            ctx.beginPath();
            ctx.ellipse(finding.x, finding.y, finding.radius, finding.radius * 0.4, 0, 0, Math.PI * 2);
            ctx.fill();
            break;
          }
          case 'fracture': {
            ctx.filter = 'blur(0.5px)';
            ctx.strokeStyle = 'rgba(15,15,15,0.8)';
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.moveTo(finding.x - finding.radius, finding.y);
            ctx.lineTo(finding.x + finding.radius, finding.y);
            ctx.stroke();
            break;
          }
          default: {
            ctx.strokeStyle = isActive ? '#22d3ee' : '#f59e0b';
            ctx.lineWidth = isActive ? 2 : 1.5;
            ctx.setLineDash([4, 4]);
            ctx.beginPath();
            ctx.arc(finding.x, finding.y, finding.radius, 0, Math.PI * 2);
            ctx.stroke();
          }
        }
        
        if (isActive) {
          ctx.filter = 'none';
          ctx.strokeStyle = '#22d3ee';
          ctx.lineWidth = 2;
          ctx.setLineDash([6, 3]);
          ctx.beginPath();
          ctx.arc(finding.x, finding.y, finding.radius + 8, 0, Math.PI * 2);
          ctx.stroke();
          ctx.setLineDash([]);
          ctx.font = '11px sans-serif';
          ctx.fillStyle = '#22d3ee';
          ctx.fillText(finding.name, finding.x + finding.radius + 12, finding.y);
        }
        
        ctx.restore();
      });
    }
  }, [findings, activeFinding, showOverlay, brightness, contrast, inverted]);

  useEffect(() => {
    const base = renderBase();
    renderFindings(base);
  }, [renderBase, renderFindings]);

  return (
    <div className="relative w-full h-full overflow-hidden bg-black">
      <canvas
        ref={canvasRef}
        width={W}
        height={H}
        className="w-full h-full object-contain"
        style={{
          transform: `scale(${zoom}) translate(${panX}px, ${panY}px)`,
          imageRendering: 'auto',
        }}
      />
    </div>
  );
}
