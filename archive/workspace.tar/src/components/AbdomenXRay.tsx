import React from 'react';
import { FindingType } from '../data/cases';

interface AbdomenXRayProps {
  activeFindings: Set<FindingType>;
  highlightedFinding?: FindingType | null;
}

const AbdomenXRay: React.FC<AbdomenXRayProps> = ({ activeFindings, highlightedFinding }) => {
  const isActive = (type: FindingType) => activeFindings.has(type);
  const isHighlighted = (type: FindingType) => highlightedFinding === type;

  return (
    <svg viewBox="0 0 600 700" className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="abdFilmBg" cx="50%" cy="50%" r="55%">
          <stop offset="0%" stopColor="#1c1c2e" />
          <stop offset="70%" stopColor="#0e0e1c" />
          <stop offset="100%" stopColor="#060612" />
        </radialGradient>

        <radialGradient id="softTissueGrad" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#2a2a3e" stopOpacity="0.4" />
          <stop offset="100%" stopColor="#1a1a2e" stopOpacity="0.7" />
        </radialGradient>

        <linearGradient id="abdBoneGrad" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#8a8a9a" stopOpacity="0.5" />
          <stop offset="50%" stopColor="#a0a0b0" stopOpacity="0.7" />
          <stop offset="100%" stopColor="#8a8a9a" stopOpacity="0.5" />
        </linearGradient>

        <linearGradient id="gasGrad" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#0a0a15" stopOpacity="0.9" />
          <stop offset="100%" stopColor="#08080f" stopOpacity="0.7" />
        </linearGradient>

        <linearGradient id="fluidLevelGrad" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#0a0a15" stopOpacity="0.8" />
          <stop offset="48%" stopColor="#0a0a15" stopOpacity="0.8" />
          <stop offset="50%" stopColor="#4a4a5e" stopOpacity="0.7" />
          <stop offset="100%" stopColor="#5a5a6e" stopOpacity="0.6" />
        </linearGradient>

        <radialGradient id="calcGrad" cx="40%" cy="40%" r="50%">
          <stop offset="0%" stopColor="#c0c0d0" stopOpacity="0.9" />
          <stop offset="60%" stopColor="#9a9aaa" stopOpacity="0.7" />
          <stop offset="100%" stopColor="#7a7a8a" stopOpacity="0.5" />
        </radialGradient>

        <filter id="abdGlow">
          <feGaussianBlur stdDeviation="3" result="coloredBlur" />
          <feMerge>
            <feMergeNode in="coloredBlur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>

        <filter id="abdGrain">
          <feTurbulence type="fractalNoise" baseFrequency="0.8" numOctaves="3" result="noise" />
          <feColorMatrix type="saturate" values="0" in="noise" result="grayNoise" />
          <feBlend in="SourceGraphic" in2="grayNoise" mode="multiply" />
        </filter>

        {/* Kidney shadow */}
        <radialGradient id="kidneyGrad" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#3a3a4e" stopOpacity="0.5" />
          <stop offset="100%" stopColor="#2a2a3e" stopOpacity="0.3" />
        </radialGradient>

        {/* Liver shadow */}
        <radialGradient id="liverGrad" cx="40%" cy="40%" r="60%">
          <stop offset="0%" stopColor="#3a3a4e" stopOpacity="0.5" />
          <stop offset="100%" stopColor="#2a2a3e" stopOpacity="0.3" />
        </radialGradient>

        {/* Psoas shadow */}
        <linearGradient id="psoasGrad" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#2a2a3e" stopOpacity="0.3" />
          <stop offset="50%" stopColor="#3a3a4e" stopOpacity="0.4" />
          <stop offset="100%" stopColor="#2a2a3e" stopOpacity="0.3" />
        </linearGradient>
      </defs>

      {/* Background */}
      <rect width="600" height="700" fill="url(#abdFilmBg)" />
      <rect x="5" y="5" width="590" height="690" fill="none" stroke="#1a1a2e" strokeWidth="2" rx="3" />

      {/* Patient info */}
      <text x="20" y="25" fill="#4a4a5e" fontSize="9" fontFamily="monospace">R  |  ABDOMEN SUPINE  |  2024-03-22</text>
      <text x="430" y="25" fill="#4a4a5e" fontSize="9" fontFamily="monospace">SID: 100cm | 70kVp</text>

      {/* Body contour - abdominal wall */}
      <path d="M150,60 Q120,80 100,120 Q80,180 75,250 Q70,350 75,450 Q80,530 100,590 Q120,640 150,660 L450,660 Q480,640 500,590 Q520,530 525,450 Q530,350 525,250 Q520,180 500,120 Q480,80 450,60"
        fill="url(#softTissueGrad)" stroke="#2a2a3e" strokeWidth="1.5" opacity="0.6" />

      {/* Lower ribs */}
      {[0, 1, 2, 3, 4, 5, 6].map((i) => (
        <g key={`rib-${i}`}>
          <path d={`M300,${60 + i * 15} Q250,${65 + i * 15} 200,${75 + i * 15} Q160,${85 + i * 15} 130,${100 + i * 15}`}
            fill="none" stroke="#7a7a8e" strokeWidth="4" opacity={0.5 - i * 0.03} strokeLinecap="round" />
          <path d={`M300,${60 + i * 15} Q350,${65 + i * 15} 400,${75 + i * 15} Q440,${85 + i * 15} 470,${100 + i * 15}`}
            fill="none" stroke="#7a7a8e" strokeWidth="4" opacity={0.5 - i * 0.03} strokeLinecap="round" />
        </g>
      ))}

      {/* Lumbar spine */}
      {Array.from({ length: 5 }, (_, i) => (
        <g key={`lumb-${i}`}>
          <rect x="275" y={130 + i * 80} width="50" height="65" rx="5" fill="#4a4a5e" opacity="0.6" />
          <line x1="300" y1={130 + i * 80} x2="300" y2={195 + i * 80} stroke="#5a5a6e" strokeWidth="1.5" opacity="0.4" />
          {/* Transverse processes */}
          <path d={`M275,${155 + i * 80} Q250,${155 + i * 80} 230,${160 + i * 80}`}
            fill="none" stroke="#6a6a7e" strokeWidth="4" opacity="0.4" strokeLinecap="round" />
          <path d={`M325,${155 + i * 80} Q350,${155 + i * 80} 370,${160 + i * 80}`}
            fill="none" stroke="#6a6a7e" strokeWidth="4" opacity="0.4" strokeLinecap="round" />
          {/* Disc spaces */}
          <rect x="280" y={192 + i * 80} width="40" height="8" rx="2" fill="#1a1a2e" opacity="0.5" />
        </g>
      ))}

      {/* Sacrum */}
      <path d="M270,530 Q280,560 300,580 Q320,560 330,530" fill="#3a3a4e" opacity="0.5" />

      {/* Pelvis - Iliac bones */}
      <path d="M270,530 Q240,540 200,560 Q160,580 140,610 Q130,640 140,660"
        fill="none" stroke="url(#abdBoneGrad)" strokeWidth="8" opacity="0.5" strokeLinecap="round" />
      <path d="M330,530 Q360,540 400,560 Q440,580 460,610 Q470,640 460,660"
        fill="none" stroke="url(#abdBoneGrad)" strokeWidth="8" opacity="0.5" strokeLinecap="round" />

      {/* Femoral heads */}
      <circle cx="180" cy="640" r="30" fill="#4a4a5e" opacity="0.4" />
      <circle cx="420" cy="640" r="30" fill="#4a4a5e" opacity="0.4" />

      {/* Psoas shadows */}
      <path d="M270,200 Q250,300 240,400 Q235,480 240,530"
        fill="none" stroke="url(#psoasGrad)" strokeWidth="15" opacity="0.3" />
      <path d="M330,200 Q350,300 360,400 Q365,480 360,530"
        fill="none" stroke="url(#psoasGrad)" strokeWidth="15" opacity="0.3" />

      {/* Liver shadow */}
      <ellipse cx="220" cy="150" rx="100" ry="50" fill="url(#liverGrad)" opacity="0.4" />

      {/* Kidney shadows */}
      <ellipse cx="230" cy="280" rx="25" ry="45" fill="url(#kidneyGrad)" opacity="0.4" transform="rotate(-10, 230, 280)" />
      <ellipse cx="370" cy="280" rx="25" ry="45" fill="url(#kidneyGrad)" opacity="0.4" transform="rotate(10, 370, 280)" />

      {/* Spleen shadow */}
      <ellipse cx="430" cy="180" rx="40" ry="30" fill="url(#kidneyGrad)" opacity="0.3" />

      {/* Normal bowel gas pattern */}
      <g opacity="0.3">
        {/* Small bowel - central */}
        <ellipse cx="280" cy="350" rx="20" ry="12" fill="#0a0a15" opacity="0.5" />
        <ellipse cx="310" cy="380" rx="18" ry="10" fill="#0a0a15" opacity="0.4" />
        <ellipse cx="290" cy="410" rx="15" ry="10" fill="#0a0a15" opacity="0.4" />
        <ellipse cx="320" cy="430" rx="17" ry="11" fill="#0a0a15" opacity="0.3" />
        {/* Colon - peripheral */}
        <path d="M140,200 Q130,300 135,400 Q140,480 160,530 Q180,560 220,570 Q280,575 340,570 Q380,560 400,530 Q420,480 425,400 Q430,300 420,200"
          fill="none" stroke="#1a1a2e" strokeWidth="20" opacity="0.3" />
      </g>

      {/* ============ PATHOLOGICAL FINDINGS ============ */}

      {/* INTESTINAL OBSTRUCTION */}
      {isActive('intestinal_obstruction') && (
        <g filter={isHighlighted('intestinal_obstruction') ? 'url(#abdGlow)' : undefined} className="transition-opacity duration-500">
          {/* Dilated small bowel loops - stepladder pattern */}
          {[
            { cx: 250, cy: 250, rx: 35, ry: 18 },
            { cx: 310, cy: 270, rx: 38, ry: 20 },
            { cx: 260, cy: 310, rx: 36, ry: 19 },
            { cx: 320, cy: 330, rx: 40, ry: 21 },
            { cx: 270, cy: 370, rx: 37, ry: 18 },
            { cx: 330, cy: 390, rx: 35, ry: 19 },
            { cx: 280, cy: 430, rx: 38, ry: 20 },
            { cx: 310, cy: 460, rx: 36, ry: 18 },
          ].map((loop, i) => (
            <g key={`loop-${i}`}>
              {/* Dilated loop */}
              <ellipse cx={loop.cx} cy={loop.cy} rx={loop.rx} ry={loop.ry}
                fill="url(#gasGrad)" stroke="#5a5a6e" strokeWidth="1" opacity="0.8" />
              {/* Air-fluid levels */}
              <line x1={loop.cx - loop.rx + 5} y1={loop.cy + 2} x2={loop.cx + loop.rx - 5} y2={loop.cy + 2}
                stroke="#6a6a80" strokeWidth="1.5" opacity="0.7" />
              {/* Valve pattern (valvulae conniventes) */}
              {Array.from({ length: 3 }, (_, j) => (
                <line key={j}
                  x1={loop.cx - loop.rx + 10 + j * 20} y1={loop.cy - loop.ry + 3}
                  x2={loop.cx - loop.rx + 10 + j * 20} y2={loop.cy + 2}
                  stroke="#4a4a5e" strokeWidth="0.8" opacity="0.5" />
              ))}
            </g>
          ))}
          {/* Collapsed colon */}
          <path d="M140,200 Q135,300 138,400 Q140,480 160,530"
            fill="none" stroke="#2a2a3e" strokeWidth="8" opacity="0.4" />
          <path d="M420,200 Q425,300 422,400 Q420,480 400,530"
            fill="none" stroke="#2a2a3e" strokeWidth="8" opacity="0.4" />
          {/* Measurement annotation */}
          <line x1="215" y1="250" x2="285" y2="250" stroke="#eab308" strokeWidth="0.5" strokeDasharray="2,2" opacity="0.6" />
          <text x="225" y="245" fill="#eab308" fontSize="7" opacity="0.7">4.8cm</text>
        </g>
      )}

      {/* FREE AIR - Pneumoperitoneum */}
      {isActive('free_air') && (
        <g filter={isHighlighted('free_air') ? 'url(#abdGlow)' : undefined} className="transition-opacity duration-500">
          {/* Air under right hemidiaphragm - crescent shape */}
          <path d="M160,100 Q200,85 250,82 Q280,80 300,82 Q260,95 220,100 Q190,105 160,100"
            fill="#0a0a15" opacity="0.9" />
          {/* Sharp demarcation line */}
          <path d="M160,100 Q200,105 250,102 Q280,100 300,98"
            fill="none" stroke="#8a8a9e" strokeWidth="1.5" opacity="0.8" />
          {/* Air under left hemidiaphragm */}
          <path d="M300,82 Q340,80 380,85 Q410,90 430,100 Q400,105 370,102 Q340,100 300,98"
            fill="#0a0a15" opacity="0.8" />
          <path d="M300,98 Q340,100 370,102 Q400,105 430,100"
            fill="none" stroke="#8a8a9e" strokeWidth="1.5" opacity="0.8" />
          {/* Rigler sign - double wall of intestine */}
          <path d="M200,120 Q220,115 240,118" fill="none" stroke="#6a6a7e" strokeWidth="1" opacity="0.6" />
          <path d="M200,125 Q220,120 240,123" fill="none" stroke="#6a6a7e" strokeWidth="1" opacity="0.6" />
          {/* Football sign - large lucency */}
          <ellipse cx="300" cy="300" rx="120" ry="180" fill="#0a0a15" opacity="0.15" />
          {/* Annotation */}
          <text x="165" y="75" fill="#dc2626" fontSize="8" opacity="0.8">↑ FREE AIR</text>
        </g>
      )}

      {/* CALCIFICATION - Aortic */}
      {isActive('calcification') && (
        <g filter={isHighlighted('calcification') ? 'url(#abdGlow)' : undefined} className="transition-opacity duration-500">
          {/* Aortic calcification - parallel lines along midline */}
          <path d="M295,180 Q293,250 292,320 Q291,390 292,450 Q293,500 295,530"
            fill="none" stroke="url(#calcGrad)" strokeWidth="3" opacity="0.8" />
          <path d="M305,180 Q307,250 308,320 Q309,390 308,450 Q307,500 305,530"
            fill="none" stroke="url(#calcGrad)" strokeWidth="3" opacity="0.8" />
          {/* Irregular calcific deposits */}
          {[200, 250, 300, 350, 400, 450, 500].map((y, i) => (
            <g key={`calc-${i}`}>
              <ellipse cx={293 + (i % 2) * 2} cy={y} rx="3" ry="4" fill="#b0b0c0" opacity={0.6 + (i % 3) * 0.1} />
              <ellipse cx={307 - (i % 2) * 2} cy={y + 10} rx="2.5" ry="3.5" fill="#a0a0b0" opacity={0.5 + (i % 2) * 0.1} />
            </g>
          ))}
          {/* Iliac artery calcification */}
          <path d="M295,530 Q270,560 240,590 Q220,610 200,630"
            fill="none" stroke="#9a9aaa" strokeWidth="2" opacity="0.5" />
          <path d="M305,530 Q330,560 360,590 Q380,610 400,630"
            fill="none" stroke="#9a9aaa" strokeWidth="2" opacity="0.5" />
        </g>
      )}

      {/* FOREIGN BODY - Surgical clips */}
      {isActive('foreign_body') && (
        <g filter={isHighlighted('foreign_body') ? 'url(#abdGlow)' : undefined} className="transition-opacity duration-500">
          {/* Surgical clips in right lower quadrant */}
          <g transform="translate(200, 520)">
            <rect x="0" y="0" width="8" height="3" rx="1" fill="#c0c0d0" opacity="0.9" />
            <rect x="12" y="5" width="7" height="3" rx="1" fill="#b0b0c0" opacity="0.85" />
          </g>
          {/* Clip shadows */}
          <ellipse cx="204" cy="522" rx="6" ry="3" fill="#0a0a15" opacity="0.3" />
          <ellipse cx="216" cy="527" rx="5" ry="2.5" fill="#0a0a15" opacity="0.3" />
        </g>
      )}

      {/* HIATAL HERNIA */}
      {isActive('hiatal_hernia') && (
        <g filter={isHighlighted('hiatal_hernia') ? 'url(#abdGlow)' : undefined} className="transition-opacity duration-500">
          {/* Air-fluid level behind heart/above diaphragm */}
          <ellipse cx="280" cy="110" rx="30" ry="25" fill="#0a0a15" opacity="0.7" />
          <line x1="255" y1="115" x2="305" y2="115" stroke="#6a6a80" strokeWidth="1.5" opacity="0.7" />
          {/* Hernia outline */}
          <path d="M255,90 Q260,80 280,78 Q300,80 305,90 Q310,105 305,120 Q300,130 280,132 Q260,130 255,120 Q250,105 255,90"
            fill="none" stroke="#84cc16" strokeWidth="1.5" opacity="0.6" />
        </g>
      )}

      {/* Side markers */}
      <text x="15" y="350" fill="#3a3a4e" fontSize="12" fontWeight="bold" opacity="0.4">R</text>
      <text x="575" y="350" fill="#3a3a4e" fontSize="12" fontWeight="bold" opacity="0.4">L</text>

      {/* Scale */}
      <line x1="560" y1="100" x2="560" y2="600" stroke="#2a2a3e" strokeWidth="0.5" opacity="0.3" />
      {[0, 1, 2, 3, 4, 5].map((i) => (
        <g key={`scale-${i}`}>
          <line x1="555" y1={100 + i * 100} x2="565" y2={100 + i * 100} stroke="#2a2a3e" strokeWidth="0.5" opacity="0.3" />
          <text x="545" y={103 + i * 100} fill="#2a2a3e" fontSize="7" opacity="0.3">{i * 5}cm</text>
        </g>
      ))}
    </svg>
  );
};

export default AbdomenXRay;
