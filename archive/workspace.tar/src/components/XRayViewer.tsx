import React, { useState, useRef, useCallback } from 'react';
import { ZoomIn, ZoomOut, RotateCcw, Maximize2, Move } from 'lucide-react';
import { FindingType } from '../data/cases';
import ChestXRay from './ChestXRay';
import AbdomenXRay from './AbdomenXRay';

interface XRayViewerProps {
  examType: string;
  activeFindings: Set<FindingType>;
  highlightedFinding: FindingType | null;
}

const XRayViewer: React.FC<XRayViewerProps> = ({ examType, activeFindings, highlightedFinding }) => {
  const [zoom, setZoom] = useState(1);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const containerRef = useRef<HTMLDivElement>(null);

  const handleZoomIn = () => setZoom((z) => Math.min(z + 0.25, 3));
  const handleZoomOut = () => setZoom((z) => Math.max(z - 0.25, 0.5));
  const handleReset = () => {
    setZoom(1);
    setPosition({ x: 0, y: 0 });
  };

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX - position.x, y: e.clientY - position.y });
  }, [position]);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (!isDragging) return;
    setPosition({
      x: e.clientX - dragStart.x,
      y: e.clientY - dragStart.y,
    });
  }, [isDragging, dragStart]);

  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
  }, []);

  const handleWheel = useCallback((e: React.WheelEvent) => {
    e.preventDefault();
    const delta = e.deltaY > 0 ? -0.1 : 0.1;
    setZoom((z) => Math.min(Math.max(z + delta, 0.5), 3));
  }, []);

  const isChest = examType.startsWith('chest');

  return (
    <div className="h-full flex flex-col">
      {/* Toolbar */}
      <div className="flex items-center gap-2 px-4 py-2 border-b border-slate-700/50 bg-slate-800/50">
        <div className="flex items-center gap-1 bg-slate-900/50 rounded-lg p-1">
          <button
            onClick={handleZoomOut}
            className="p-1.5 rounded hover:bg-slate-700/50 text-slate-400 hover:text-slate-200 transition-colors"
            title="Thu nhỏ"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <span className="text-xs font-mono text-slate-400 px-2 min-w-[48px] text-center">
            {Math.round(zoom * 100)}%
          </span>
          <button
            onClick={handleZoomIn}
            className="p-1.5 rounded hover:bg-slate-700/50 text-slate-400 hover:text-slate-200 transition-colors"
            title="Phóng to"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
        </div>

        <button
          onClick={handleReset}
          className="p-1.5 rounded hover:bg-slate-700/50 text-slate-400 hover:text-slate-200 transition-colors"
          title="Đặt lại"
        >
          <RotateCcw className="w-4 h-4" />
        </button>

        <button
          onClick={() => {
            setZoom(1.5);
            setPosition({ x: 0, y: 0 });
          }}
          className="p-1.5 rounded hover:bg-slate-700/50 text-slate-400 hover:text-slate-200 transition-colors"
          title="Vừa màn hình"
        >
          <Maximize2 className="w-4 h-4" />
        </button>

        <div className="ml-auto flex items-center gap-2">
          <Move className="w-3.5 h-3.5 text-slate-500" />
          <span className="text-[10px] text-slate-500">Kéo để di chuyển • Cuộn để zoom</span>
        </div>
      </div>

      {/* Viewer */}
      <div
        ref={containerRef}
        className="flex-1 relative overflow-hidden bg-black cursor-grab active:cursor-grabbing"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onWheel={handleWheel}
      >
        {/* Lightbox effect */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div
            className="transition-transform duration-200 ease-out"
            style={{
              transform: `translate(${position.x}px, ${position.y}px) scale(${zoom})`,
            }}
          >
            {/* Film frame */}
            <div className="relative shadow-2xl">
              <div className="absolute -inset-2 bg-slate-900 rounded-sm opacity-50" />
              <div className="relative w-[500px] h-[580px] bg-black rounded-sm overflow-hidden border border-slate-800">
                {isChest ? (
                  <ChestXRay
                    activeFindings={activeFindings}
                    view="PA"
                    highlightedFinding={highlightedFinding}
                  />
                ) : (
                  <AbdomenXRay
                    activeFindings={activeFindings}
                    highlightedFinding={highlightedFinding}
                  />
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Corner annotations */}
        <div className="absolute top-3 left-3 text-[10px] text-slate-600 font-mono">
          <div>{isChest ? 'CHEST PA' : 'ABDOMEN'}</div>
          <div>DICOM Viewer v2.1</div>
        </div>
        <div className="absolute bottom-3 right-3 text-[10px] text-slate-600 font-mono text-right">
          <div>W: 256 L: 128</div>
          <div>{isChest ? 'Soft Tissue' : 'Abdomen'}</div>
        </div>

        {/* Window level indicator */}
        <div className="absolute top-3 right-3 flex flex-col gap-1">
          <div className="w-1 h-16 bg-gradient-to-b from-white via-gray-500 to-black rounded-full opacity-30" />
        </div>
      </div>
    </div>
  );
};

export default XRayViewer;
