import { useEffect, useRef, useCallback } from 'react';
import type { Finding } from '../types';

interface Props {
  findings: Finding[];
  activeFinding: string | null;
  showOverlay: boolean;
  zoom: number;
  panX: number;
  panY: number;
  brightness: number;
  contrast: number;
  inverted: boolean;
}

// Simplex-like noise for film grain
function createNoise(width: number, height: number, scale: number = 1): Float32Array {
  const data = new Float32Array(width * height);
  // Use multiple octaves of value noise
  for (let octave = 0; octave < 3; octave++) {
    const freq = scale * Math.pow(2, octave);
    const amp = 1 / Math.pow(2, octave);
    const gridW = Math.ceil(width / freq) + 2;
    const gridH = Math.ceil(height / freq) + 2;
    const grid = new Float32Array(gridW * gridH);
    for (let i = 0; i < grid.length; i++) grid[i] = Math.random();
    
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const gx = x / freq;
        const gy = y / freq;
        const ix = Math.floor(gx);
        const iy = Math.floor(gy);
        const fx = gx - ix;
        const fy = gy - iy;
        const sx = fx * fx * (3 - 2 * fx);
        const sy = fy * fy * (3 - 2 * fy);
        
        const v00 = grid[iy * gridW + ix];
        const v10 = grid[iy * gridW + ix + 1];
        const v01 = grid[(iy + 1) * gridW + ix];
        const v11 = grid[(iy + 1) * gridW + ix + 1];
        
        const v = v00 * (1-sx) * (1-sy) + v10 * sx * (1-sy) + v01 * (1-sx) * sy + v11 * sx * sy;
        data[y * width + x] += v * amp;
      }
    }
  }
  return data;
}

function drawSoftEllipse(
  ctx: CanvasRenderingContext2D,
  cx: number, cy: number,
  rx: number, ry: number,
  color: string,
  blur: number,
  opacity: number = 1
) {
  ctx.save();
  ctx.filter = `blur(${blur}px)`;
  ctx.globalAlpha = opacity;
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawSoftPath(
  ctx: CanvasRenderingContext2D,
  path: Path2D,
  color: string,
  blur: number,
  opacity: number = 1,
  lineWidth: number = 2
) {
  ctx.save();
  ctx.filter = `blur(${blur}px)`;
  ctx.globalAlpha = opacity;
  ctx.strokeStyle = color;
  ctx.lineWidth = lineWidth;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  ctx.stroke(path);
  ctx.restore();
}

export default function ChestXRayCanvas({ findings, activeFinding, showOverlay, zoom, panX, panY, brightness, contrast, inverted }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const baseCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const W = 600;
  const H = 750;

  const renderBase = useCallback(() => {
    const offscreen = document.createElement('canvas');
    offscreen.width = W;
    offscreen.height = H;
    const ctx = offscreen.getContext('2d')!;

    // === FILM BASE ===
    // Dark background like actual X-ray film
    const filmGrad = ctx.createRadialGradient(W/2, H/2, 50, W/2, H/2, W*0.8);
    filmGrad.addColorStop(0, '#1a1a1a');
    filmGrad.addColorStop(0.5, '#111111');
    filmGrad.addColorStop(1, '#050505');
    ctx.fillStyle = filmGrad;
    ctx.fillRect(0, 0, W, H);

    // === SOFT TISSUE / BODY OUTLINE ===
    // Shoulder and body contour
    ctx.save();
    ctx.filter = 'blur(8px)';
    const bodyGrad = ctx.createLinearGradient(0, 0, 0, H);
    bodyGrad.addColorStop(0, 'rgba(60,60,60,0.3)');
    bodyGrad.addColorStop(0.15, 'rgba(80,80,80,0.4)');
    bodyGrad.addColorStop(0.5, 'rgba(70,70,70,0.3)');
    bodyGrad.addColorStop(1, 'rgba(50,50,50,0.2)');
    
    ctx.fillStyle = bodyGrad;
    ctx.beginPath();
    ctx.moveTo(30, 80);
    ctx.bezierCurveTo(80, 60, 200, 50, 300, 55);
    ctx.bezierCurveTo(400, 50, 520, 60, 570, 80);
    ctx.lineTo(580, H);
    ctx.lineTo(20, H);
    ctx.closePath();
    ctx.fill();
    ctx.restore();

    // === LUNG FIELDS ===
    // Right lung (viewer's left)
    const lungGradR = ctx.createRadialGradient(200, 350, 20, 200, 350, 200);
    lungGradR.addColorStop(0, 'rgba(5,5,5,0.95)');
    lungGradR.addColorStop(0.3, 'rgba(10,10,10,0.9)');
    lungGradR.addColorStop(0.6, 'rgba(15,15,15,0.85)');
    lungGradR.addColorStop(0.85, 'rgba(25,25,25,0.7)');
    lungGradR.addColorStop(1, 'rgba(40,40,40,0.4)');
    
    ctx.save();
    ctx.filter = 'blur(3px)';
    ctx.fillStyle = lungGradR;
    ctx.beginPath();
    ctx.moveTo(280, 120);
    ctx.bezierCurveTo(270, 200, 260, 350, 270, 480);
    ctx.bezierCurveTo(275, 530, 280, 560, 290, 580);
    ctx.bezierCurveTo(250, 590, 150, 580, 100, 540);
    ctx.bezierCurveTo(70, 500, 60, 400, 65, 300);
    ctx.bezierCurveTo(70, 200, 90, 140, 130, 110);
    ctx.bezierCurveTo(180, 85, 250, 95, 280, 120);
    ctx.closePath();
    ctx.fill();
    ctx.restore();

    // Left lung (viewer's right) - slightly smaller due to heart
    const lungGradL = ctx.createRadialGradient(400, 350, 20, 400, 350, 190);
    lungGradL.addColorStop(0, 'rgba(5,5,5,0.95)');
    lungGradL.addColorStop(0.3, 'rgba(10,10,10,0.9)');
    lungGradL.addColorStop(0.6, 'rgba(15,15,15,0.85)');
    lungGradL.addColorStop(0.85, 'rgba(25,25,25,0.7)');
    lungGradL.addColorStop(1, 'rgba(40,40,40,0.4)');
    
    ctx.save();
    ctx.filter = 'blur(3px)';
    ctx.fillStyle = lungGradL;
    ctx.beginPath();
    ctx.moveTo(320, 120);
    ctx.bezierCurveTo(330, 200, 340, 350, 330, 480);
    ctx.bezierCurveTo(325, 530, 320, 560, 310, 580);
    ctx.bezierCurveTo(350, 590, 450, 580, 500, 540);
    ctx.bezierCurveTo(530, 500, 540, 400, 535, 300);
    ctx.bezierCurveTo(530, 200, 510, 140, 470, 110);
    ctx.bezierCurveTo(420, 85, 350, 95, 320, 120);
    ctx.closePath();
    ctx.fill();
    ctx.restore();

    // === LUNG VESSEL MARKINGS (bronchovascular) ===
    ctx.save();
    ctx.filter = 'blur(2px)';
    ctx.globalAlpha = 0.3;
    ctx.strokeStyle = 'rgba(50,50,50,0.8)';
    ctx.lineWidth = 1.5;
    
    // Right hilar vessels
    for (let i = 0; i < 12; i++) {
      const angle = -0.8 + i * 0.15;
      const len = 80 + Math.random() * 100;
      ctx.beginPath();
      ctx.moveTo(260, 280);
      const cp1x = 260 + Math.cos(angle) * len * 0.5 + (Math.random() - 0.5) * 20;
      const cp1y = 280 + Math.sin(angle) * len * 0.5;
      const ex = 260 + Math.cos(angle) * len;
      const ey = 280 + Math.sin(angle) * len;
      ctx.quadraticCurveTo(cp1x, cp1y, ex, ey);
      ctx.stroke();
    }
    // Left hilar vessels
    for (let i = 0; i < 12; i++) {
      const angle = Math.PI + 0.8 - i * 0.15;
      const len = 80 + Math.random() * 100;
      ctx.beginPath();
      ctx.moveTo(340, 280);
      const cp1x = 340 + Math.cos(angle) * len * 0.5 + (Math.random() - 0.5) * 20;
      const cp1y = 280 + Math.sin(angle) * len * 0.5;
      const ex = 340 + Math.cos(angle) * len;
      const ey = 280 + Math.sin(angle) * len;
      ctx.quadraticCurveTo(cp1x, cp1y, ex, ey);
      ctx.stroke();
    }
    ctx.restore();

    // === HEART SHADOW (Mediastinum) ===
    const heartGrad = ctx.createRadialGradient(320, 400, 10, 320, 400, 130);
    heartGrad.addColorStop(0, 'rgba(75,75,75,0.9)');
    heartGrad.addColorStop(0.4, 'rgba(65,65,65,0.85)');
    heartGrad.addColorStop(0.7, 'rgba(55,55,55,0.7)');
    heartGrad.addColorStop(1, 'rgba(35,35,35,0.3)');
    
    ctx.save();
    ctx.filter = 'blur(5px)';
    ctx.fillStyle = heartGrad;
    ctx.beginPath();
    ctx.moveTo(300, 180);
    ctx.bezierCurveTo(310, 220, 330, 300, 340, 380);
    ctx.bezierCurveTo(350, 440, 360, 500, 340, 560);
    ctx.bezierCurveTo(320, 590, 280, 590, 250, 570);
    ctx.bezierCurveTo(220, 540, 210, 480, 220, 420);
    ctx.bezierCurveTo(230, 350, 260, 280, 280, 220);
    ctx.bezierCurveTo(290, 190, 295, 180, 300, 180);
    ctx.closePath();
    ctx.fill();
    ctx.restore();

    // Aortic knob
    drawSoftEllipse(ctx, 280, 200, 35, 30, 'rgba(70,70,70,0.6)', 6);
    
    // === SPINE (vertebral column) ===
    ctx.save();
    ctx.filter = 'blur(2px)';
    const spineGrad = ctx.createLinearGradient(285, 0, 315, 0);
    spineGrad.addColorStop(0, 'rgba(55,55,55,0.4)');
    spineGrad.addColorStop(0.3, 'rgba(70,70,70,0.6)');
    spineGrad.addColorStop(0.5, 'rgba(80,80,80,0.7)');
    spineGrad.addColorStop(0.7, 'rgba(70,70,70,0.6)');
    spineGrad.addColorStop(1, 'rgba(55,55,55,0.4)');
    ctx.fillStyle = spineGrad;
    ctx.fillRect(288, 100, 24, 500);
    
    // Vertebral bodies
    for (let i = 0; i < 12; i++) {
      const y = 130 + i * 38;
      const vertGrad = ctx.createLinearGradient(285, y, 315, y);
      vertGrad.addColorStop(0, 'rgba(60,60,60,0.3)');
      vertGrad.addColorStop(0.5, 'rgba(85,85,85,0.5)');
      vertGrad.addColorStop(1, 'rgba(60,60,60,0.3)');
      ctx.fillStyle = vertGrad;
      ctx.fillRect(286, y, 28, 30);
      // Disc space
      ctx.fillStyle = 'rgba(20,20,20,0.4)';
      ctx.fillRect(288, y + 30, 24, 8);
    }
    ctx.restore();

    // === RIBS ===
    ctx.save();
    // Posterior ribs (more visible, thicker)
    for (let i = 0; i < 10; i++) {
      const y = 140 + i * 42;
      const ribOpacity = 0.25 + (i < 5 ? 0.1 : 0);
      
      // Right ribs
      ctx.filter = `blur(${1.5 + i * 0.1}px)`;
      ctx.globalAlpha = ribOpacity;
      ctx.strokeStyle = 'rgba(90,90,90,0.9)';
      ctx.lineWidth = 4 - i * 0.2;
      ctx.beginPath();
      ctx.moveTo(300, y);
      ctx.bezierCurveTo(250, y - 5 + i * 2, 180, y + 10 + i * 3, 100, y + 30 + i * 5);
      ctx.stroke();
      
      // Left ribs
      ctx.beginPath();
      ctx.moveTo(300, y);
      ctx.bezierCurveTo(350, y - 5 + i * 2, 420, y + 10 + i * 3, 500, y + 30 + i * 5);
      ctx.stroke();
    }
    
    // Anterior ribs (thinner, less visible)
    ctx.globalAlpha = 0.15;
    for (let i = 0; i < 8; i++) {
      const y = 160 + i * 45;
      ctx.filter = 'blur(2px)';
      ctx.strokeStyle = 'rgba(80,80,80,0.7)';
      ctx.lineWidth = 2;
      
      // Right anterior
      ctx.beginPath();
      ctx.moveTo(290, y + 20);
      ctx.bezierCurveTo(250, y + 40, 180, y + 60, 120, y + 80);
      ctx.stroke();
      
      // Left anterior
      ctx.beginPath();
      ctx.moveTo(310, y + 20);
      ctx.bezierCurveTo(350, y + 40, 420, y + 60, 480, y + 80);
      ctx.stroke();
    }
    ctx.restore();

    // === CLAVICLES ===
    ctx.save();
    ctx.filter = 'blur(1.5px)';
    ctx.strokeStyle = 'rgba(95,95,95,0.7)';
    ctx.lineWidth = 6;
    ctx.lineCap = 'round';
    
    // Right clavicle
    ctx.beginPath();
    ctx.moveTo(295, 105);
    ctx.bezierCurveTo(240, 95, 160, 90, 80, 100);
    ctx.stroke();
    
    // Left clavicle
    ctx.beginPath();
    ctx.moveTo(305, 105);
    ctx.bezierCurveTo(360, 95, 440, 90, 520, 100);
    ctx.stroke();
    ctx.restore();

    // === SCAPULAE (shoulder blades) ===
    drawSoftEllipse(ctx, 90, 180, 40, 70, 'rgba(60,60,60,0.3)', 5);
    drawSoftEllipse(ctx, 510, 180, 40, 70, 'rgba(60,60,60,0.3)', 5);

    // === DIAPHRAGM ===
    ctx.save();
    ctx.filter = 'blur(3px)';
    ctx.strokeStyle = 'rgba(75,75,75,0.7)';
    ctx.lineWidth = 4;
    
    // Right hemidiaphragm
    ctx.beginPath();
    ctx.moveTo(80, 540);
    ctx.bezierCurveTo(120, 500, 200, 490, 280, 520);
    ctx.stroke();
    
    // Left hemidiaphragm (slightly lower)
    ctx.beginPath();
    ctx.moveTo(320, 530);
    ctx.bezierCurveTo(400, 500, 480, 510, 520, 550);
    ctx.stroke();
    
    // Costophrenic angles
    ctx.strokeStyle = 'rgba(60,60,60,0.5)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(80, 540);
    ctx.lineTo(90, 580);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(520, 550);
    ctx.lineTo(510, 590);
    ctx.stroke();
    ctx.restore();

    // === TRACHEA ===
    ctx.save();
    ctx.filter = 'blur(2px)';
    ctx.fillStyle = 'rgba(10,10,10,0.7)';
    ctx.beginPath();
    ctx.moveTo(293, 50);
    ctx.lineTo(307, 50);
    ctx.lineTo(310, 200);
    ctx.lineTo(290, 200);
    ctx.closePath();
    ctx.fill();
    
    // Carina
    ctx.beginPath();
    ctx.moveTo(290, 200);
    ctx.lineTo(260, 250);
    ctx.lineTo(265, 255);
    ctx.lineTo(295, 210);
    ctx.closePath();
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(310, 200);
    ctx.lineTo(340, 250);
    ctx.lineTo(335, 255);
    ctx.lineTo(305, 210);
    ctx.closePath();
    ctx.fill();
    ctx.restore();

    // === FILM GRAIN / NOISE ===
    const noise = createNoise(W, H, 3);
    const imageData = ctx.getImageData(0, 0, W, H);
    const data = imageData.data;
    for (let i = 0; i < noise.length; i++) {
      const grain = (noise[i] - 0.5) * 15;
      data[i * 4] = Math.max(0, Math.min(255, data[i * 4] + grain));
      data[i * 4 + 1] = Math.max(0, Math.min(255, data[i * 4 + 1] + grain));
      data[i * 4 + 2] = Math.max(0, Math.min(255, data[i * 4 + 2] + grain));
    }
    ctx.putImageData(imageData, 0, 0);

    // === VIGNETTE ===
    const vigGrad = ctx.createRadialGradient(W/2, H/2, W*0.25, W/2, H/2, W*0.7);
    vigGrad.addColorStop(0, 'rgba(0,0,0,0)');
    vigGrad.addColorStop(0.7, 'rgba(0,0,0,0.1)');
    vigGrad.addColorStop(1, 'rgba(0,0,0,0.5)');
    ctx.fillStyle = vigGrad;
    ctx.fillRect(0, 0, W, H);

    // === BORDER MARKERS (typical X-ray markers) ===
    ctx.save();
    ctx.font = 'bold 16px monospace';
    ctx.fillStyle = 'rgba(200,200,200,0.8)';
    ctx.fillText('R', 560, 30);
    ctx.fillText('PA', 20, 30);
    ctx.restore();

    baseCanvasRef.current = offscreen;
    return offscreen;
  }, []);

  const renderFindings = useCallback((baseImage: HTMLCanvasElement) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d')!;
    
    // Draw base
    ctx.drawImage(baseImage, 0, 0);

    // Apply brightness/contrast
    if (brightness !== 0 || contrast !== 0) {
      const imageData = ctx.getImageData(0, 0, W, H);
      const data = imageData.data;
      const factor = (259 * (contrast * 255 + 255)) / (255 * (259 - contrast * 255));
      for (let i = 0; i < data.length; i += 4) {
        for (let c = 0; c < 3; c++) {
          let val = data[i + c];
          val += brightness * 50;
          val = factor * (val - 128) + 128;
          data[i + c] = Math.max(0, Math.min(255, val));
        }
      }
      ctx.putImageData(imageData, 0, 0);
    }

    // Invert if needed
    if (inverted) {
      const imageData = ctx.getImageData(0, 0, W, H);
      const data = imageData.data;
      for (let i = 0; i < data.length; i += 4) {
        data[i] = 255 - data[i];
        data[i + 1] = 255 - data[i + 1];
        data[i + 2] = 255 - data[i + 2];
      }
      ctx.putImageData(imageData, 0, 0);
    }

    // Draw findings
    if (showOverlay) {
      findings.forEach(finding => {
        const isActive = activeFinding === finding.id;
        ctx.save();
        
        switch (finding.type) {
          case 'opacity': {
            // Consolidation / opacity
            const grad = ctx.createRadialGradient(finding.x, finding.y, 0, finding.x, finding.y, finding.radius);
            grad.addColorStop(0, 'rgba(80,80,80,0.7)');
            grad.addColorStop(0.5, 'rgba(65,65,65,0.5)');
            grad.addColorStop(1, 'rgba(40,40,40,0)');
            ctx.filter = 'blur(4px)';
            ctx.fillStyle = grad;
            ctx.beginPath();
            ctx.ellipse(finding.x, finding.y, finding.radius, finding.radius * 0.8, 0, 0, Math.PI * 2);
            ctx.fill();
            break;
          }
          case 'lucency': {
            // Hyperlucency
            const grad = ctx.createRadialGradient(finding.x, finding.y, 0, finding.x, finding.y, finding.radius);
            grad.addColorStop(0, 'rgba(0,0,0,0.6)');
            grad.addColorStop(0.7, 'rgba(0,0,0,0.3)');
            grad.addColorStop(1, 'rgba(0,0,0,0)');
            ctx.filter = 'blur(5px)';
            ctx.fillStyle = grad;
            ctx.beginPath();
            ctx.ellipse(finding.x, finding.y, finding.radius, finding.radius * 0.9, 0, 0, Math.PI * 2);
            ctx.fill();
            break;
          }
          case 'effusion': {
            // Pleural effusion - meniscus sign
            ctx.filter = 'blur(3px)';
            const effGrad = ctx.createLinearGradient(finding.x, finding.y - finding.radius, finding.x, finding.y + finding.radius);
            effGrad.addColorStop(0, 'rgba(60,60,60,0)');
            effGrad.addColorStop(0.3, 'rgba(70,70,70,0.4)');
            effGrad.addColorStop(1, 'rgba(80,80,80,0.8)');
            ctx.fillStyle = effGrad;
            ctx.beginPath();
            ctx.moveTo(finding.x - finding.radius, finding.y + finding.radius);
            ctx.quadraticCurveTo(finding.x, finding.y - finding.radius * 0.5, finding.x + finding.radius, finding.y + finding.radius);
            ctx.lineTo(finding.x + finding.radius, finding.y + finding.radius * 1.5);
            ctx.lineTo(finding.x - finding.radius, finding.y + finding.radius * 1.5);
            ctx.closePath();
            ctx.fill();
            break;
          }
          case 'pneumothorax': {
            // Pneumothorax - visible pleural line
            ctx.filter = 'blur(1px)';
            ctx.strokeStyle = 'rgba(90,90,90,0.8)';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.moveTo(finding.x - finding.radius, finding.y - finding.radius * 0.5);
            ctx.bezierCurveTo(
              finding.x - finding.radius * 0.3, finding.y - finding.radius,
              finding.x + finding.radius * 0.3, finding.y - finding.radius,
              finding.x + finding.radius, finding.y - finding.radius * 0.5
            );
            ctx.stroke();
            // Lucent area beyond
            const ptGrad = ctx.createRadialGradient(finding.x, finding.y - finding.radius * 0.3, 0, finding.x, finding.y - finding.radius * 0.3, finding.radius);
            ptGrad.addColorStop(0, 'rgba(0,0,0,0.5)');
            ptGrad.addColorStop(1, 'rgba(0,0,0,0)');
            ctx.filter = 'blur(4px)';
            ctx.fillStyle = ptGrad;
            ctx.fillRect(finding.x - finding.radius, finding.y - finding.radius, finding.radius * 2, finding.radius);
            break;
          }
          case 'mass': {
            // Mass/nodule
            const massGrad = ctx.createRadialGradient(finding.x, finding.y, 0, finding.x, finding.y, finding.radius);
            massGrad.addColorStop(0, 'rgba(85,85,85,0.8)');
            massGrad.addColorStop(0.6, 'rgba(70,70,70,0.6)');
            massGrad.addColorStop(0.85, 'rgba(55,55,55,0.3)');
            massGrad.addColorStop(1, 'rgba(40,40,40,0)');
            ctx.filter = 'blur(2px)';
            ctx.fillStyle = massGrad;
            ctx.beginPath();
            // Irregular shape
            for (let a = 0; a < Math.PI * 2; a += 0.1) {
              const r = finding.radius * (0.8 + 0.2 * Math.sin(a * 3 + finding.x));
              const px = finding.x + Math.cos(a) * r;
              const py = finding.y + Math.sin(a) * r;
              if (a === 0) ctx.moveTo(px, py);
              else ctx.lineTo(px, py);
            }
            ctx.closePath();
            ctx.fill();
            break;
          }
          case 'fracture': {
            // Fracture line
            ctx.filter = 'blur(0.5px)';
            ctx.strokeStyle = 'rgba(20,20,20,0.8)';
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.moveTo(finding.x - finding.radius, finding.y - finding.radius * 0.3);
            ctx.bezierCurveTo(
              finding.x - finding.radius * 0.3, finding.y + finding.radius * 0.2,
              finding.x + finding.radius * 0.3, finding.y - finding.radius * 0.2,
              finding.x + finding.radius, finding.y + finding.radius * 0.3
            );
            ctx.stroke();
            // Displacement
            ctx.strokeStyle = 'rgba(80,80,80,0.5)';
            ctx.lineWidth = 3;
            ctx.filter = 'blur(2px)';
            ctx.beginPath();
            ctx.moveTo(finding.x - finding.radius * 0.8, finding.y - finding.radius * 0.4);
            ctx.lineTo(finding.x + finding.radius * 0.8, finding.y + finding.radius * 0.4);
            ctx.stroke();
            break;
          }
          case 'calcification': {
            // Calcification
            ctx.filter = 'blur(1px)';
            ctx.fillStyle = 'rgba(120,120,120,0.8)';
            ctx.beginPath();
            ctx.arc(finding.x, finding.y, finding.radius * 0.4, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = 'rgba(140,140,140,0.6)';
            ctx.beginPath();
            ctx.arc(finding.x, finding.y, finding.radius * 0.2, 0, Math.PI * 2);
            ctx.fill();
            break;
          }
          case 'cardiomegaly': {
            // Enlarged heart
            const heartGrad = ctx.createRadialGradient(finding.x, finding.y, 10, finding.x, finding.y, finding.radius);
            heartGrad.addColorStop(0, 'rgba(80,80,80,0.6)');
            heartGrad.addColorStop(0.5, 'rgba(70,70,70,0.5)');
            heartGrad.addColorStop(1, 'rgba(50,50,50,0)');
            ctx.filter = 'blur(6px)';
            ctx.fillStyle = heartGrad;
            ctx.beginPath();
            ctx.ellipse(finding.x, finding.y, finding.radius, finding.radius * 1.1, 0, 0, Math.PI * 2);
            ctx.fill();
            break;
          }
          default: {
            // Generic marker
            ctx.strokeStyle = isActive ? '#22d3ee' : '#f59e0b';
            ctx.lineWidth = isActive ? 2 : 1.5;
            ctx.setLineDash([4, 4]);
            ctx.beginPath();
            ctx.arc(finding.x, finding.y, finding.radius, 0, Math.PI * 2);
            ctx.stroke();
          }
        }
        
        // Active highlight ring
        if (isActive) {
          ctx.filter = 'none';
          ctx.strokeStyle = '#22d3ee';
          ctx.lineWidth = 2;
          ctx.setLineDash([6, 3]);
          ctx.beginPath();
          ctx.arc(finding.x, finding.y, finding.radius + 8, 0, Math.PI * 2);
          ctx.stroke();
          
          // Label
          ctx.setLineDash([]);
          ctx.font = '11px sans-serif';
          ctx.fillStyle = '#22d3ee';
          ctx.fillText(finding.name, finding.x + finding.radius + 12, finding.y);
        }
        
        ctx.restore();
      });
    }
  }, [findings, activeFinding, showOverlay, brightness, contrast, inverted]);

  useEffect(() => {
    const base = renderBase();
    renderFindings(base);
  }, [renderBase, renderFindings]);

  return (
    <div className="relative w-full h-full overflow-hidden bg-black">
      <canvas
        ref={canvasRef}
        width={W}
        height={H}
        className="w-full h-full object-contain"
        style={{
          transform: `scale(${zoom}) translate(${panX}px, ${panY}px)`,
          imageRendering: 'auto',
        }}
      />
    </div>
  );
}
